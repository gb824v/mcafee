function RSDSettings()
{
}

new RSDSettings();

RSDSettings.VALID_LAST_AGENT_COMMUNICATION = true;
RSDSettings.VALID_LAST_SENSOR_DETECTION = true;
RSDSettings.VALID_SUBNET_GOOD = true;
RSDSettings.VALID_SYSTEM_GOOD = true;
RSDSettings.VALID_SENSOR_GOOD = true;

function validateSettings()
{
    return RSDSettings.validate();
}

RSDSettings.validate = function ()
{
    var isValid =( RSDSettings.VALID_LAST_AGENT_COMMUNICATION &&
        RSDSettings.VALID_LAST_SENSOR_DETECTION &&
        RSDSettings.VALID_SUBNET_GOOD &&
        RSDSettings.VALID_SYSTEM_GOOD &&
        RSDSettings.VALID_SENSOR_GOOD
        );

    OrionCore.setEnabledById("saveButton", isValid);

    return isValid;
}

RSDSettings.lastAgentCommunication = function()
{
    var lac = new Number($("rsd.lastAgentCommunication").value);
    var lsd = new Number($("rsd.lastSensorDetection").value);

    if (lac != "")
    {
        $("rsd.lastAgentCommunication.time").style.display = "none";
        if (isNaN(lac))
        {
            lac = 1;
            $("rsd.lastAgentCommunication").value = lac;
        }
        else if (lac <= 0)
        {
            lac = 1;
            $("rsd.lastAgentCommunication").value = lac;
        }
        else if (lac >= 1000)
        {
            lac = 999;
            $("rsd.lastAgentCommunication").value = lac;
        }

        if (lac > lsd)
        {
            RSDSettings.VALID_LAST_AGENT_COMMUNICATION = false;
            RSDSettings.VALID_LAST_SENSOR_DETECTION = false;
            $("rsd.lastAgentCommunication.agent").style.display = "";
            $("rsd.lastSensorDetection.sensor").style.display = "";
        }
        else
        {
            RSDSettings.VALID_LAST_AGENT_COMMUNICATION = true;
            RSDSettings.VALID_LAST_SENSOR_DETECTION = true;
            $("rsd.lastAgentCommunication.agent").style.display = "none";
            $("rsd.lastSensorDetection.sensor").style.display = "none";
        }
    }
    else
    {
        RSDSettings.VALID_LAST_AGENT_COMMUNICATION = false;
        RSDSettings.VALID_LAST_SENSOR_DETECTION = false;
        $("rsd.lastAgentCommunication.time").style.display = "";
        $("rsd.lastAgentCommunication.agent").style.display = "none";
        $("rsd.lastSensorDetection.sensor").style.display = "none";
    }
    $("rsd.lastAgentCommOlderThan").innerHTML = $("rsd.lastAgentCommunication").value;

    return RSDSettings.validate();
}

RSDSettings.lastSensorDetection = function ()
{
    var lsd = new Number($("rsd.lastSensorDetection").value);
    var lac = new Number($("rsd.lastAgentCommunication").value);

    if (lsd != "")
    {
        $("rsd.lastSensorDetection.time").style.display = "none";
        if (isNaN(lac))
        {
            lsd = 1;
            $("rsd.lastSensorDetection").value = lsd;
        }
        else if (lsd <= 0)
        {
            lsd = 1;
            $("rsd.lastSensorDetection").value = lsd;
        }
        else if (lsd >= 1000)
        {
            lsd = 999;
            $("rsd.lastSensorDetection").value = lsd;
        }

        if (lsd >= lac)
        {
            RSDSettings.VALID_LAST_SENSOR_DETECTION = true;
            RSDSettings.VALID_LAST_AGENT_COMMUNICATION = true;
            $("rsd.lastSensorDetection.sensor").style.display = "none";
            $("rsd.lastAgentCommunication.agent").style.display = "none";
        }
        else
        {
            RSDSettings.VALID_LAST_SENSOR_DETECTION = false;
            RSDSettings.VALID_LAST_AGENT_COMMUNICATION = false;
            $("rsd.lastSensorDetection.sensor").style.display = "";
            $("rsd.lastAgentCommunication.agent").style.display = "";
        }
    }
    else
    {
        RSDSettings.VALID_LAST_SENSOR_DETECTION = false;
        RSDSettings.VALID_LAST_AGENT_COMMUNICATION = false;
        $("rsd.lastSensorDetection.time").style.display = "";
        $("rsd.lastAgentCommunication.agent").style.display = "none";
        $("rsd.lastSensorDetection.sensor").style.display = "none";
    }

    return RSDSettings.validate();
}

RSDSettings.subnetGoodValidation = function ()
{
    var sg = new Number($("rsd.subnetGood").value);
    var so = new Number($("rsd.subnetOk").value);

    if (sg != "")
    {
        $("rsd.subnet.invalid.value").style.display = "none";
        if (isNaN(sg))
        {
            $("rsd.subnetGreen.invalid").style.display = "";
            $("rsd.subnetGood").value = "";
            $("rsd.subnetOkGood").innerHTML = "";
            sg = -1;
        }
        else if (sg <= 1)
        {
            $("rsd.subnetGreen.invalid").style.display = "";
            $("rsd.subnetGood").value = "";
            $("rsd.subnetOkGood").innerHTML = "";
            sg = -1;
        }
        else if (sg > 99)
        {
            $("rsd.subnetGreen.invalid").style.display = "";
            $("rsd.subnetGood").value = "";
            $("rsd.subnetOkGood").innerHTML = "";
            sg = -1;
        }
        else
        {
            $("rsd.subnetGreen.invalid").style.display = "none";
            $("rsd.subnetGood").value = sg;
            $("rsd.subnetOkGood").innerHTML = sg;
        }

        if (sg > 0 && so > 0 && sg > so)
        {
            RSDSettings.VALID_SUBNET_GOOD = true;
            $("rsd.subnet.invalid.value").style.display = "none";
        }
        else
        {
            RSDSettings.VALID_SUBNET_GOOD = false;
            $("rsd.subnet.invalid.value").style.display = "";
        }
    }
    else
    {
        RSDSettings.VALID_SUBNET_GOOD = false;
        $("rsd.subnet.invalid.value").style.display = "";
    }

    return RSDSettings.validate();
}

RSDSettings.subnetOkValidation = function ()
{
    var sg = new Number($("rsd.subnetGood").value);
    var so = new Number($("rsd.subnetOk").value);

    if (so != "")
    {
        if (isNaN(so) || so < 1 || so >= sg)
        {
            $("rsd.subnetOrange.invalid").style.display = "";
            $("rsd.subnetOk").value = "";
            $("rsd.subnetPoor").innerHTML = "";
            so = 100;
        }
        else
        {
            $("rsd.subnetOrange.invalid").style.display = "none";
            $("rsd.subnetOk").value = so;
            $("rsd.subnetPoor").innerHTML = so;
        }

        if (sg > 0 && so > 0 && sg > so)
        {
            RSDSettings.VALID_SUBNET_GOOD = true;
            $("rsd.subnet.invalid.value").style.display = "none";
        }
        else
        {
            RSDSettings.VALID_SUBNET_GOOD = false;
            $("rsd.subnet.invalid.value").style.display = "";
        }
    }
    else
    {
        RSDSettings.VALID_SUBNET_GOOD = false;
        $("rsd.subnet.invalid.value").style.display = "";
    }

    return RSDSettings.validate();
}

RSDSettings.systemGoodValidation = function ()
{
    var sg = new Number($("rsd.systemGood").value);
    var so = new Number($("rsd.systemOk").value);

    if (sg != "")
    {
        $("rsd.system.invalid.value").style.display = "none";
        if (isNaN(sg))
        {
            $("rsd.systemGreen.invalid").style.display = "";
            $("rsd.systemGood").value = "";
            $("rsd.systemOkGood").innerHTML = "";
            sg = -1;
        }
        else if (sg <= 1)
        {
            $("rsd.systemGreen.invalid").style.display = "";
            $("rsd.systemGood").value = "";
            $("rsd.systemOkGood").innerHTML = "";
            sg = -1;
        }
        else if (sg > 99)
        {
            $("rsd.systemGreen.invalid").style.display = "";
            $("rsd.systemGood").value = "";
            $("rsd.systemOkGood").innerHTML = "";
            sg = -1;
        }
        else
        {
            $("rsd.systemGreen.invalid").style.display = "none";
            $("rsd.systemGood").value = sg;
            $("rsd.systemOkGood").innerHTML = sg;
        }

        if (sg > 0 && so > 0 && sg > so)
        {
            RSDSettings.VALID_SYSTEM_GOOD = true;
            $("rsd.system.invalid.value").style.display = "none";
        }
        else
        {
            RSDSettings.VALID_SYSTEM_GOOD = false;
            $("rsd.system.invalid.value").style.display = "";
        }
    }
    else
    {
        RSDSettings.VALID_SYSTEM_GOOD = false;
        $("rsd.system.invalid.value").style.display = "";
    }

    return RSDSettings.validate();
}

RSDSettings.systemOkValidation = function ()
{
    var sg = new Number($("rsd.systemGood").value);
    var so = new Number($("rsd.systemOk").value);

    if (so != "")
    {
        if (isNaN(so) || so < 1 || so >= sg)
        {
            $("rsd.systemOrange.invalid").style.display = "";
            $("rsd.systemOk").value = "";
            $("rsd.systemPoor").innerHTML = "";
            so = 100;
        }
        else
        {
            $("rsd.systemOrange.invalid").style.display = "none";
            $("rsd.systemOk").value = so;
            $("rsd.systemPoor").innerHTML = so;
        }

        if (sg > 0 && so > 0 && sg > so)
        {
            RSDSettings.VALID_SYSTEM_GOOD = true;
            $("rsd.system.invalid.value").style.display = "none";
        }
        else
        {
            RSDSettings.VALID_SYSTEM_GOOD = false;
            $("rsd.system.invalid.value").style.display = "";
        }
    }
    else
    {
        RSDSettings.VALID_SYSTEM_GOOD = false;
        $("rsd.system.invalid.value").style.display = "";
    }

    return RSDSettings.validate();
}

RSDSettings.sensorGoodValidation = function ()
{
    var sg = new Number($("rsd.sensorGood").value);
    var so = new Number($("rsd.sensorOk").value);

    if (sg != "")
    {
        $("rsd.sensor.invalid.value").style.display = "none";
        if (isNaN(sg))
        {
            $("rsd.sensorGreen.invalid").style.display = "";
            $("rsd.sensorGood").value = "";
            $("rsd.sensorOkGood").innerHTML = "";
            sg = -1;
        }
        else if (sg <= 1)
        {
            $("rsd.sensorGreen.invalid").style.display = "";
            $("rsd.sensorGood").value = "";
            $("rsd.sensorOkGood").innerHTML = "";
            sg = -1;
        }
        else if (sg > 99)
        {
            $("rsd.sensorGreen.invalid").style.display = "";
            $("rsd.sensorGood").value = "";
            $("rsd.sensorOkGood").innerHTML = "";
            sg = -1;
        }
        else
        {
            $("rsd.sensorGreen.invalid").style.display = "none";
            $("rsd.sensorGood").value = sg;
            $("rsd.sensorOkGood").innerHTML = sg;
        }

        if (sg > 0 && so > 0 && sg > so)
        {
            RSDSettings.VALID_SENSOR_GOOD = true;
            $("rsd.sensor.invalid.value").style.display = "none";
        }
        else
        {
            RSDSettings.VALID_SENSOR_GOOD = false;
            $("rsd.sensor.invalid.value").style.display = "";
        }
    }
    else
    {
        RSDSettings.VALID_SENSOR_GOOD = false;
        $("rsd.sensor.invalid.value").style.display = "";
    }

    return RSDSettings.validate();
}

RSDSettings.sensorOkValidation = function ()
{
    var sg = new Number($("rsd.sensorGood").value);
    var so = new Number($("rsd.sensorOk").value);

    if (so != "")
    {
        if (isNaN(so) || so < 1 || so >= sg)
        {
            $("rsd.sensorOrange.invalid").style.display = "";
            $("rsd.sensorOk").value = "";
            $("rsd.sensorPoor").innerHTML = "";
            so = 100;
        }
        else
        {
            $("rsd.sensorOrange.invalid").style.display = "none";
            $("rsd.sensorOk").value = so;
            $("rsd.sensorPoor").innerHTML = so;
        }

        if (sg > 0 && so > 0 && sg > so)
        {
            RSDSettings.VALID_SENSOR_GOOD = true;
            $("rsd.sensor.invalid.value").style.display = "none";
        }
        else
        {
            RSDSettings.VALID_SENSOR_GOOD = false;
            $("rsd.sensor.invalid.value").style.display = "";
        }
    }
    else
    {
        RSDSettings.VALID_SENSOR_GOOD = false;
        $("rsd.sensor.invalid.value").style.display = "";
    }

    return RSDSettings.validate();
}