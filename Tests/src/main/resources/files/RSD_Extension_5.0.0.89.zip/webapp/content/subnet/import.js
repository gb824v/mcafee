function _clickedSingle()
{
    OrionCore.setEnabled($("subnet.name.id"), true);
    OrionCore.setEnabled($("network.addr.id"), true);
    OrionCore.setEnabled($("network.mask.id"), true);
    OrionCore.setEnabled($("import.type.text.value"), false);
    OrionCore.setEnabled($("import.type.file.value"), false);
    $("import.type.single").checked = true;
}

function _clickedText()
{
    OrionCore.setEnabled($("subnet.name.id"), false);
    OrionCore.setEnabled($("network.addr.id"), false);
    OrionCore.setEnabled($("network.mask.id"), false);
    OrionCore.setEnabled($("import.type.text.value"), true);
    OrionCore.setEnabled($("import.type.file.value"), false);
    $("import.type.text").checked = true;
}

function _clickedFile()
{
    OrionCore.setEnabled($("subnet.name.id"), false);
    OrionCore.setEnabled($("network.addr.id"), false);
    OrionCore.setEnabled($("network.mask.id"), false);
    OrionCore.setEnabled($("import.type.text.value"), false);
    OrionCore.setEnabled($("import.type.file.value"), true);
    $("import.type.file").checked = true;
}

function _cancel()
{
    OrionForm.markInputExempt("import.type.single");
    OrionForm.markInputExempt("import.type.file");
    OrionForm.markInputExempt("import.type.text");

    OrionNavigation.back();
}

function _doOnLoad()
{
    OrionForm.setStateChangeHandler(onFormStateChange);
    OrionForm.revalidate();
}

function onFormStateChange( isDirty, isValid )
{
    if (isDirty && isValid)
    {
        OrionCore.setEnabled($("import.button"), true);
    }
    else
    {
        OrionCore.setEnabled($("import.button"), false);
    }
}

function _addSubnet()
{
        if ($("import.type.file").checked)
        {
            // Set the encoding type for uploading an image
            OrionForm.setEncoding(OrionForm.MULTIPART);
        }
        else
        {
            // Set the encoding type for text - not uploading an image
            OrionForm.setEncoding(OrionForm.DEFAULT);
        }

        OrionCore.doFormAction("/rsd/addSubnet.do", [], "POST");
}

function _validateImportCidr(address, mask)
{
    return  ( OrionValidate.isValidIpv4CidrSubnet(address, mask) ||  OrionValidate.isValidIpv6CidrSubnet(address, mask) );
}

function _validateIPAddress(value)
{
    var address = $("network.addr.id").value;
    var mask = $("network.mask.id").value;
    return  _validateImportCidr(address, mask);
}

function _validateNameAndIP()
{
	var isValid = false;

    var iprange = $("import.type.text.value");
    var rangeList = OrionCore.trim(iprange.value);

    if (rangeList && rangeList.length > 0)
    {
        var ranges = rangeList.split(/[\r\n]/);

        for (var i = 0; i < ranges.length; i++)
        {
        	var val = OrionCore.trim(ranges[i]);
		    if (val.indexOf(",") > 0)
		    {
		    	var comma = val.indexOf(",");
		    	if (val.length > comma+1)
		    	{
		    		var addr = val.substring(comma+1);
			    	var idx = val.indexOf("/",comma+1);
			    	if (val.length > idx+1)
			    	{
				    	var addr = val.substring(comma+1,idx);
				    	var bits = val.substring(idx+1);

				    	isValid = _validateImportCidr(addr, bits);
				    }
				    else
				    {
				    	isValid = false;
				    }
		    	}
		    	else
		    	{
		    		isValid = false;
		    	}
		    }
		    else
		    {
		    	var idx = val.indexOf("/");
		    	if (val.length > idx+1)
		    	{
			    	var addr = val.substring(0,idx);
			    	var bits = val.substring(idx+1);

			    	isValid = _validateImportCidr(addr, bits);
			    }
			    else
			    {
			    	isValid = false;
			    }
		    }
        }
    }
    else
    {
    	isValid = false;
    }

    return isValid;
}