function RSDHome()
{
}

new RSDHome();

RSDHome.selectRow = function( uid )
{
    if (uid < 0)
    {
        // a negative value indicates this is the unknown subnet, but the acutal subnet id is not negative...
        if ($("ignore.subnet.button"))
        {
            OrionCore.setEnabledById("ignore.subnet.button", false);
        }
        uid = (uid * -1);
    }
    else
    {
        if ($("ignore.subnet.button"))
        {
            OrionCore.setEnabledById("ignore.subnet.button", true);
        }
    }
    OrionCore.doAsyncAction("/rsd/loadRoguesForSubnet.do", ["subnetID", uid], RSDHome.loadRoguesForSubnetTable, RSDHome.loadRoguesForSubnetTableFailure);
}

RSDHome.listLoaded = function ()
{
    // This was causing a double-load of the table - bug 447875
    var subnetID = OrionList.getSelectedItem("roguesBySubnetList");
    RSDHome.selectRow(subnetID);
    if(OrionList.isEmpty("roguesBySubnetList"))
    {
        if ($("ignore.subnet.button"))
        {
            OrionCore.setEnabledById("ignore.subnet.button", false);
        }
    }
}

RSDHome.loadRoguesForSubnetTable = function()
{
    var table = MFSTable.get("rfsTable");
    table.refresh();
//    OrionTable.refresh("rfsTable");
}

RSDHome.loadRoguesForSubnetTableFailure = function (ret, text)
{
    OrionCore.showMessageBox(true, ret+" "+text, OrionCore.DIALOG_OK);
}

RSDHome.doDashboardDataRollover = function( element )
{
    element.className = "homeDashboardDataValue homeDashboardDataValueOver";
}

RSDHome.doDashboardDataRollout = function( element )
{
    element.className = "homeDashboardDataValue";
}

RSDHome.doDashboardListRollover = function ( element )
{
    element.className = "homeDashboardDataValueOver";
}

RSDHome.doDashboardListRollout = function ( element )
{
    element.className = "";
}

RSDHome.fillSubnetStatus = function()
{
    OrionCore.doAsyncAction("/rsd/fillSubnetStatus.do", [], RSDHome.fillSubnetStatusSuccess, RSDHome.fillSubnetStatusFailure);
}

RSDHome.fillSubnetStatusSuccess = function(xmlstr)
{
    var xmldoc = OrionCore.getXMLDocument(xmlstr);

    var background = OrionCore.getText(xmldoc.getElementsByTagName("background")[0]);
    var title = OrionCore.getText(xmldoc.getElementsByTagName("title")[0]);
    var text = OrionCore.getText(xmldoc.getElementsByTagName("text")[0]);
    var covered = OrionCore.getText(xmldoc.getElementsByTagName("covered")[0]);
    var uncovered = OrionCore.getText(xmldoc.getElementsByTagName("uncovered")[0]);
    var rogue = OrionCore.getText(xmldoc.getElementsByTagName("rogue")[0]);
    var ignored = OrionCore.getText(xmldoc.getElementsByTagName("ignored")[0]);

    $("rsd.subnetStatusBackground").className = "homeDashboardMessageArea";
    $("rsd.subnetStatusBackground").style.backgroundImage = background;
    $("rsd.subnetStatusText").title = title;
    $("rsd.subnetStatusText").innerHTML = text;
    $("rsd.subnetCoveredValue").innerHTML = covered;
    $("rsd.subnetUncoveredValue").innerHTML = uncovered;
    $("rsd.subnetRogueValue").innerHTML = rogue;
    if (ignored > 0)
    {
        var txt = $("subnet.ignored.sub").innerHTML;
        $("subnet.ignored.link").innerHTML = txt.replace("%cnt%", ignored);;
        $("subnet.ignored.text").style.display = "";
    }
    else
    {
        $("subnet.ignored.text").style.display = "none";
        $("subnet.ignored.link").innerHTML = "";
    }
}

RSDHome.fillSubnetStatusFailure = function (ret, text)
{
    OrionCore.showMessageBox(true, ret+" "+text, OrionCore.DIALOG_OK);
}

RSDHome.fillSystemStatus = function ()
{
    OrionCore.doAsyncAction("/rsd/fillSystemStatus.do", [], RSDHome.fillSystemStatusSuccess, RSDHome.fillSystemStatusFailure);
}

RSDHome.fillSystemStatusSuccess = function(xmlstr)
{
    var xmldoc = OrionCore.getXMLDocument(xmlstr);

    var background = OrionCore.getText(xmldoc.getElementsByTagName("background")[0]);
    var title = OrionCore.getText(xmldoc.getElementsByTagName("title")[0]);
    var text = OrionCore.getText(xmldoc.getElementsByTagName("text")[0]);
    var managed = OrionCore.getText(xmldoc.getElementsByTagName("managed")[0]);
    var rogue = OrionCore.getText(xmldoc.getElementsByTagName("rogue")[0]);
    var exceptions = OrionCore.getText(xmldoc.getElementsByTagName("exceptions")[0]);
    var inactive = OrionCore.getText(xmldoc.getElementsByTagName("inactive")[0]);

    $("rsd.systemStatusBackground").className = "homeDashboardMessageArea";
    $("rsd.systemStatusBackground").style.backgroundImage = background;
    $("rsd.systemStatusText").title = title;
    $("rsd.systemStatusText").innerHTML = text;
    $("rsd.systemManagedValue").innerHTML = managed;
    $("rsd.systemRogueValue").innerHTML = rogue;
    $("rsd.systemExceptionsValue").innerHTML = exceptions;
    $("rsd.systemInactiveValue").innerHTML = inactive;

}

RSDHome.fillSystemStatusFailure = function (ret, text)
{
    OrionCore.showMessageBox(true, ret+" "+text, OrionCore.DIALOG_OK);
}

RSDHome.fillSensorStatus = function ()
{
    OrionCore.doAsyncAction("/rsd/fillSensorStatus.do", [], RSDHome.fillSensorStatusSuccess, RSDHome.fillSensorStatusFailure);
}

RSDHome.fillSensorStatusSuccess = function(xmlstr)
{
    var xmldoc = OrionCore.getXMLDocument(xmlstr);

    var background = OrionCore.getText(xmldoc.getElementsByTagName("background")[0]);
    var title = OrionCore.getText(xmldoc.getElementsByTagName("title")[0]);
    var text = OrionCore.getText(xmldoc.getElementsByTagName("text")[0]);
    var active = OrionCore.getText(xmldoc.getElementsByTagName("active")[0]);
    var passive = OrionCore.getText(xmldoc.getElementsByTagName("passive")[0]);
    var missing = OrionCore.getText(xmldoc.getElementsByTagName("missing")[0]);
    var uninstalled = OrionCore.getText(xmldoc.getElementsByTagName("uninstalled")[0]);

    $("rsd.sensorStatusBackground").className = "homeDashboardMessageArea";
    $("rsd.sensorStatusBackground").style.backgroundImage = background;
    $("rsd.sensorStatusText").title = title;
    $("rsd.sensorStatusText").innerHTML = text;
    $("rsd.sensorActiveValue").innerHTML = active;
    $("rsd.sensorPassiveValue").innerHTML = passive;
    $("rsd.sensorMissingValue").innerHTML = missing;

    if (uninstalled > 0)
    {
        var txt = $("sensor.uninstalled.sub").innerHTML;
        $("sensor.uninstalled.link").innerHTML = txt.replace("%cnt%", uninstalled);;
        $("sensor.uninstalled.text").style.display = "";
    }
    else
    {
        $("sensor.uninstalled.text").style.display = "none";
        $("sensor.uninstalled.link").innerHTML = "";
    }

}

RSDHome.fillSensorStatusFailure = function (ret, text)
{
    OrionCore.showMessageBox(true, ret+" "+text, OrionCore.DIALOG_OK);
}

RSDHome.showCoveredSubnets = function()
{
    OrionCore.showPleaseWait(true);
    OrionCore.doAction("/rsd/subnets.do", ["filterId", "subnets.filter.covered", "filterKey", "subnets.filter.covered.text"]);
}

RSDHome.showUncoveredSubnets = function()
{
    OrionCore.showPleaseWait(true);
    OrionCore.doAction("/rsd/subnets.do", ["filterId", "subnets.filter.uncovered", "filterKey", "subnets.filter.uncovered.text"]);
}

RSDHome.showRogueSubnets = function()
{
    OrionCore.showPleaseWait(true);
    OrionCore.doAction("/rsd/subnets.do", ["filterId", "subnets.filter.rogues", "filterKey", "subnets.filter.rogues.text"]);
}

RSDHome.showIgnoredSubnets = function()
{
    OrionCore.showPleaseWait(true);
    OrionCore.doAction("/rsd/subnets.do", ["filterId", "subnets.filter.ignored", "filterKey", "subnets.filter.ignored.text"]);
}

RSDHome.showActiveSensors = function()
{
    OrionCore.showPleaseWait(true);
    OrionCore.doAction("/rsd/manageSensors.do", ["filterId", "sensor.filter.active", "filterKey", "sensor.filter.active.text"]);
}

RSDHome.showPassiveSensors = function()
{
    OrionCore.showPleaseWait(true);
    OrionCore.doAction("/rsd/manageSensors.do", ["filterId", "sensor.filter.passive", "filterKey", "sensor.filter.passive.text"]);
}

RSDHome.showMissingSensors = function()
{
    OrionCore.showPleaseWait(true);
    OrionCore.doAction("/rsd/manageSensors.do", ["filterId", "sensor.filter.missing", "filterKey", "sensor.filter.missing.text"]);
}

RSDHome.showUninstalledSensors = function()
{
    OrionCore.showPleaseWait(true);
    OrionCore.doAction("/rsd/manageSensors.do", ["filterId", "sensor.filter.uninstalled", "filterKey", "sensor.filter.uninstalled.text"]);
}

RSDHome.showCompliantSystems = function()
{
    OrionCore.showPleaseWait(true);
    OrionCore.doAction("/rsd/showDetectedSystems.do", ["filterId", "detectedsystems.filter.compliant", "filterKey", "detectedsystems.filter.compliant.text"]);
}

RSDHome.showRogueSystems = function()
{
    OrionCore.showPleaseWait(true);
    OrionCore.doAction("/rsd/showDetectedSystems.do", ["filterId", "detectedsystems.filter.rogue", "filterKey", "detectedsystems.filter.rogue.text"]);
}

RSDHome.showInactiveSystems = function()
{
    OrionCore.showPleaseWait(true);
    OrionCore.doAction("/rsd/showDetectedSystems.do", ["filterId", "detectedsystems.filter.inactive", "filterKey", "detectedsystems.filter.inactive.text"]);
}

RSDHome.showManagedSystems = function()
{
    OrionCore.showPleaseWait(true);
    OrionCore.doAction("/rsd/showDetectedSystems.do", ["filterId", "detectedsystems.filter.managed", "filterKey", "detectedsystems.filter.managed.text"]);
}

RSDHome.showExceptionSystems = function()
{
    OrionCore.showPleaseWait(true);
    OrionCore.doAction("/rsd/showDetectedSystems.do", ["filterId", "detectedsystems.filter.exception", "filterKey", "detectedsystems.filter.exception.text"]);
}


RSDHome.configureSubnetDashboard = function()
{
    OrionCore.setDialogBoxTitle("Configure Subnet Dashboard");
    OrionCore.dialogBoxOkHandler = RSDHome.saveSubnetDashboardProperties;
    OrionCore.showAsyncDialogBox(true, "/rsd/configureSubnetDashboard.do", OrionCore.DIALOG_OK_CANCEL);
}

RSDHome.saveSubnetDashboardProperties = function()
{
    var good = $("rsd.subnet.dashboard.properties.good").value;
    var ok = $("rsd.subnet.dashboard.properties.ok").value;

    OrionCore.doAsyncAction("/rsd/saveSubnetDashboard.do", ["subnetGood", good, "subnetOk", ok], RSDHome.saveSubnetDashboardPropertiesSuccess, RSDHome.saveSubnetDashboardPropertiesFailed, "POST");
}

RSDHome.validateSubnetValues = function()
{
    var good = $("rsd.subnet.dashboard.properties.good").value;
    var ok = $("rsd.subnet.dashboard.properties.ok").value;

    //TODO: need to validate that "good" is always larger than "ok" - can you dynamically set the min/max on an mfs:numberbox?
}

RSDHome.saveSubnetDashboardPropertiesSuccess = function ( msg, key )
{
    alert("success: " + msg + " : " + key);
}

RSDHome.saveSubnetDashboardPropertiesFailed = function ( msg, key )
{
    alert("failed: " + msg + " : " + key);
}

RSDHome.roguesForSubnetChangeHandler = function()
{
    var table = MFSTable.get("rfsTable");
    var selectionType = table.getSelectionType();
    var exceptionEnabled = false;
    var pushAgentEnabled = false;
    var addToTreeEnabled = false;
    var queryAgentEnabled = false;
    var ignoreSystemEnabled = false;

    if (selectionType == MFSTable.SELECTION_NONE)
    {
        exceptionEnabled = false;
        pushAgentEnabled = false;
        addToTreeEnabled = false;
        queryAgentEnabled = false;
        ignoreSystemEnabled = false;
    }
    else if (selectionType == MFSTable.SELECTION_SINGLE || selectionType == MFSTable.SELECTION_MULTIPLE || MFSTable.SELECTION_INVERT)
    {
        exceptionEnabled = true;
        pushAgentEnabled = true;
        addToTreeEnabled = true;
        queryAgentEnabled = true;
        ignoreSystemEnabled = true;
    }
    else if (selectionType == MFSTable.SELECTION_ALL)
    {
        exceptionEnabled = true;
        pushAgentEnabled = false;
        addToTreeEnabled = false;
        queryAgentEnabled = false;
        ignoreSystemEnabled = false;
    }

    if ($("rsd.mark.exception.button"))
    {
        OrionCore.setEnabledById("rsd.mark.exception.button", exceptionEnabled);
    }
    if ($("rsd.push.agent.button"))
    {
        OrionCore.setEnabledById("rsd.push.agent.button", pushAgentEnabled);
    }
    if ($("rsd.add.to.tree.button"))
    {
        OrionCore.setEnabledById("rsd.add.to.tree.button", addToTreeEnabled);
    }
    if ($("rsd.delete.system.button"))
    {
        OrionCore.setEnabledById("rsd.delete.system.button", ignoreSystemEnabled);
    }
    if ($("rsd.query.agent.button"))
    {
        OrionCore.setEnabledById("rsd.query.agent.button", queryAgentEnabled);
    }
}

RSDHome.roguesForSubnetRowHandler = function ( uid, index, tableid, datasourceAttr )
{
    OrionCore.showPleaseWait(true);
    var table = MFSTable.get(tableid);
    var rt = table.registeredTypeUID;

    OrionCore.doAction("/rsd/showDetectedSystems.do",
            ["filterId", "detectedsystems.filter.rogue",
             "filterKey", "detectedsystems.filter.rogue.text",
             "UID", uid,
             "index", index - table.viewIndex,
             "absoluteIndex", index,
             "rt", rt,
             "datasourceAttr", datasourceAttr]);
}

RSDHome.ignoreSubnetDialog = function(title)
{
    var snid = OrionList.getSelectedItem("roguesBySubnetList");
    OrionCore.dialogBoxOkHandler = RSDHome.ignoreSubnet;
    OrionCore.setDialogBoxTitle(title);
    OrionCore.showAsyncDialogBox(true, "/rsd/ignoreSubnetDialog.do?snid="+snid, OrionCore.DIALOG_OK_CANCEL);
}

RSDHome.ignoreSubnet = function()
{
    var uid = OrionList.getSelectedItem("roguesBySubnetList");
    OrionCore.doAsyncAction("/rsd/ignoreSubnets.do", ["UIDs", uid], RSDHome.ignoreSubnetSuccess, RSDHome.ignoreSubnetFailure, "POST");
}

RSDHome.ignoreSubnetSuccess = function ( response )
{
    OrionCore.refreshPage(true);
}

RSDHome.ignoreSubnetFailure = function( code, response )
{
    alert("code: " + code + "\n\n" + response);
}


RSDHome.markAsException = function()
{
    OrionCore.showPleaseWait(true);

    var table = MFSTable.get("rfsTable");
    var selectionType = table.getSelectionType(); //OrionTable.getSelectionType("rfsTable");

    if (selectionType == MFSTable.SELECTION_NONE)
    {
        OrionCore.refreshPage(true);
    }
    else if (selectionType == MFSTable.SELECTION_SINGLE || selectionType == MFSTable.SELECTION_MULTIPLE)
    {
        var uids = table.getSelected();

        OrionCore.doAsyncAction("/rsd/markAsException.do", ["UIDs", uids, "selectionType", selectionType], RSDHome.markAsExceptionSuccess, RSDHome.markAsExceptionFailure, "POST");
    }
    else if(selectionType == MFSTable.SELECTION_INVERT)
    {
        var uids = table.getSelected();

        OrionCore.doAsyncAction("/rsd/markAsException.do", ["UIDs", uids, "datasourceAttr", "roguesForSubnetDataSource", "selectionType", selectionType], RSDHome.markAsExceptionSuccess, RSDHome.markAsExceptionFailure, "POST");
    }
    else if (selectionType == MFSTable.SELECTION_ALL)
    {
        OrionCore.doAsyncAction("/rsd/bulkMarkAsException.do", ["datasourceAttr", "roguesForSubnetDataSource", "selectionType", selectionType], RSDHome.markAsExceptionSuccess, RSDHome.markAsExceptionFailure, "POST");
    }
}

RSDHome.markAsExceptionSuccess = function( response )
{
    // TODO: make the covered subnets, compliant systems, sensor health widgets ajax-aware
    // TODO: so I can just update widgets rather than the whole page... Currently that
    // TODO: works fine for the list/table...

    // We really don't care what the response is, the "change" to the list/table
    // is the "response" - this has to reload the whole page because the
    // covered subnets/system status widgets can have different values as well...

    OrionCore.refreshPage(true);
//    OrionList.refresh("roguesBySubnetList", "/rsd/loadRoguesBySubnet.do");
}

RSDHome.markAsExceptionFailure = function( code, response )
{
    alert("code: " + code + "\n\n" + response);
}

RSDHome.pushAgent = function ()
{
    OrionCore.showPleaseWait(true);
    var table = MFSTable.get("rfsTable");
    var selectionType = table.getSelectionType();

    if (selectionType == MFSTable.SELECTION_NONE)
    {
        OrionCore.refreshPage(true);
    }
    else if (selectionType == MFSTable.SELECTION_SINGLE || selectionType == MFSTable.SELECTION_MULTIPLE || selectionType == MFSTable.SELECTION_INVERT)
    {
        var uids = table.getSelected();

        OrionCore.doAction("/rsd/prepareToPushAgent.do", ["UIDs", uids, "datasourceAttr", "roguesForSubnetDataSource", "selectionType", selectionType]);
    }
    else if (selectionType == MFSTable.SELECTION_ALL)
    {
        OrionCore.showAsyncDialogBox(true, "/rsd/pushAgentDatasourceFailure.do", OrionCore.DIALOG_OK);
    }
}

RSDHome.addToTree = function ()
{
    OrionCore.showPleaseWait(true);

    var table = MFSTable.get("rfsTable");
    var selectionType = table.getSelectionType();

    if (selectionType == MFSTable.SELECTION_NONE)
    {
        OrionCore.refreshPage(true);
    }
    else if (selectionType == MFSTable.SELECTION_SINGLE || selectionType == MFSTable.SELECTION_MULTIPLE || selectionType == MFSTable.SELECTION_INVERT)
    {
        var uids = table.getSelected();

        OrionCore.doAction("/rsd/prepareAddToTree.do", ["UIDs", uids, "datasourceAttr", "roguesForSubnetDataSource"]);
    }
    else if (selectionType == MFSTable.SELECTION_ALL)
    {
        //        OrionCore.showAsyncDialogBox(true, "/rsd/pushAgentDatasourceFailure.do", OrionCore.DIALOG_OK);
    }
}

RSDHome.queryAgent = function ()
{
    OrionCore.showPleaseWait(true);

    var table = MFSTable.get("rfsTable");
    var selectionType = table.getSelectionType();

    if (selectionType == MFSTable.SELECTION_NONE)
    {
        OrionCore.refreshPage(true);
    }
    else if (selectionType == MFSTable.SELECTION_SINGLE || selectionType == MFSTable.SELECTION_MULTIPLE || selectionType == MFSTable.SELECTION_INVERT)
    {
        var uids = table.getSelected();

        OrionCore.doAction("/rsd/queryAgent.do", ["UIDs", uids, "datasourceAttr", "roguesForSubnetDataSource"]);
    }
    else if (selectionType == MFSTable.SELECTION_ALL)
    {
        OrionCore.showAsyncDialogBox(true, "/rsd/pushAgentDatasourceFailure.do", OrionCore.DIALOG_OK);
    }
}


RSDHome.showSensorBlacklist = function ()
{
    OrionCore.showPleaseWait(true);
    OrionCore.doAction("/rsd/showBlacklist.do")
}


RSDHome.addSubnet = function ()
{
    OrionCore.doAction("/rsd/showAddSubnet.do");
}


RSDHome.showDetailStats = function ()
{
    OrionCore.doAction("/rsd/showDetailStats.do");
}


RSDHome.importExportExceptions = function ()
{
    OrionCore.doAction("/rsd/displayExceptions.do");
}



