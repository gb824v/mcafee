-- Bug 711259 - Recreate EPONotificationProcessed. This needs to be done for all upgrade
-- scenario.
IF NOT EXISTS (SELECT * FROM EPONotificationProcessed WHERE [Type] = 'rsdAddDetectedSystemEvent')
    INSERT INTO EPONotificationProcessed ([Type])
        VALUES (N'rsdAddDetectedSystemEvent');
GO
