-- unnstall-poc901126.sql
--
-- Copyright (c) 2013 McAfee Security Inc.
-- All rights reserved.

--------------------------------------------------------------------------------
-- Restore prior versions of RSD matching algorithm procedures
--------------------------------------------------------------------------------

-- restore RSD 4.7.X version.
IF EXISTS(SELECT * FROM sys.objects where object_id = OBJECT_ID(N'[dbo].[RSDSP_MatchManagedSystems]'))
    DROP PROCEDURE [dbo].[RSDSP_MatchManagedSystems];
GO
CREATE PROCEDURE [dbo].[RSDSP_MatchManagedSystems]
(
	@HostID				int,
    @AgentGUID          uniqueidentifier,
    @MAC                nvarchar(12),
    @ComputerName       nvarchar(16),
    @Domain             nvarchar(255),
    @DnsName            nvarchar(255),
    @IPV4               int,
    @IPV6               binary (16),
    @DetectionType      nvarchar(255)
)
AS
BEGIN
    declare @managedMatching    int;

    -- The Configuration ID by default should always be 1
    select @managedMatching = [RSDConfiguration].[ManagedMatching]
        from [dbo].[RSDConfiguration]
        where [RSDConfiguration].[ID] = 1;

    declare @useAgentGUID       bit;
    declare @useProductGUID     bit;
    declare @useMAC             bit;
    declare @useHostnameDomain  bit;
    declare @useDNSName         bit;
    declare @useIPAddress       bit;
    declare @useHostname        bit;

    set @useAgentGUID = @managedMatching & 0x1;
    set @useProductGUID = @managedMatching & 0x2;
    set @useMAC = @managedMatching & 0x10;
    set @useHostnameDomain = @managedMatching & 0x20;
    set @useDNSName = @managedMatching & 0x40;
    set @useIPAddress = @managedMatching & 0x80;
    set @useHostname = @managedMatching & 0x100;

    declare @m_AgentGUID          uniqueidentifier;

    declare @found bit;
	declare @cnt int;
	declare @done bit;
	declare @results table (
		LeafNodeID		int,
		AgentGUID       uniqueidentifier,
		MAC             nvarchar(100),
		ComputerName    nvarchar(255),
		Domain          nvarchar(255),
		DnsName         nvarchar(255),
		IPV4            int,
		IPV6            binary (16)
	);

    set @found = 0;
	set @done = 0;
	set @cnt = 0;

    if (@AgentGUID is not null and @useAgentGUID = 1)
    begin

		insert into @results (LeafNodeID, AgentGUID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6)
			select [EPOLeafNode].[AutoID],
				   @AgentGUID,
				   [EPOComputerProperties].[NetAddress],
				   [EPOComputerProperties].[ComputerName],
				   [EPOComputerProperties].[DomainName],
				   [EPOComputerProperties].[IPHostName],
				   [dbo].[RSDFN_ConvertIPV6BinaryToInt]([EPOComputerProperties].[IPV6]),
				   [EPOComputerProperties].[IPV6]
			from [EPOLeafNode] WITH (NOLOCK)
				inner join [EPOComputerProperties] WITH (NOLOCK)
				on [EPOLeafNode].[AutoID] = [EPOComputerProperties].[ParentID]
			where [EPOLeafNode].[AgentGUID] = @AgentGUID
					AND ((@DetectionType is null OR @DetectionType = N'detectedSystem') AND
						[EPOComputerProperties].[ManagementType] is null
					)
					OR
					(@DetectionType is NOT null AND
						[EPOComputerProperties].[ManagementType] = @DetectionType
					);

		select @cnt = count(*) from @results;
		if (@cnt = 1)
		begin
            set @done = 1;
			set @m_AgentGUID = @AgentGUID;
		end

		-- In this case, we have already associated the AgentGUID to a ManagedSystem, so we're good
		-- unless we decide we want to update the DetectedSystem entry with known values from the ManagedSystem
		-- If more than one AgentGUID matches, we've got other problems...
    end

	if (@done = 0 and @MAC is not null and @useMAC = 1)
	begin
		if (@found = 0)
		begin
		    set @MAC = upper(@MAC);

			insert into @results (LeafNodeID, AgentGUID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6)
				select [EPOLeafNode].[AutoID],
					   [EPOLeafNode].[AgentGUID],
					   [EPOComputerProperties].[NetAddress],
					   [EPOComputerProperties].[ComputerName],
					   [EPOComputerProperties].[DomainName],
					   [EPOComputerProperties].[IPHostName],
    				   [dbo].[RSDFN_ConvertIPV6BinaryToInt]([EPOComputerProperties].[IPV6]),
					   [EPOComputerProperties].[IPV6]
				from [EPOLeafNode] WITH (NOLOCK)
					inner join [EPOComputerProperties] WITH (NOLOCK)
					on [EPOLeafNode].[AutoID] = [EPOComputerProperties].[ParentID]
				where upper([dbo].[EPOComputerProperties].[NetAddress]) = @MAC
					AND ((@DetectionType is null OR @DetectionType = N'detectedSystem') AND
						[EPOComputerProperties].[ManagementType] is null
					)
					OR
					(@DetectionType is NOT null AND
						[EPOComputerProperties].[ManagementType] = @DetectionType
					);

			select @cnt = count(*) from @results;

			if (@cnt = 1)
			begin
				set @done = 1;
				select @m_AgentGUID = AgentGUID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		-- Since this is the first possible case, there is no "else" here...
	end

	if (@done = 0 and @ComputerName is not null and @Domain is not null and @useHostnameDomain = 1)
	begin
		if (@found = 0)
		begin
			insert into @results (LeafNodeID, AgentGUID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6)
				select [EPOLeafNode].[AutoID],
					   [EPOLeafNode].[AgentGUID],
					   [EPOComputerProperties].[NetAddress],
					   [EPOComputerProperties].[ComputerName],
					   [EPOComputerProperties].[DomainName],
					   [EPOComputerProperties].[IPHostName],
    				   [dbo].[RSDFN_ConvertIPV6BinaryToInt]([EPOComputerProperties].[IPV6]),
					   [EPOComputerProperties].[IPV6]
				from [EPOLeafNode] WITH (NOLOCK)
					inner join [EPOComputerProperties] WITH (NOLOCK)
					on [EPOLeafNode].[AutoID] = [EPOComputerProperties].[ParentID]
				where [dbo].[EPOComputerProperties].[ComputerName] = @ComputerName
					and [dbo].[EPOComputerProperties].[DomainName] = @Domain
					AND ((@DetectionType is null OR @DetectionType = N'detectedSystem') AND
						[EPOComputerProperties].[ManagementType] is null
					)
					OR
					(@DetectionType is NOT null AND
						[EPOComputerProperties].[ManagementType] = @DetectionType
					);

			select @cnt = count(*) from @results;
			if (@cnt = 1)
			begin
				set @done = 1;
				select @m_AgentGUID = AgentGUID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		else
		begin
			delete R from @results as R where R.ComputerName <> @ComputerName and R.Domain <> @Domain;

			select @cnt = count(*) from @results;

			if (@cnt = 0)
			begin
				set @done = 1;
			end
			if (@cnt = 1)
			begin
				set @done = 1;
				select @m_AgentGUID = AgentGUID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
	end

	if (@done = 0 and @DnsName is not null and @useDNSName = 1)
	begin
		-- If we haven't found anything yet, insert this new selection into the DB
		if (@found = 0)
		begin
			insert into @results (LeafNodeID, AgentGUID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6)
				select [EPOLeafNode].[AutoID],
					   [EPOLeafNode].[AgentGUID],
					   [EPOComputerProperties].[NetAddress],
					   [EPOComputerProperties].[ComputerName],
					   [EPOComputerProperties].[DomainName],
					   [EPOComputerProperties].[IPHostName],
    				   [dbo].[RSDFN_ConvertIPV6BinaryToInt]([EPOComputerProperties].[IPV6]),
					   [EPOComputerProperties].[IPV6]
				from [EPOLeafNode] WITH (NOLOCK)
					inner join [EPOComputerProperties] WITH (NOLOCK)
					on [EPOLeafNode].[AutoID] = [EPOComputerProperties].[ParentID]
				where [dbo].[EPOComputerProperties].[IPHostName] = @DnsName
					AND ((@DetectionType is null OR @DetectionType = N'detectedSystem') AND
						[EPOComputerProperties].[ManagementType] is null
					)
					OR
					(@DetectionType is NOT null AND
						[EPOComputerProperties].[ManagementType] = @DetectionType
					);

			select @cnt = count(*) from @results;
			if (@cnt = 1)
			begin
				set @done = 1;
				select @m_AgentGUID = AgentGUID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		else
		begin
			delete R from @results as R where R.DnsName <> @DnsName;

			select @cnt = count(*) from @results;

			if (@cnt = 0)
			begin
				set @done = 1;
			end
			if (@cnt = 1)
			begin
				set @done = 1;
				select @m_AgentGUID = AgentGUID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
	end

	-- This is the IP Address check, it's gonna be a little nasty...
	if (@done = 0 and ( @IPV4 is not null or @IPV6 is not null) and @useIPAddress = 1)
	begin
		-- convert IPV4 to IPV6 so we can just use a single algorithm :)
		declare @ipaddr binary(16);
		if (@IPV4 is not null)
		begin
			set @ipaddr = [dbo].[RSDFN_ConvertIntToIPV6Binary](@IPV4);
		end
		else
		begin
			set @ipaddr = @IPV6;
		end

		-- We only want to do anything if this IPAddress falls in the correct range
		if ([dbo].[RSDFN_IsInRSDConfigurationIPRange](@ipaddr) = 1)
		begin
			if (@found = 0)
			begin
				if (@IPV4 is not null)
				begin
					insert into @results (LeafNodeID, AgentGUID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6)
						select [EPOLeafNode].[AutoID],
							   [EPOLeafNode].[AgentGUID],
							   [EPOComputerProperties].[NetAddress],
							   [EPOComputerProperties].[ComputerName],
							   [EPOComputerProperties].[DomainName],
							   [EPOComputerProperties].[IPHostName],
            				   [dbo].[RSDFN_ConvertIPV6BinaryToInt]([EPOComputerProperties].[IPV6]),
							   [EPOComputerProperties].[IPV6]
						from [EPOLeafNode] WITH (NOLOCK)
							inner join [EPOComputerProperties] WITH (NOLOCK)
							on [EPOLeafNode].[AutoID] = [EPOComputerProperties].[ParentID]
						where [dbo].[EPOComputerProperties].[IPV6] = [dbo].[RSDFN_ConvertIntToIPV6Binary](@IPV4)
							AND ((@DetectionType is null OR @DetectionType = N'detectedSystem') AND
								[EPOComputerProperties].[ManagementType] is null
							)
							OR
							(@DetectionType is NOT null AND
								[EPOComputerProperties].[ManagementType] = @DetectionType
							);
				end
				else
				begin
					insert into @results (LeafNodeID, AgentGUID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6)
						select [EPOLeafNode].[AutoID],
							   [EPOLeafNode].[AgentGUID],
							   [EPOComputerProperties].[NetAddress],
							   [EPOComputerProperties].[ComputerName],
							   [EPOComputerProperties].[DomainName],
							   [EPOComputerProperties].[IPHostName],
            				   [dbo].[RSDFN_ConvertIPV6BinaryToInt]([EPOComputerProperties].[IPV6]),
							   [EPOComputerProperties].[IPV6]
					from [EPOLeafNode] WITH (NOLOCK)
						inner join [EPOComputerProperties] WITH (NOLOCK)
						on [EPOLeafNode].[AutoID] = [EPOComputerProperties].[ParentID]
						where [dbo].[EPOComputerProperties].[IPV6] = @IPV6
							AND ((@DetectionType is null OR @DetectionType = N'detectedSystem') AND
								[EPOComputerProperties].[ManagementType] is null
							)
							OR
							(@DetectionType is NOT null AND
								[EPOComputerProperties].[ManagementType] = @DetectionType
							);
				end

				select @cnt = count(*) from @results;
				if (@cnt = 1)
				begin
					set @done = 1;
					select @m_AgentGUID = AgentGUID from @results;
				end
				if (@cnt > 1)
				begin
					set @found = 1;
				end
			end
			else
			begin
				-- If this is IPV4, remove the IPV4 elements...
				if (@IPV4 is not null)
				begin
					delete R from @results as R where R.IPV4 <> @IPV4;
				end
				else
				begin
					delete R from @results as R where R.IPV6 <> @IPV6;
				end

    			select @cnt = count(*) from @results;
				if (@cnt = 0)
				begin
					set @done = 1;
				end
				if (@cnt = 1)
				begin
					set @done = 1;
					select @m_AgentGUID = AgentGUID from @results;
				end
				if (@cnt > 1)
				begin
					set @found = 1;
				end
			end
		end
	end

	-- Check for Hostname only!
	if (@done = 0 and @ComputerName is not null and @useHostname = 1)
	begin
		-- If we haven't found anything yet, insert this new selection into the DB
		if (@found = 0)
		begin
			insert into @results (LeafNodeID, AgentGUID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6)
				select [EPOLeafNode].[AutoID],
					   [EPOLeafNode].[AgentGUID],
					   [EPOComputerProperties].[NetAddress],
					   [EPOComputerProperties].[ComputerName],
					   [EPOComputerProperties].[DomainName],
					   [EPOComputerProperties].[IPHostName],
    				   [dbo].[RSDFN_ConvertIPV6BinaryToInt]([EPOComputerProperties].[IPV6]),
					   [EPOComputerProperties].[IPV6]
				from [EPOLeafNode] WITH (NOLOCK)
					inner join [EPOComputerProperties] WITH (NOLOCK)
					on [EPOLeafNode].[AutoID] = [EPOComputerProperties].[ParentID]
				where [dbo].[EPOComputerProperties].[ComputerName] = @ComputerName
					AND ((@DetectionType is null OR @DetectionType = N'detectedSystem') AND
						[EPOComputerProperties].[ManagementType] is null
					)
					OR
					(@DetectionType is NOT null AND
						[EPOComputerProperties].[ManagementType] = @DetectionType
					);

			select @cnt = count(*) from @results;
			if (@cnt = 1)
			begin
				set @done = 1;
				select @m_AgentGUID = AgentGUID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		else
		begin
			delete R from @results as R where R.ComputerName <> @ComputerName;
			select @cnt = count(*) from @results;

			if (@cnt = 0)
			begin
				set @done = 1;
			end
			if (@cnt = 1)
			begin
				set @done = 1;
				select @m_AgentGUID = AgentGUID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
	end


	if (@done = 1 and @m_AgentGUID is not null)
	begin
		update [dbo].[RSDDetectedSystemProperties]
		set AgentGUID = @m_AgentGUID, RogueAction = 0
		where HostID = @HostID
		and (AgentGUID is null OR AgentGUID <> @m_AgentGUID OR RogueAction is null OR RogueAction <> 0);
	end
END
GO

-- restore RSD 4.7.X version.
IF EXISTS(SELECT * FROM sys.objects where object_id = OBJECT_ID(N'[dbo].[RSDSP_MatchDetectedSystems]'))
    DROP PROCEDURE [dbo].[RSDSP_MatchDetectedSystems];
GO
CREATE PROCEDURE [dbo].[RSDSP_MatchDetectedSystems]
(
    @AgentGUID					uniqueidentifier,
	@SourceID					int,
	@SourceType					nvarchar(100),
	@ExternalID					nvarchar(1000),
    @MAC						nvarchar(12),
    @ComputerName				nvarchar(16),
    @Domain						nvarchar(255),
    @DnsName					nvarchar(255),
    @IPV4						int,
    @IPV6						binary (16),
    @DetectionType              nvarchar(255),
    @MatchingOverride	        int,
	@HostID						int output
)
AS
BEGIN
    declare @detectedMatching    int;

    -- The Configuration ID by default should always be 1
    if(@MatchingOverride > 0)
		set @detectedMatching = @MatchingOverride
	else
	begin
		select @detectedMatching = [RSDConfiguration].[DetectedMatching]
			from [dbo].[RSDConfiguration]
			where [RSDConfiguration].[ID] = 1;
	end

    declare @useAgentGUID       bit;
    declare @useProductGUID     bit;
    declare @useMAC             bit;
    declare @useHostnameDomain  bit;
    declare @useDNSName         bit;
    declare @useIPAddress       bit;
    declare @useHostname        bit;

    set @useAgentGUID = @detectedMatching & 0x1;
    set @useProductGUID = @detectedMatching & 0x2;
    set @useMAC = @detectedMatching & 0x10;
    set @useHostnameDomain = @detectedMatching & 0x20;
    set @useDNSName = @detectedMatching & 0x40;
    set @useIPAddress = @detectedMatching & 0x80;
    set @useHostname = @detectedMatching & 0x100;

    declare @found bit;
	declare @done bit;
	declare @cnt int;
	declare @results table (
		HostID				int,
		AgentGUID		    uniqueidentifier,
		SourceID			int,
		SourceType			nvarchar(100),
		ExternalID			nvarchar(1000),
		MAC					nvarchar(12),
		ComputerName		nvarchar(16),
		Domain				nvarchar(255),
		DnsName				nvarchar(255),
		IPV4				int,
		IPV6				binary (16),
		LastDetectedTime	datetime
	);

    set @found = 0;
	set @done = 0;
	set @cnt = 0;

	-- Check for a match on the agent guid
    if (@AgentGUID is not null and @useAgentGUID = 1)
    begin
		insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
			select [RSDDetectedSystemProperties].[HostID],
				   [RSDDetectedSystemProperties].[AgentGUID],
				   [RSDDetectedSource].[SourceID],
				   [RSDDetectedSource].[SourceType],
				   [RSDDetectedSource].[ExternalID],
				   [RSDInterfaceProperties].[MAC],
				   [RSDDetectedSystemProperties].[NetbiosName],
				   [RSDDetectedSystemProperties].[Domain],
				   [RSDDetectedSystemProperties].[DnsName],
				   [RSDInterfaceProperties].[IPV4],
				   [RSDInterfaceProperties].[IPV6],
				   [RSDDetectedSystemProperties].[LastDetectedTime]
			from [RSDDetectedSystemProperties] WITH (NOLOCK)
				 inner join [RSDInterfaceProperties] WITH (NOLOCK)
					on [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
				 inner join [RSDDetectedSource] WITH (NOLOCK)
					on [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
			where [RSDDetectedSystemProperties].[AgentGUID] = @AgentGUID
			    and [RSDDetectedSystemProperties].[DetectionType] = @DetectionType;

		select @cnt = count(*) from @results;
		if (@cnt = 1)
		begin
			select @HostID = HostID from @results;
			set @done = 1;
		end
		if (@cnt > 1)
		begin
			set @found = 1;
		end
    end

	-- Like AgentGUID - this should uniquely identify a single system, if not, then we fall through to the user
	-- defined selections
	if (@done = 0 and @SourceType is not null and @ExternalID is not null and @useProductGUID = 1)
	begin
		insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
			select [RSDDetectedSystemProperties].[HostID],
				   [RSDDetectedSystemProperties].[AgentGUID],
				   [RSDDetectedSource].[SourceID],
				   [RSDDetectedSource].[SourceType],
				   [RSDDetectedSource].[ExternalID],
				   [RSDInterfaceProperties].[MAC],
				   [RSDDetectedSystemProperties].[NetbiosName],
				   [RSDDetectedSystemProperties].[Domain],
				   [RSDDetectedSystemProperties].[DnsName],
				   [RSDInterfaceProperties].[IPV4],
				   [RSDInterfaceProperties].[IPV6],
				   [RSDDetectedSystemProperties].[LastDetectedTime]
			from [RSDDetectedSystemProperties] WITH (NOLOCK)
				 inner join [RSDInterfaceProperties] WITH (NOLOCK)
					on [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
				 inner join [RSDDetectedSource] WITH (NOLOCK)
					on [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
			where [RSDDetectedSource].[SourceType] = @SourceType
				and [RSDDetectedSource].[ExternalID] = @ExternalID
				and [RSDDetectedSystemProperties].[DetectionType] = @DetectionType;


		select @cnt = count(*) from @results;
		if (@cnt = 1)
		begin
			set @done = 1;
			select @HostID = HostID from @results;
		end
		if (@cnt > 1)
		begin
			set @found = 1;
		end
	end


	-- Check for a match on the MAC address...
	if (@done = 0 and @MAC is not null and @useMAC = 1)
	begin
		if (@found = 0)
		begin
			insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
				select [RSDDetectedSystemProperties].[HostID],
					   [RSDDetectedSystemProperties].[AgentGUID],
					   [RSDDetectedSource].[SourceID],
					   [RSDDetectedSource].[SourceType],
					   [RSDDetectedSource].[ExternalID],
					   [RSDInterfaceProperties].[MAC],
					   [RSDDetectedSystemProperties].[NetbiosName],
					   [RSDDetectedSystemProperties].[Domain],
					   [RSDDetectedSystemProperties].[DnsName],
					   [RSDInterfaceProperties].[IPV4],
					   [RSDInterfaceProperties].[IPV6],
					   [RSDDetectedSystemProperties].[LastDetectedTime]
				from [RSDDetectedSystemProperties] WITH (NOLOCK)
					 inner join [RSDInterfaceProperties] WITH (NOLOCK)
						on [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
					 inner join [RSDDetectedSource] WITH (NOLOCK)
						on [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
				where [RSDInterfaceProperties].[MAC] = @MAC
				    and [RSDDetectedSystemProperties].[DetectionType] = @DetectionType;

			select @cnt = count(*) from @results;
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		else
		begin
			-- need to get the most recent, in case we drop to 0 in our count...
			select @HostID = HostID from @results order by LastDetectedTime desc;

			delete R from @results as R  where MAC <> @MAC;

			select @cnt = count(*) from @results;
			if (@cnt = 0)
			begin
				-- use the host that was most recently detected
				set @done = 1;
			end
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end

		end
	end

	-- Next, do the ComputerName/Domain pair
	if (@done = 0 and @ComputerName is not null and @Domain is not null and @useHostnameDomain = 1)
	begin
		if (@found = 0)
		begin
			insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
				select [RSDDetectedSystemProperties].[HostID],
					   [RSDDetectedSystemProperties].[AgentGUID],
					   [RSDDetectedSource].[SourceID],
					   [RSDDetectedSource].[SourceType],
					   [RSDDetectedSource].[ExternalID],
					   [RSDInterfaceProperties].[MAC],
					   [RSDDetectedSystemProperties].[NetbiosName],
					   [RSDDetectedSystemProperties].[Domain],
					   [RSDDetectedSystemProperties].[DnsName],
					   [RSDInterfaceProperties].[IPV4],
					   [RSDInterfaceProperties].[IPV6],
					   [RSDDetectedSystemProperties].[LastDetectedTime]
				from [RSDDetectedSystemProperties] WITH (NOLOCK)
					 inner join [RSDInterfaceProperties] WITH (NOLOCK)
						on [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
					 inner join [RSDDetectedSource] WITH (NOLOCK)
						on [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
				where [RSDDetectedSystemProperties].[NetbiosName] = @ComputerName
					and [RSDDetectedSystemProperties].[Domain] = @Domain
					and [RSDDetectedSystemProperties].[DetectionType] = @DetectionType;

			select @cnt = count(*) from @results;
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		else
		begin
			-- need to get the most recent, in case we drop to 0 in our count...
			select @HostID = HostID from @results order by LastDetectedTime desc;

			delete R from @results as R  where ComputerName <> @ComputerName and Domain <> @Domain;

			select @cnt = count(*) from @results;
			if (@cnt = 0)
			begin
				-- use the host that was most recently detected
				set @done = 1;
			end
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end

		end
	end

	-- Use DNS name
	if (@done = 0 and @DnsName is not null and @useDNSName = 1)
	begin
		if (@found = 0)
		begin
			insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
				select [RSDDetectedSystemProperties].[HostID],
					   [RSDDetectedSystemProperties].[AgentGUID],
					   [RSDDetectedSource].[SourceID],
					   [RSDDetectedSource].[SourceType],
					   [RSDDetectedSource].[ExternalID],
					   [RSDInterfaceProperties].[MAC],
					   [RSDDetectedSystemProperties].[NetbiosName],
					   [RSDDetectedSystemProperties].[Domain],
					   [RSDDetectedSystemProperties].[DnsName],
					   [RSDInterfaceProperties].[IPV4],
					   [RSDInterfaceProperties].[IPV6],
					   [RSDDetectedSystemProperties].[LastDetectedTime]
				from [RSDDetectedSystemProperties] WITH (NOLOCK)
					 inner join [RSDInterfaceProperties] WITH (NOLOCK)
						on [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
					 inner join [RSDDetectedSource] WITH (NOLOCK)
						on [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
				where [RSDDetectedSystemProperties].[DnsName] = @DnsName
				    and [RSDDetectedSystemProperties].[DetectionType] = @DetectionType;

			select @cnt = count(*) from @results;
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		else
		begin
			-- need to get the most recent, in case we drop to 0 in our count...
			select @HostID = HostID from @results order by LastDetectedTime desc;

			delete R from @results as R where DnsName <> @DnsName;

			select @cnt = count(*) from @results;
			if (@cnt = 0)
			begin
				-- use the host that was most recently detected
				set @done = 1;
			end
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end

		end
	end

	-- This is the IP Address check, it's gonna be a little nasty...
	if (@done = 0 and ( @IPV4 is not null or @IPV6 is not null) and @useIPAddress = 1)
	begin
		-- convert IPV4 to IPV6 so we can just use a single algorithm :)
		declare @ipaddr binary(16);
		if (@IPV4 is not null)
		begin
			set @ipaddr = [dbo].[RSDFN_ConvertIntToIPV6Binary](@IPV4);
		end
		else
		begin
			set @ipaddr = @IPV6;
		end

		-- We only want to do anything if this IPAddress falls in the correct range
		if ([dbo].[RSDFN_IsInRSDConfigurationIPRange](@ipaddr) = 1)
		begin
			if (@found = 0)
			begin
				if (@IPV4 is not null)
				begin
                    insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
                        select [RSDDetectedSystemProperties].[HostID],
                               [RSDDetectedSystemProperties].[AgentGUID],
                               [RSDDetectedSource].[SourceID],
                               [RSDDetectedSource].[SourceType],
                               [RSDDetectedSource].[ExternalID],
                               [RSDInterfaceProperties].[MAC],
                               [RSDDetectedSystemProperties].[NetbiosName],
                               [RSDDetectedSystemProperties].[Domain],
                               [RSDDetectedSystemProperties].[DnsName],
                               [RSDInterfaceProperties].[IPV4],
                               [RSDInterfaceProperties].[IPV6],
                               [RSDDetectedSystemProperties].[LastDetectedTime]
						from [RSDDetectedSystemProperties] WITH (NOLOCK)
							 inner join [RSDInterfaceProperties] WITH (NOLOCK)
								on [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
							 inner join [RSDDetectedSource] WITH (NOLOCK)
								on [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
						where [RSDInterfaceProperties].[IPV4] = @IPV4
						    and [RSDDetectedSystemProperties].[DetectionType] = @DetectionType;

				end
				else
				begin
                    insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
                        select [RSDDetectedSystemProperties].[HostID],
                               [RSDDetectedSystemProperties].[AgentGUID],
                               [RSDDetectedSource].[SourceID],
                               [RSDDetectedSource].[SourceType],
                               [RSDDetectedSource].[ExternalID],
                               [RSDInterfaceProperties].[MAC],
                               [RSDDetectedSystemProperties].[NetbiosName],
                               [RSDDetectedSystemProperties].[Domain],
                               [RSDDetectedSystemProperties].[DnsName],
                               [RSDInterfaceProperties].[IPV4],
                               [RSDInterfaceProperties].[IPV6],
                               [RSDDetectedSystemProperties].[LastDetectedTime]
						from [RSDDetectedSystemProperties] WITH (NOLOCK)
							 inner join [RSDInterfaceProperties] WITH (NOLOCK)
								on [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
							 inner join [RSDDetectedSource] WITH (NOLOCK)
								on [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
						where [RSDInterfaceProperties].[IPV6] = @IPV6
						    and [RSDDetectedSystemProperties].[DetectionType] = @DetectionType;
				end

                select @cnt = count(*) from @results;
                if (@cnt = 1)
                begin
                    set @done = 1;
                    select @HostID = HostID from @results;
                end
                if (@cnt > 1)
                begin
                    set @found = 1;
                end
			end
			else
			begin
                -- need to get the most recent, in case we drop to 0 in our count...
                select @HostID = HostID from @results order by LastDetectedTime desc;

				-- If this is IPV4, remove the IPV4 elements...
				if (@IPV4 is not null)
				begin
					delete R from @results as R where R.IPV4 <> @IPV4;
				end
				else
				begin
					delete R from @results as R where R.IPV6 <> @IPV6;
				end

                select @cnt = count(*) from @results;
                if (@cnt = 0)
                begin
                    -- use the host that was most recently detected
                    set @done = 1;
                end
                if (@cnt = 1)
                begin
                    set @done = 1;
                    select @HostID = HostID from @results;
                end
                if (@cnt > 1)
                begin
                    set @found = 1;
                end

			end
		end
	end

	-- Check for Hostname only!
	if (@done = 0 and @ComputerName is not null and @useHostname = 1)
	begin
		if (@found = 0)
		begin
			insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
				select [RSDDetectedSystemProperties].[HostID],
					   [RSDDetectedSystemProperties].[AgentGUID],
					   [RSDDetectedSource].[SourceID],
					   [RSDDetectedSource].[SourceType],
					   [RSDDetectedSource].[ExternalID],
					   [RSDInterfaceProperties].[MAC],
					   [RSDDetectedSystemProperties].[NetbiosName],
					   [RSDDetectedSystemProperties].[Domain],
					   [RSDDetectedSystemProperties].[DnsName],
					   [RSDInterfaceProperties].[IPV4],
					   [RSDInterfaceProperties].[IPV6],
					   [RSDDetectedSystemProperties].[LastDetectedTime]
				from [RSDDetectedSystemProperties] WITH (NOLOCK)
					 inner join [RSDInterfaceProperties] WITH (NOLOCK)
						on [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
					 inner join [RSDDetectedSource] WITH (NOLOCK)
						on [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
				where [RSDDetectedSystemProperties].[NetbiosName] = @ComputerName
				    and [RSDDetectedSystemProperties].[DetectionType] = @DetectionType;


			select @cnt = count(*) from @results;
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		else
		begin
			-- need to get the most recent, in case we drop to 0 in our count...
			select @HostID = HostID from @results order by LastDetectedTime desc;

			delete R from @results as R  where ComputerName <> @ComputerName;

			select @cnt = count(*) from @results;
			if (@cnt = 0)
			begin
				-- use the host that was most recently detected
				set @done = 1;
			end
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end

		end
	end

	-- If we never were able to narrow it down to just one, return the most recently detected host from our temp table
	if (@done = 0 and @cnt > 1)
	begin
		select @HostID = HostID from @results order by LastDetectedTime desc;
	end
END
GO

/****** Object:  StoredProcedure [dbo].[RSDSP_GetNewDetectedSystemEvents]    Script Date: 10/02/2013 13:28:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RSDSP_GetNewDetectedSystemEvents]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[RSDSP_GetNewDetectedSystemEvents]
GO


/****** Object:  StoredProcedure [dbo].[RSDSP_GetNewDetectedSystemEvents]    Script Date: 10/02/2013 13:28:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[RSDSP_GetNewDetectedSystemEvents]
(
	@WhereClause	ntext
)
AS
BEGIN
	SET NOCOUNT ON;

    -- Create the Where clause for the timestamp, so we're only pulling events we haven't processed yet...
    declare @WhereTime nvarchar(128);
	set @WhereTime = 'RecordedTime > (select LastProcessedUTC from [dbo].[EPONotificationProcessed] where [Type] = N''rsdAddDetectedSystemEvent'')';

	-- If the where clause is null, then we must want all the events since the last time
	-- the Notification Threat Event triggered...  So, just get ALL events
	declare @LastProcessed datetime;
	set @LastProcessed = GETUTCDATE();
	if (@WhereClause is null)
	begin
		exec ('select HostID, DnsName, OSPlatform, OSFamily, OSVersion, Domain, NetbiosName, NetbiosComment, Users, [RSDDetectedSystems].AgentGUID,
		    FriendlyName, Ignored, Comments, IPV4, IPV6, MAC, Exception, RogueAction, LastDetectedTime, OrgName, OUI, [RSDDetectedSystems].NewDetection,
		    RogueState, Managed, Rogue, Inactive, DetectedSourceName, LastAgentCommunication, AgentVersion, ServerName, rs.ComputerName as SensorComputerName,
		    rs.SensorName, rs.SensorType, rs.Description as SensorDescription
			from [RSDDetectedSystems] inner join RSDSensors rs on [RSDDetectedSystems].SourceID = rs.SensorID where ' + @WhereTime);
	end
	else
	begin
		exec ('select HostID, DnsName, OSPlatform, OSFamily, OSVersion, Domain, NetbiosName, NetbiosComment, Users, [RSDDetectedSystems].AgentGUID,
		    FriendlyName, Ignored, Comments, IPV4, IPV6, MAC, Exception, RogueAction, LastDetectedTime, OrgName, OUI, [RSDDetectedSystems].NewDetection,
		    RogueState, Managed, Rogue, Inactive, DetectedSourceName, LastAgentCommunication, AgentVersion, ServerName, rs.ComputerName as SensorComputerName,
		    rs.SensorName, rs.SensorType, rs.Description as SensorDescription
			from [RSDDetectedSystems] inner join RSDSensors rs on [RSDDetectedSystems].SourceID = rs.SensorID where (' + @WhereTime + ') and (' + @WhereClause + ')' );
	end

    exec [dbo].[RSDSP_UpdateNewDetectedSystemEventCheck] @LastProcessed;

END
GO