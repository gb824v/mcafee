-- NOTE: The dropping of procs/functions is in the uninstall.sql file

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------
-- Functions
-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------
CREATE FUNCTION [dbo].[RSDFN_ConvertMACToDisplayString]
(
    @mac nvarchar(12)
)
RETURNS NVARCHAR(17)
AS
BEGIN
    set @mac = upper(@mac);
    RETURN substring(@mac, 1, 2) + ':' +
		   substring(@mac, 3, 2) + ':' +
           substring(@mac, 5, 2) + ':' +
		   substring(@mac, 7, 2) + ':' +
		   substring(@mac, 9, 2) + ':' +
           substring(@mac, 11, 2);
END
GO

CREATE FUNCTION [dbo].[RSDFN_ConvertIntToIPString]
(
    @ipin int
)
RETURNS CHAR(15)
AS
BEGIN
	declare @o1 bigint, @o2 bigint, @o3 bigint, @o4 bigint;
	declare @ip bigint;

-- This is the magic epo conversion size...
    set @ip = (CAST(@ipin as bigint) + 2147483647) + 1;

    SET @o1 = @ip / 16777216;
    SET @ip = @ip % 16777216;
    SET @o2 = @ip / 65536;
    SET @ip = @ip % 65536;
    SET @o3 = @ip / 256;
    SET @ip = @ip % 256;
    SET @o4 = @ip;

    RETURN
        CONVERT(VARCHAR(4), @o1) + '.' +
        CONVERT(VARCHAR(4), @o2) + '.' +
        CONVERT(VARCHAR(4), @o3) + '.' +
        CONVERT(VARCHAR(4), @o4)
END
GO

CREATE FUNCTION [dbo].[RSDFN_ConvertBigIntToIPString]
(
    @ipin bigint
)
RETURNS CHAR(15)
AS
BEGIN
	declare @o1 bigint, @o2 bigint, @o3 bigint, @o4 bigint;
	declare @ip bigint;

    set @ip = @ipin;

    SET @o1 = @ip / 16777216;
    SET @ip = @ip % 16777216;
    SET @o2 = @ip / 65536;
    SET @ip = @ip % 65536;
    SET @o3 = @ip / 256;
    SET @ip = @ip % 256;
    SET @o4 = @ip;

    RETURN
        CONVERT(VARCHAR(4), @o1) + '.' +
        CONVERT(VARCHAR(4), @o2) + '.' +
        CONVERT(VARCHAR(4), @o3) + '.' +
        CONVERT(VARCHAR(4), @o4)
END
GO

CREATE FUNCTION [dbo].[RSDFN_ConvertIntToIPV4Binary]
(
    @ipin int
)
RETURNS BINARY(4)
AS
BEGIN
	declare @o1 bigint, @o2 bigint, @o3 bigint, @o4 bigint;
	declare @ip bigint;

-- This is the magic epo conversion size...
    set @ip = (CAST(@ipin as bigint) + 2147483647) + 1;

    SET @o1 = @ip / 16777216;
    SET @ip = @ip % 16777216;
    SET @o2 = @ip / 65536;
    SET @ip = @ip % 65536;
    SET @o3 = @ip / 256;
    SET @ip = @ip % 256;
    SET @o4 = @ip;

    RETURN
        CONVERT(BINARY(1), @o1) +
        CONVERT(BINARY(1), @o2) +
        CONVERT(BINARY(1), @o3) +
        CONVERT(BINARY(1), @o4)
END
GO

CREATE FUNCTION [dbo].[RSDFN_ConvertIntToIPV6Binary]
(
    @IPV4 int
)
RETURNS binary(16)
AS
BEGIN
    RETURN 0x00000000000000000000FFFF + [dbo].[RSDFN_ConvertIntToIPV4Binary](@IPV4); 
END
GO


CREATE FUNCTION [dbo].[RSDFN_ConvertIPStringToInt]
(
    @ipstr nvarchar(15)
)
RETURNS int
AS
BEGIN
    RETURN CONVERT(int, ([dbo].epoConvertIPStringToIPV4(@ipstr) - 2147483648));
END
GO

CREATE FUNCTION [dbo].[RSDFN_ConvertIPStringToBigInt]
(
    @ipstr nvarchar(15)
)
RETURNS bigint
AS
BEGIN
    RETURN [dbo].[epoConvertIPStringToIPV4](@ipstr);
END
GO

CREATE FUNCTION [dbo].[RSDFN_CreateFriendlyName]
(
    @DnsName nvarchar(255),
	@NetbiosName nvarchar(16),
	@IPV4 int,
	@MAC nvarchar(12)
)
RETURNS NVARCHAR(255)
AS
BEGIN
	declare @FriendlyName nvarchar(255);

    -- Friendly name is determined by the following, whichever one is not null
    if (@DnsName is not null)
    begin
        set @FriendlyName = @DnsName;
    end
    else
    begin
        if (@NetbiosName is not null)
        begin
            set @FriendlyName = @NetbiosName;
        end
        else
        begin
            if (@IPV4 > -2147483648)
            begin
                set @FriendlyName = [dbo].[RSDFN_ConvertIntToIPString](@IPV4);
            end
            else
            begin
                if (@MAC is not null)
                begin
                    set @FriendlyName = [dbo].[RSDFN_ConvertMACToDisplayString](@MAC);
                end
                else
                begin
                    set @FriendlyName = '';
                end
            end
        end
    end

	RETURN @FriendlyName;

END
GO

CREATE FUNCTION [dbo].[RSDFN_IsLeafNodeInSensorBlacklist]
(
    @leafNodeID  int
)
RETURNS bit
AS
BEGIN
    declare @inBlacklist int;
    select @inBlacklist = count(*) from [dbo].[RSDSensorBlacklistTarget]
        join [dbo].[EPOLeafNode]
        on [dbo].[RSDSensorBlacklistTarget].[AgentGUID] = [dbo].[EPOLeafNode].[AgentGUID]
        where [dbo].[EPOLeafNode].[AutoID] = @leafNodeID;

    declare @ret bit;
    set @ret = 0;

    if (@inBlacklist <> 0)
    begin
        set @ret = 1;
    end;

    return @ret;
END
GO

CREATE FUNCTION [dbo].[RSDFN_IsInIPRange]
(
    @ipaddr	binary(16),
	@start	binary(16),
	@end	binary(16)
)
RETURNS bit
AS
BEGIN
	if (@ipaddr >= @start and @ipaddr <= @end)
		return 1;

	return 0;
END
GO

CREATE FUNCTION [dbo].[RSDFN_IsInRSDConfigurationIPRange]
(
    @ipaddr	binary(16)
)
RETURNS bit
AS
BEGIN
	DECLARE @StartAddress binary(16);
	DECLARE @EndAddress binary(16);
	DECLARE @ret bit;
	set @ret = 0;

	DECLARE @cur CURSOR;
	SET @cur = CURSOR FOR
		SELECT StartAddress, EndAddress
		FROM RSDConfigurationIPRanges
		WHERE ID = 1;

	-- open the cursor
	OPEN @cur;

	-- walk all items in the server cursor
	FETCH NEXT FROM @cur INTO @StartAddress, @EndAddress
	WHILE @@FETCH_STATUS = 0
	BEGIN

		if ([dbo].[RSDFN_IsInIPRange](@ipaddr, @StartAddress, @EndAddress) = 1)
		begin
			set @ret = 1;
			break;
		end
	FETCH NEXT FROM @cur INTO @StartAddress, @EndAddress
	END;

	-- close and release the server cursor.
	CLOSE @cur;
	DEALLOCATE @cur;

	return @ret;

END
GO


CREATE FUNCTION [dbo].[RSDFN_IsInSensorBlacklist]
(
    @AgentGUID  uniqueidentifier
)
RETURNS bit
AS
BEGIN
    declare @inBlacklist int;
    select @inBlacklist = count(*) from [dbo].[RSDSensorBlacklistTarget]
        where [dbo].[RSDSensorBlacklistTarget].[AgentGUID] = @AgentGUID;

    declare @ret bit;
    set @ret = 0;

    if (@inBlacklist <> 0)
    begin
        set @ret = 1;
    end;

    return @ret;
END
GO


CREATE FUNCTION [dbo].[RSDFN_CountSensorsForSubnet]
(
	@SubnetID int,
	@SensorStatus int
)
RETURNS int
AS
BEGIN
	declare @cnt int;

	select @cnt = count(*) from RSDSensorToSubnet
	left join RSDSensors on RSDSensors.SensorID = RSDSensorToSubnet.SensorID
	where RSDSensorToSubnet.SubnetID = @SubnetID and RSDSensors.Status = @SensorStatus

	return @cnt;
END
GO

CREATE FUNCTION [dbo].[RSDFN_GetManagedSystemsBySubnetIDCount]
(
	@SubnetID		int,
	@ShowAll        bit = 1,
	@HasSensor		bit = 0,
	@InBlacklist	bit = 0
)
RETURNS int
AS
BEGIN
    -- This duplicates the stored proc but gets the count...
    declare @cnt int;

	declare @ipsubnet int;
	declare @ipmask int;

	select @ipsubnet = IPV4, @ipmask = IPV4mask
	from [dbo].[RSDSubnetProperties] where SubnetID = @SubnetID;

	declare @Subnet nvarchar(15);
	declare @SubnetMask nvarchar(15);

	set @Subnet = [dbo].[RSDFN_ConvertIntToIPString](@ipsubnet);
	set @SubnetMask = [dbo].[RSDFN_ConvertIntToIPString](@ipmask);

    if (@ShowAll = 1)
    begin
        select @cnt = count(*)
        from [dbo].[EPOComputerProperties]
        inner join EPOLeafNode on EPOComputerProperties.ParentID = EPOLeafNode.AutoID
        where EPOComputerProperties.SubnetAddress = @Subnet
            and EPOComputerProperties.SubnetMask = @SubnetMask;
    end
    else
    begin
        if (@InBlacklist = 1)
        begin
            select @cnt = count(*)
            from [dbo].[EPOComputerProperties]
            inner join EPOLeafNode on EPOComputerProperties.ParentID = EPOLeafNode.AutoID
            where EPOComputerProperties.SubnetAddress = @Subnet
                and EPOComputerProperties.SubnetMask = @SubnetMask
                and [dbo].[RSDFN_IsInSensorBlacklist](EPOLeafNode.AgentGUID) = @InBlacklist;
        end
        else
        begin
            select @cnt = count(*)
            from [dbo].[EPOComputerProperties]
            inner join EPOLeafNode on EPOComputerProperties.ParentID = EPOLeafNode.AutoID
            where EPOComputerProperties.SubnetAddress = @Subnet
                and EPOComputerProperties.SubnetMask = @SubnetMask
                and [dbo].[RSDFN_ManagedSystemHasSensor](EPOComputerProperties.ParentID) = @HasSensor
                and [dbo].[RSDFN_IsInSensorBlacklist](EPOLeafNode.AgentGUID) = @InBlacklist;
        end
    end

    return @cnt;
END
GO

-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------
-- Stored Procedures
-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[RSDSP_GetManagedSystemsBySubnetID]
(
	@SubnetID		int,
	@ShowAll        bit = 1,
	@HasSensor		bit = 0,
	@InBlacklist	bit = 0
)
AS
BEGIN
	declare @ipsubnet int;
	declare @ipmask int;

	select @ipsubnet = IPV4, @ipmask = IPV4mask
	from [dbo].[RSDSubnetProperties] where SubnetID = @SubnetID;

	declare @Subnet nvarchar(15);
	declare @SubnetMask nvarchar(15);

	set @Subnet = [dbo].[RSDFN_ConvertIntToIPString](@ipsubnet);
	set @SubnetMask = [dbo].[RSDFN_ConvertIntToIPString](@ipmask);

    if (@ShowAll = 1)
    begin
        select EPOComputerProperties.ParentID,
            EPOComputerProperties.ComputerName,
            EPOComputerProperties.DomainName,
            EPOComputerProperties.IPHostName,
            EPOComputerProperties.IPAddress,
            EPOComputerProperties.OSType,
            EPOComputerProperties.CPUType,
            EPOComputerProperties.NumOfCPU,
            EPOComputerProperties.TotalDiskSpace,
            EPOComputerProperties.FreeDiskSpace,
            EPOComputerProperties.TotalPhysicalMemory,
            EPOComputerProperties.FreeMemory
        from [dbo].[EPOComputerProperties]
        inner join EPOLeafNode on EPOComputerProperties.ParentID = EPOLeafNode.AutoID
        where EPOComputerProperties.SubnetAddress = @Subnet
            and EPOComputerProperties.SubnetMask = @SubnetMask;
    end
    else
    begin
        if (@InBlacklist = 1)
        begin
            select EPOComputerProperties.ParentID,
                EPOComputerProperties.ComputerName,
                EPOComputerProperties.DomainName,
                EPOComputerProperties.IPHostName,
                EPOComputerProperties.IPAddress,
                EPOComputerProperties.OSType,
                EPOComputerProperties.CPUType,
                EPOComputerProperties.NumOfCPU,
                EPOComputerProperties.TotalDiskSpace,
                EPOComputerProperties.FreeDiskSpace,
                EPOComputerProperties.TotalPhysicalMemory,
                EPOComputerProperties.FreeMemory
            from [dbo].[EPOComputerProperties]
            inner join EPOLeafNode on EPOComputerProperties.ParentID = EPOLeafNode.AutoID
            where EPOComputerProperties.SubnetAddress = @Subnet
                and EPOComputerProperties.SubnetMask = @SubnetMask
                and [dbo].[RSDFN_IsInSensorBlacklist](EPOLeafNode.AgentGUID) = @InBlacklist;
        end
        else
        begin
            select EPOComputerProperties.ParentID,
                EPOComputerProperties.ComputerName,
                EPOComputerProperties.DomainName,
                EPOComputerProperties.IPHostName,
                EPOComputerProperties.IPAddress,
                EPOComputerProperties.OSType,
                EPOComputerProperties.CPUType,
                EPOComputerProperties.NumOfCPU,
                EPOComputerProperties.TotalDiskSpace,
                EPOComputerProperties.FreeDiskSpace,
                EPOComputerProperties.TotalPhysicalMemory,
                EPOComputerProperties.FreeMemory
            from [dbo].[EPOComputerProperties]
            inner join EPOLeafNode on EPOComputerProperties.ParentID = EPOLeafNode.AutoID
            where EPOComputerProperties.SubnetAddress = @Subnet
                and EPOComputerProperties.SubnetMask = @SubnetMask
                and [dbo].[RSDFN_ManagedSystemHasSensor](EPOComputerProperties.ParentID) = @HasSensor
                and [dbo].[RSDFN_IsInSensorBlacklist](EPOLeafNode.AgentGUID) = @InBlacklist;
        end
    end
END
GO


CREATE PROCEDURE [dbo].[RSDSP_UpdateSensorToSubnet]
(
    @SensorID     int,
    @SubnetID     int
)
AS
BEGIN
    if (@SensorID is not null and @SubnetID is not null)
    begin
        declare @cnt int;

        select @cnt = count(*) from [dbo].[RSDSensorToSubnet] where SensorID = @SensorID and SubnetID = @SubnetID;

        if (@cnt = 0)
        begin
            declare @senid int;
            declare @subid int;

            -- Make sure the sensor id and subnet id passed in actually have corresponding entries
            -- if not, then we're not going to add this in, we will hope that a sensor/subnet are created
            -- at a later time, as these should (by definition) both exist at this time, if they don't
            -- then one or the other was deleted somewhere between when the transaction began and
            -- when it finished.  The next "detection" will be re-create the sensor/subnet pair
            select @senid = SensorID from [dbo].[RSDSensorProperties] where SensorID = @SensorID;
            select @subid = SubnetID from [dbo].[RSDSubnetProperties] where SubnetID = @SubnetID;
            if (@senid is not null and @subid is not null)
            begin
                insert into [dbo].[RSDSensorToSubnet] (SensorID, SubnetID) values (@senid, @subid)
            end
        end

    end
END
GO



CREATE PROCEDURE [dbo].[RSDSP_RemoveFromSensorBlacklist]
(
    @AgentGUID     uniqueidentifier
)
AS
BEGIN
    if (@AgentGUID is not null)
    begin
        delete from [dbo].[RSDSensorBlacklistTarget] where AgentGUID = @AgentGUID
    end
END
GO

CREATE PROCEDURE [dbo].[RSDSP_AddToSensorBlacklist]
(
    @ComputerName       nvarchar(255),
    @InputAgentGUID     uniqueidentifier,
    @OutputAgentGUID    uniqueidentifier OUTPUT
)
AS
BEGIN
    declare @AgentGUID uniqueidentifier;
    declare @ParentID int;

    if (@InputAgentGUID is null)
    begin
        select @AgentGUID = [dbo].[EPOLeafNode].[AgentGUID], @ParentID = [dbo].[EPOLeafNode].[AutoID]
        from [dbo].[EPOLeafNode], [dbo].[EPOComputerProperties]
        where [dbo].[EPOLeafNode].[AutoID] = [dbo].[EPOComputerProperties].[ParentID]
            and [dbo].[EPOComputerProperties].[ComputerName] = @ComputerName;
    end
    else
    begin
        select @AgentGUID = AgentGUID, @ParentID = AutoID from [dbo].[EPOLeafNode] where AgentGUID = @InputAgentGUID;
        if (@AgentGUID is null)
        begin
            select @AgentGUID = [dbo].[EPOLeafNode].[AgentGUID], @ParentID = [dbo].[EPOLeafNode].[AutoID]
            from [dbo].[EPOLeafNode], [dbo].[EPOComputerProperties]
            where [dbo].[EPOLeafNode].[AutoID] = [dbo].[EPOComputerProperties].[ParentID]
                and [dbo].[EPOComputerProperties].[ComputerName] = @ComputerName;
        end
    end

    declare @HasSensor bit;
    set @HasSensor = [dbo].[RSDFN_ManagedSystemHasSensor](@ParentID);

    if (@AgentGUID is not null and @HasSensor = 0)
    begin
        declare @cnt int;
        set @cnt = 0;
        select @cnt = count(*) from [dbo].[RSDSensorBlacklistTarget] where AgentGUID = @AgentGUID;

        if (@cnt = 0)
        begin
           insert into [dbo].[RSDSensorBlacklistTarget] (AgentGUID) values(@AgentGUID);
        end

        set @OutputAgentGUID = @AgentGUID;
    end

END
GO

CREATE PROCEDURE [dbo].[RSDSP_ManagedSystemHasSensorByAgentGUID]
(
    @AgentGUID      uniqueidentifier,
    @HasSensor      bit OUTPUT,
    @ComputerName   nvarchar(255) OUTPUT
)
AS
BEGIN
    declare @ParentID int;

    select @ParentID = AutoID, @ComputerName = NodeName from [dbo].[EPOLeafNode] where AgentGUID = @AgentGUID;

    set @HasSensor = [dbo].[RSDFN_ManagedSystemHasSensor](@ParentID);
END
GO



CREATE PROCEDURE [dbo].[RSDSP_BlacklistSystemByAgentGUID]
(
    @AgentGUID          uniqueidentifier,
    @AddSystem          bit,
    @HasSensor          bit OUTPUT,
    @ComputerName       nvarchar(255) OUTPUT,
    @OutputAgentGUID    uniqueidentifier OUTPUT
)
AS
BEGIN
    exec [dbo].[RSDSP_ManagedSystemHasSensorByAgentGUID] @AgentGUID, @HasSensor OUTPUT, @ComputerName OUTPUT;

    if (@AgentGUID is not null)
    begin
        if (@AddSystem = 0)
        begin
			select @OutputAgentGUID = AgentGUID from RSDSensorBlacklistTarget where AgentGUID = @AgentGUID;
			if (@OutputAgentGUID is not null)
			begin
				exec RSDSP_RemoveFromSensorBlacklist @AgentGUID;
			end
        end
        else
        begin
            if (@HasSensor = 0)
            begin
                exec RSDSP_AddToSensorBlacklist null, @AgentGUID, @OutputAgentGUID OUTPUT;
            end
        end
    end
END
GO

CREATE PROCEDURE [dbo].[RSDSP_BlacklistSystemByParentID]
(
    @ParentID           int,
    @AddSystem          bit,
    @HasSensor          bit OUTPUT,
    @ComputerName       nvarchar(255) OUTPUT,
    @OutputAgentGUID    uniqueidentifier OUTPUT
)
AS
BEGIN
    declare @AgentGUID uniqueidentifier;

    select @AgentGUID = [dbo].[EPOLeafNode].[AgentGUID]
        from [dbo].[EPOLeafNode]
        where [dbo].[EPOLeafNode].[AutoID] = @ParentID;

    exec RSDSP_BlacklistSystemByAgentGUID @AgentGUID, @AddSystem, @HasSensor OUTPUT, @ComputerName OUTPUT, @OutputAgentGUID OUTPUT;

    if (@ComputerName is null)
    begin
        select @ComputerName = NodeName  
            from [dbo].[EPOLeafNode]
            where [dbo].[EPOLeafNode].[AutoID] = @ParentID;
    end
END
GO


CREATE FUNCTION [dbo].[RSDFN_GetSubnetID]
(
    @ipv4	    int,
	@ipv4mask	int,
	@ipv6	    binary(16),
	@ipv6mask   binary(16)
)
RETURNS int
AS
BEGIN
    declare @SubnetID int;

    declare @cnt int;
    set @cnt = 0;

    -- Check to see if the subnet already exists
    select @cnt = count(*) from [dbo].[RSDSubnetProperties] where IPV4 = @IPV4
    if (@cnt > 0)
    begin
        if (@cnt = 1)
        begin
            select @SubnetID = SubnetID from [dbo].[RSDSubnetProperties] where IPV4 = @IPV4
        end
        else
        begin
            select @SubnetID = SubnetID from [dbo].[RSDSubnetProperties] where IPV4 = @IPV4 and IPV4mask = @IPV4mask
        end
    end

	return @SubnetID;
END
GO


CREATE PROCEDURE [dbo].[RSDSP_UpdateSubnets]
(
    @IPV4           int,
    @IPV4mask       int,
    @IPV6           binary (16),
    @IPV6mask       binary (16),
    @OutputSubnetID int OUTPUT
)
AS
BEGIN
    declare @SubnetID int;
    declare @SubnetName nvarchar(255);

    set @SubnetID = [dbo].[RSDFN_GetSubnetID](@IPV4, @IPV4mask, @IPV6, @IPV6mask);

-- in 3.6 the SubnetName was the name of the first machine that found it...
    set @SubnetName = [dbo].[RSDFN_ConvertIntToIPString](@IPV4);

    if (@SubnetID is not null)
    begin
        declare @_SubnetName nvarchar(255);
        declare @_IPV4 int;
        declare @_IPV4mask int;
        declare @_IPV6 binary (16);
        declare @_IPV6mask binary (16);

        select @_SubnetName = SubnetName,
                @_IPV4 = IPV4,
                @_IPV4mask = IPV4mask,
                @_IPV6 = IPV6,
                @_IPV6mask = IPV6mask
        from [dbo].[RSDSubnetProperties]
        where SubnetID = @SubnetID

        -- Here, we want the one stored in the DB to win, not the one we made up...
        if (@_SubnetName is not null or LEN(@_SubnetName) > 0)
            set @SubnetName = @_SubnetName;

        if (@IPV4 = -2147483648 or @IPV4 is null)
            set @IPV4 = @_IPV4;
        if (@IPV4mask = -2147483648 or @IPV4 is null)
            set @IPV4mask = @_IPV4mask;

        set @IPV6 = ISNULL(@IPV6, @_IPV6);
        set @IPV6mask = ISNULL(@IPV6mask, @_IPV6mask);

        update [dbo].[RSDSubnetProperties]
        set SubnetName = @SubnetName,
            IPV4 = @IPV4,
            IPV4mask = @IPV4mask,
            IPV6 = @IPV6,
            IPV6mask = @IPV6mask
        where SubnetID = @SubnetID

    end
    else
    begin
        -- need to make sure a subnet exists for this interface...
        insert into [dbo].[RSDSubnetProperties] (SubnetName, IPV4, IPV4mask, IPV6, IPV6mask)
        values (@SubnetName, @IPV4, @IPV4mask, @IPV6, @IPV6mask)

        select @SubnetID = @@IDENTITY;
    end

    set @OutputSubnetID = @SubnetID;

END
GO


CREATE PROCEDURE [dbo].[RSDSP_SubnetOverlap]
(
    @IPV4           int,
	@IPV4mask		int,
    @OutputSubnetID int OUTPUT
)
AS
BEGIN
--	declare @debug bit;
--	set @debug = 0;
	declare @NetworkAddr bigint;
	declare @NetworkMask bigint;
	set @OutputSubnetID = NULL;

	set @NetworkAddr = CONVERT(bigint, @IPV4 + 2147483648);
	set @NetworkMask = CONVERT(bigint, @IPV4mask + 2147483648);

	declare @minip bigint;
	declare @maxip bigint;

	set @minip = @NetworkAddr & @NetworkMask;
	set @maxip = @minip | ( (~@NetworkMask) & 0x00000000ffffffff );

    declare @SubnetID int;
	declare @Subnet bigint;
	declare @SubnetMask bigint;
	declare @min bigint;
	declare @max bigint;

	DECLARE @cur CURSOR;
	SET @cur = CURSOR FOR
		SELECT SubnetID,
			   (CONVERT(bigint, IPV4 + 2147483648)) AS Subnet,
			   (CONVERT(bigint, IPV4mask + 2147483648)) AS SubnetMask
		FROM RSDSubnetProperties

	-- open the cursor
	OPEN @cur;

	-- walk all items in the server cursor
	FETCH NEXT FROM @cur INTO @SubnetID, @Subnet, @SubnetMask;
	WHILE @@FETCH_STATUS = 0
	BEGIN
		set @min = @Subnet & @SubnetMask;
		set @max = @min | ( (~@SubnetMask) & 0x00000000ffffffff );

--		if (@debug = 1)
--		begin
--		print '@min ' + [dbo].[RSDFN_ConvertBigIntToIPString](@min) +
--			' @max '+[dbo].[RSDFN_ConvertBigIntToIPString](@max) +
--			' @minip '+[dbo].[RSDFN_ConvertBigIntToIPString](@minip) +
--			' @maxip '+[dbo].[RSDFN_ConvertBigIntToIPString](@maxip)
--		end

		-- Check to see if the supplied subnet is already contained within an existing subnet
		if ((@minip >= @min and @minip <= @max) or (@maxip >= @min and @maxip <= @max))
		begin
			set @OutputSubnetID = @SubnetID;
--			if (@debug = 1)
--			begin
--			print 'found! ' + [dbo].[RSDFN_ConvertIntToIPString](@IPV4) + ' '+[dbo].[RSDFN_ConvertIntToIPString](@IPV4mask)
--			print 'inside ' + [dbo].[RSDFN_ConvertBigIntToIPString](@Subnet) + ' '+[dbo].[RSDFN_ConvertBigIntToIPString](@SubnetMask)
--			end
			break;
		end

		-- Now, check to see if the existing subnet is contained within the supplied subnet
		if ((@min >= @minip and @min <= @maxip) or (@max >= @minip and @max <= @maxip))
		begin
			set @OutputSubnetID = @SubnetID;
--			if (@debug = 1)
--			begin
--			print 'found! ' + [dbo].[RSDFN_ConvertIntToIPString](@IPV4) + ' '+[dbo].[RSDFN_ConvertIntToIPString](@IPV4mask)
--			print 'outside ' + [dbo].[RSDFN_ConvertBigIntToIPString](@Subnet) + ' '+[dbo].[RSDFN_ConvertBigIntToIPString](@SubnetMask)
--			end
			break;
		end

		FETCH NEXT FROM @cur INTO @SubnetID, @Subnet, @SubnetMask;
	END;

	-- close and release the server cursor.
	CLOSE @cur;
	DEALLOCATE @cur;

--	if (@OutputSubnetID is null and @debug = 1)
--	begin
--			print 'not found! ' + [dbo].[RSDFN_ConvertIntToIPString](@IPV4) + ' '+[dbo].[RSDFN_ConvertIntToIPString](@IPV4mask)
--	end
END
GO

CREATE PROCEDURE [dbo].[RSDSP_FindSubnetForIPAddress]
(
    @IPV4           int,
    @OutputSubnetID int OUTPUT
)
AS
BEGIN
    declare @SubnetID int;
	declare @NetworkAddr bigint;
	declare @NetworkMask bigint;


	declare @min bigint;
	declare @max bigint;

	declare @ip bigint;
    set @ip = CONVERT(bigint, @IPV4 + 2147483648);

	DECLARE @cur CURSOR;
	SET @cur = CURSOR FOR
		SELECT SubnetID,
			   (CONVERT(bigint, IPV4 + 2147483648)) AS NetworkAddr,
			   (CONVERT(bigint, IPV4mask + 2147483648)) AS NetworkMask
		FROM RSDSubnetProperties

	-- open the cursor
	OPEN @cur;

	-- walk all items in the server cursor
	FETCH NEXT FROM @cur INTO @SubnetID, @NetworkAddr, @NetworkMask;
	WHILE @@FETCH_STATUS = 0
	BEGIN
		set @min = @NetworkAddr & @NetworkMask;
		set @max = @min | ( (~@NetworkMask) & 0x00000000ffffffff );

		if (@ip >= @min and @ip <= @max)
		begin
			set @OutputSubnetID = @SubnetID;
			break;
		end

		FETCH NEXT FROM @cur INTO @SubnetID, @NetworkAddr, @NetworkMask;
	END;

	-- close and release the server cursor.
	CLOSE @cur;
	DEALLOCATE @cur;

	-- If NO subnet is found, use the bit-bucket subnet id 0.0.0.0/32
    if (@OutputSubnetID is null)
    begin
        select @OutputSubnetID = SubnetID from RSDSubnetProperties where IPV4 = -2147483648 and IPV4mask = 2147483647;

        if (@OutputSubnetID is null)
        begin
            -- The bit bucket must always exist
            insert into [dbo].[RSDSubnetProperties] (SubnetName, IPV4, IPV4mask, BitBucket)
            values ('0.0.0.0/32', -2147483648, 2147483647, 1);

            select @OutputSubnetID = @@IDENTITY;
        end
        else
        begin
            update [dbo].[RSDSubnetProperties] set Ignored = 0 where SubnetID = @OutputSubnetID;
        end
    end
END
GO

-- This tries to select and match the incoming detected system with existing managed machines
CREATE PROCEDURE [dbo].[RSDSP_MatchManagedSystems]
(
	@HostID				int,
    @AgentGUID          uniqueidentifier,
    @MAC                nvarchar(12),
    @ComputerName       nvarchar(16),
    @Domain             nvarchar(16),
    @DnsName            nvarchar(255),
    @IPV4               int,
    @IPV6               binary (16)
)
AS
BEGIN
    declare @managedMatching    int;

    -- The Configuration ID by default should always be 1
    select @managedMatching = [RSDConfiguration].[ManagedMatching]
        from [dbo].[RSDConfiguration]
        where [RSDConfiguration].[ID] = 1;

    declare @useAgentGUID       bit;
    declare @useProductGUID     bit;
    declare @useMAC             bit;
    declare @useHostnameDomain  bit;
    declare @useDNSName         bit;
    declare @useIPAddress       bit;
    declare @useHostname        bit;

    set @useAgentGUID = @managedMatching & 0x1;
    set @useProductGUID = @managedMatching & 0x2;
    set @useMAC = @managedMatching & 0x10;
    set @useHostnameDomain = @managedMatching & 0x20;
    set @useDNSName = @managedMatching & 0x40;
    set @useIPAddress = @managedMatching & 0x80;
    set @useHostname = @managedMatching & 0x100;

    declare @m_AgentGUID          uniqueidentifier;

    declare @found bit;
	declare @cnt int;
	declare @done bit;
	declare @results table (
		LeafNodeID		int,
		AgentGUID       uniqueidentifier,
		MAC             nvarchar(100),
		ComputerName    nvarchar(255),
		Domain          nvarchar(100),
		DnsName         nvarchar(255),
		IPV4            int,
		IPV6            binary (16)
	);

    set @found = 0;
	set @done = 0;
	set @cnt = 0;

    if (@AgentGUID is not null and @useAgentGUID = 1)
    begin

		insert into @results (LeafNodeID, AgentGUID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6)
			select [EPOLeafNode].[AutoID],
				   [EPOLeafNode].[AgentGUID],
				   [EPOComputerProperties].[NetAddress],
				   [EPOComputerProperties].[ComputerName],
				   [EPOComputerProperties].[DomainName],
				   [EPOComputerProperties].[IPHostName],
				   [EPOComputerProperties].[IPV4x],
				   [EPOComputerProperties].[IPV6]
			from [EPOLeafNode], [EPOComputerProperties]
			where [EPOLeafNode].[AutoID] = [EPOComputerProperties].[ParentID]
				and [EPOLeafNode].[AgentGUID] = @AgentGUID;

		select @cnt = count(*) from @results;
		if (@cnt = 1)
		begin
            set @done = 1;
			set @m_AgentGUID = @AgentGUID;
		end

		-- In this case, we have already associated the AgentGUID to a ManagedSystem, so we're good
		-- unless we decide we want to update the DetectedSystem entry with known values from the ManagedSystem
		-- If more than one AgentGUID matches, we've got other problems...
    end

	if (@done = 0 and @MAC is not null and @useMAC = 1)
	begin
		if (@found = 0)
		begin
		    set @MAC = upper(@MAC);

			insert into @results (LeafNodeID, AgentGUID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6)
				select [EPOLeafNode].[AutoID],
					   [EPOLeafNode].[AgentGUID],
					   [EPOComputerProperties].[NetAddress],
					   [EPOComputerProperties].[ComputerName],
					   [EPOComputerProperties].[DomainName],
					   [EPOComputerProperties].[IPHostName],
					   [EPOComputerProperties].[IPV4x],
					   [EPOComputerProperties].[IPV6]
				from [EPOLeafNode], [EPOComputerProperties]
				where [EPOLeafNode].[AutoID] = [EPOComputerProperties].[ParentID]
					and upper([dbo].[EPOComputerProperties].[NetAddress]) = @MAC;

			select @cnt = count(*) from @results;

			if (@cnt = 1)
			begin
				set @done = 1;
				select @m_AgentGUID = AgentGUID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		-- Since this is the first possible case, there is no "else" here...
	end

	if (@done = 0 and @ComputerName is not null and @Domain is not null and @useHostnameDomain = 1)
	begin
		if (@found = 0)
		begin
			insert into @results (LeafNodeID, AgentGUID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6)
				select [EPOLeafNode].[AutoID],
					   [EPOLeafNode].[AgentGUID],
					   [EPOComputerProperties].[NetAddress],
					   [EPOComputerProperties].[ComputerName],
					   [EPOComputerProperties].[DomainName],
					   [EPOComputerProperties].[IPHostName],
					   [EPOComputerProperties].[IPV4x],
					   [EPOComputerProperties].[IPV6]
				from [EPOLeafNode], [EPOComputerProperties]
				where [EPOLeafNode].[AutoID] = [EPOComputerProperties].[ParentID]
					and [dbo].[EPOComputerProperties].[ComputerName] = @ComputerName
					and [dbo].[EPOComputerProperties].[DomainName] = @Domain;

			select @cnt = count(*) from @results;
			if (@cnt = 1)
			begin
				set @done = 1;
				select @m_AgentGUID = AgentGUID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		else
		begin
			delete R from @results as R where R.ComputerName <> @ComputerName and R.Domain <> @Domain;

			select @cnt = count(*) from @results;

			if (@cnt = 0)
			begin
				set @done = 1;
			end
			if (@cnt = 1)
			begin
				set @done = 1;
				select @m_AgentGUID = AgentGUID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
	end

	if (@done = 0 and @DnsName is not null and @useDNSName = 1)
	begin
		-- If we haven't found anything yet, insert this new selection into the DB
		if (@found = 0)
		begin
			insert into @results (LeafNodeID, AgentGUID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6)
				select [EPOLeafNode].[AutoID],
					   [EPOLeafNode].[AgentGUID],
					   [EPOComputerProperties].[NetAddress],
					   [EPOComputerProperties].[ComputerName],
					   [EPOComputerProperties].[DomainName],
					   [EPOComputerProperties].[IPHostName],
					   [EPOComputerProperties].[IPV4x],
					   [EPOComputerProperties].[IPV6]
				from [EPOLeafNode], [EPOComputerProperties]
				where [EPOLeafNode].[AutoID] = [EPOComputerProperties].[ParentID]
					and [dbo].[EPOComputerProperties].[IPHostName] = @DnsName;

			select @cnt = count(*) from @results;
			if (@cnt = 1)
			begin
				set @done = 1;
				select @m_AgentGUID = AgentGUID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		else
		begin
			delete R from @results as R where R.DnsName <> @DnsName;

			select @cnt = count(*) from @results;

			if (@cnt = 0)
			begin
				set @done = 1;
			end
			if (@cnt = 1)
			begin
				set @done = 1;
				select @m_AgentGUID = AgentGUID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
	end

	-- This is the IP Address check, it's gonna be a little nasty...
	if (@done = 0 and ( @IPV4 is not null or @IPV6 is not null) and @useIPAddress = 1)
	begin
		-- convert IPV4 to IPV6 so we can just use a single algorithm :)
		declare @ipaddr binary(16);
		if (@IPV4 is not null)
		begin
			set @ipaddr = [dbo].[RSDFN_ConvertIntToIPV6Binary](@IPV4);
		end
		else
		begin
			set @ipaddr = @IPV6;
		end

		-- We only want to do anything if this IPAddress falls in the correct range
		if ([dbo].[RSDFN_IsInRSDConfigurationIPRange](@ipaddr) = 1)
		begin
			if (@found = 0)
			begin
				if (@IPV4 is not null)
				begin
					insert into @results (LeafNodeID, AgentGUID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6)
						select [EPOLeafNode].[AutoID],
							   [EPOLeafNode].[AgentGUID],
							   [EPOComputerProperties].[NetAddress],
							   [EPOComputerProperties].[ComputerName],
							   [EPOComputerProperties].[DomainName],
							   [EPOComputerProperties].[IPHostName],
							   [EPOComputerProperties].[IPV4x],
							   [EPOComputerProperties].[IPV6]
						from [EPOLeafNode], [EPOComputerProperties]
						where [EPOLeafNode].[AutoID] = [EPOComputerProperties].[ParentID]
							and [dbo].[EPOComputerProperties].[IPV4x] = @IPV4;
				end
				else
				begin
					insert into @results (LeafNodeID, AgentGUID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6)
						select [EPOLeafNode].[AutoID],
							   [EPOLeafNode].[AgentGUID],
							   [EPOComputerProperties].[NetAddress],
							   [EPOComputerProperties].[ComputerName],
							   [EPOComputerProperties].[DomainName],
							   [EPOComputerProperties].[IPHostName],
							   [EPOComputerProperties].[IPV4x],
							   [EPOComputerProperties].[IPV6]
						from [EPOLeafNode], [EPOComputerProperties]
						where [EPOLeafNode].[AutoID] = [EPOComputerProperties].[ParentID]
							and [dbo].[EPOComputerProperties].[IPV6] = @IPV6;
				end

				select @cnt = count(*) from @results;
				if (@cnt = 1)
				begin
					set @done = 1;
					select @m_AgentGUID = AgentGUID from @results;
				end
				if (@cnt > 1)
				begin
					set @found = 1;
				end
			end
			else
			begin
				-- If this is IPV4, remove the IPV4 elements...
				if (@IPV4 is not null)
				begin
					delete R from @results as R where R.IPV4 <> @IPV4;
				end
				else
				begin
					delete R from @results as R where R.IPV6 <> @IPV6;
				end

    			select @cnt = count(*) from @results;
				if (@cnt = 0)
				begin
					set @done = 1;
				end
				if (@cnt = 1)
				begin
					set @done = 1;
					select @m_AgentGUID = AgentGUID from @results;
				end
				if (@cnt > 1)
				begin
					set @found = 1;
				end
			end
		end
	end

	-- Check for Hostname only!
	if (@done = 0 and @ComputerName is not null and @useHostname = 1)
	begin
		-- If we haven't found anything yet, insert this new selection into the DB
		if (@found = 0)
		begin
			insert into @results (LeafNodeID, AgentGUID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6)
				select [EPOLeafNode].[AutoID],
					   [EPOLeafNode].[AgentGUID],
					   [EPOComputerProperties].[NetAddress],
					   [EPOComputerProperties].[ComputerName],
					   [EPOComputerProperties].[DomainName],
					   [EPOComputerProperties].[IPHostName],
					   [EPOComputerProperties].[IPV4x],
					   [EPOComputerProperties].[IPV6]
				from [EPOLeafNode], [EPOComputerProperties]
				where [EPOLeafNode].[AutoID] = [EPOComputerProperties].[ParentID]
					and [dbo].[EPOComputerProperties].[ComputerName] = @ComputerName;

			select @cnt = count(*) from @results;
			if (@cnt = 1)
			begin
				set @done = 1;
				select @m_AgentGUID = AgentGUID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		else
		begin
			delete R from @results as R where R.ComputerName <> @ComputerName;
			select @cnt = count(*) from @results;

			if (@cnt = 0)
			begin
				set @done = 1;
			end
			if (@cnt = 1)
			begin
				set @done = 1;
				select @m_AgentGUID = AgentGUID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
	end


	if (@done = 1 and @m_AgentGUID is not null)
	begin
		update [dbo].[RSDDetectedSystemProperties]
		set AgentGUID = @m_AgentGUID, RogueAction = 0
		where HostID = @HostID;
	end

END
GO


-- This tries to select and match the incoming detected system with existing managed machines
CREATE PROCEDURE [dbo].[RSDSP_MatchDetectedSystems]
(
    @AgentGUID          uniqueidentifier,
	@SourceID			int,
	@SourceType			nvarchar(100),
	@ExternalID			nvarchar(1000),
    @MAC                nvarchar(12),
    @ComputerName       nvarchar(16),
    @Domain             nvarchar(16),
    @DnsName            nvarchar(255),
    @IPV4               int,
    @IPV6               binary (16),
	@HostID				int output
)
AS
BEGIN
    declare @detectedMatching    int;

    -- The Configuration ID by default should always be 1
    select @detectedMatching = [RSDConfiguration].[DetectedMatching]
        from [dbo].[RSDConfiguration]
        where [RSDConfiguration].[ID] = 1;

    declare @useAgentGUID       bit;
    declare @useProductGUID     bit;
    declare @useMAC             bit;
    declare @useHostnameDomain  bit;
    declare @useDNSName         bit;
    declare @useIPAddress       bit;
    declare @useHostname        bit;

    set @useAgentGUID = @detectedMatching & 0x1;
    set @useProductGUID = @detectedMatching & 0x2;
    set @useMAC = @detectedMatching & 0x10;
    set @useHostnameDomain = @detectedMatching & 0x20;
    set @useDNSName = @detectedMatching & 0x40;
    set @useIPAddress = @detectedMatching & 0x80;
    set @useHostname = @detectedMatching & 0x100;

    declare @found bit;
	declare @done bit;
	declare @cnt int;
	declare @results table (
		HostID				int,
		AgentGUID		    uniqueidentifier,
		SourceID			int,
		SourceType			nvarchar(100),
		ExternalID			nvarchar(1000),
		MAC					nvarchar(12),
		ComputerName		nvarchar(16),
		Domain				nvarchar(16),
		DnsName				nvarchar(255),
		IPV4				int,
		IPV6				binary (16),
		LastDetectedTime	datetime
	);

    set @found = 0;
	set @done = 0;
	set @cnt = 0;

	-- Check for a match on the agent guid
    if (@AgentGUID is not null and @useAgentGUID = 1)
    begin
		insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
			select [RSDDetectedSystemProperties].[HostID],
				   [RSDDetectedSystemProperties].[AgentGUID],
				   [RSDDetectedSource].[SourceID],
				   [RSDDetectedSource].[SourceType],
				   [RSDDetectedSource].[ExternalID],
				   [RSDInterfaceProperties].[MAC],
				   [RSDDetectedSystemProperties].[NetbiosName],
				   [RSDDetectedSystemProperties].[Domain],
				   [RSDDetectedSystemProperties].[DnsName],
				   [RSDInterfaceProperties].[IPV4],
				   [RSDInterfaceProperties].[IPV6],
				   [RSDDetectedSystemProperties].[LastDetectedTime]
			from [RSDDetectedSystemProperties], [RSDInterfaceProperties], [RSDDetectedSource]
			where [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
				and [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
				and [RSDDetectedSystemProperties].[AgentGUID] = @AgentGUID;

		select @cnt = count(*) from @results;
		if (@cnt = 1)
		begin
			select @HostID = HostID from @results;
			set @done = 1;
		end
		if (@cnt > 1)
		begin
			set @found = 1;
		end
    end

	-- Like AgentGUID - this should uniquely identify a single system, if not, then we fall through to the user
	-- defined selections
	if (@done = 0 and @SourceID is not null and @SourceType is not null and @ExternalID is not null and @useProductGUID = 1)
	begin
		insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
			select [RSDDetectedSystemProperties].[HostID],
				   [RSDDetectedSystemProperties].[AgentGUID],
				   [RSDDetectedSource].[SourceID],
				   [RSDDetectedSource].[SourceType],
				   [RSDDetectedSource].[ExternalID],
				   [RSDInterfaceProperties].[MAC],
				   [RSDDetectedSystemProperties].[NetbiosName],
				   [RSDDetectedSystemProperties].[Domain],
				   [RSDDetectedSystemProperties].[DnsName],
				   [RSDInterfaceProperties].[IPV4],
				   [RSDInterfaceProperties].[IPV6],
				   [RSDDetectedSystemProperties].[LastDetectedTime]
			from [RSDDetectedSystemProperties], [RSDInterfaceProperties], [RSDDetectedSource]
			where [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
				and [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
				and [RSDDetectedSource].[SourceID] = @SourceID
				and [RSDDetectedSource].[SourceType] = @SourceType
				and [RSDDetectedSource].[ExternalID] = @ExternalID;

		select @cnt = count(*) from @results;
		if (@cnt = 1)
		begin
			set @done = 1;
			select @HostID = HostID from @results;
		end
		if (@cnt > 1)
		begin
			set @found = 1;
		end
	end


	-- Check for a match on the MAC address...
	if (@done = 0 and @MAC is not null and @useMAC = 1)
	begin
		if (@found = 0)
		begin
			insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
				select [RSDDetectedSystemProperties].[HostID],
					   [RSDDetectedSystemProperties].[AgentGUID],
					   [RSDDetectedSource].[SourceID],
					   [RSDDetectedSource].[SourceType],
					   [RSDDetectedSource].[ExternalID],
					   [RSDInterfaceProperties].[MAC],
					   [RSDDetectedSystemProperties].[NetbiosName],
					   [RSDDetectedSystemProperties].[Domain],
					   [RSDDetectedSystemProperties].[DnsName],
					   [RSDInterfaceProperties].[IPV4],
					   [RSDInterfaceProperties].[IPV6],
					   [RSDDetectedSystemProperties].[LastDetectedTime]
				from [RSDDetectedSystemProperties], [RSDInterfaceProperties], [RSDDetectedSource]
				where [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
					and [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
					and [RSDInterfaceProperties].[MAC] = @MAC;

			select @cnt = count(*) from @results;
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		else
		begin
			-- need to get the most recent, in case we drop to 0 in our count...
			select @HostID = HostID from @results order by LastDetectedTime desc;

			delete R from @results as R  where MAC <> @MAC;

			select @cnt = count(*) from @results;
			if (@cnt = 0)
			begin
				-- use the host that was most recently detected
				set @done = 1;
			end
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end

		end
	end

	-- Next, do the ComputerName/Domain pair
	if (@done = 0 and @ComputerName is not null and @Domain is not null and @useHostnameDomain = 1)
	begin
		if (@found = 0)
		begin
			insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
				select [RSDDetectedSystemProperties].[HostID],
					   [RSDDetectedSystemProperties].[AgentGUID],
					   [RSDDetectedSource].[SourceID],
					   [RSDDetectedSource].[SourceType],
					   [RSDDetectedSource].[ExternalID],
					   [RSDInterfaceProperties].[MAC],
					   [RSDDetectedSystemProperties].[NetbiosName],
					   [RSDDetectedSystemProperties].[Domain],
					   [RSDDetectedSystemProperties].[DnsName],
					   [RSDInterfaceProperties].[IPV4],
					   [RSDInterfaceProperties].[IPV6],
					   [RSDDetectedSystemProperties].[LastDetectedTime]
				from [RSDDetectedSystemProperties], [RSDInterfaceProperties], [RSDDetectedSource]
				where [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
					and [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
					and [RSDDetectedSystemProperties].[NetbiosName] = @ComputerName
					and [RSDDetectedSystemProperties].[Domain] = @Domain;

			select @cnt = count(*) from @results;
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		else
		begin
			-- need to get the most recent, in case we drop to 0 in our count...
			select @HostID = HostID from @results order by LastDetectedTime desc;

			delete R from @results as R  where ComputerName <> @ComputerName and Domain <> @Domain;

			select @cnt = count(*) from @results;
			if (@cnt = 0)
			begin
				-- use the host that was most recently detected
				set @done = 1;
			end
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end

		end
	end

	-- Use DNS name
	if (@done = 0 and @DnsName is not null and @useDNSName = 1)
	begin
		if (@found = 0)
		begin
			insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
				select [RSDDetectedSystemProperties].[HostID],
					   [RSDDetectedSystemProperties].[AgentGUID],
					   [RSDDetectedSource].[SourceID],
					   [RSDDetectedSource].[SourceType],
					   [RSDDetectedSource].[ExternalID],
					   [RSDInterfaceProperties].[MAC],
					   [RSDDetectedSystemProperties].[NetbiosName],
					   [RSDDetectedSystemProperties].[Domain],
					   [RSDDetectedSystemProperties].[DnsName],
					   [RSDInterfaceProperties].[IPV4],
					   [RSDInterfaceProperties].[IPV6],
					   [RSDDetectedSystemProperties].[LastDetectedTime]
				from [RSDDetectedSystemProperties], [RSDInterfaceProperties], [RSDDetectedSource]
				where [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
					and [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
					and [RSDDetectedSystemProperties].[DnsName] = @DnsName;

			select @cnt = count(*) from @results;
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		else
		begin
			-- need to get the most recent, in case we drop to 0 in our count...
			select @HostID = HostID from @results order by LastDetectedTime desc;

			delete R from @results as R where DnsName <> @DnsName;

			select @cnt = count(*) from @results;
			if (@cnt = 0)
			begin
				-- use the host that was most recently detected
				set @done = 1;
			end
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end

		end
	end

	-- This is the IP Address check, it's gonna be a little nasty...
	if (@done = 0 and ( @IPV4 is not null or @IPV6 is not null) and @useIPAddress = 1)
	begin
		-- convert IPV4 to IPV6 so we can just use a single algorithm :)
		declare @ipaddr binary(16);
		if (@IPV4 is not null)
		begin
			set @ipaddr = [dbo].[RSDFN_ConvertIntToIPV6Binary](@IPV4);
		end
		else
		begin
			set @ipaddr = @IPV6;
		end

		-- We only want to do anything if this IPAddress falls in the correct range
		if ([dbo].[RSDFN_IsInRSDConfigurationIPRange](@ipaddr) = 1)
		begin
			if (@found = 0)
			begin
				if (@IPV4 is not null)
				begin
                    insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
                        select [RSDDetectedSystemProperties].[HostID],
                               [RSDDetectedSystemProperties].[AgentGUID],
                               [RSDDetectedSource].[SourceID],
                               [RSDDetectedSource].[SourceType],
                               [RSDDetectedSource].[ExternalID],
                               [RSDInterfaceProperties].[MAC],
                               [RSDDetectedSystemProperties].[NetbiosName],
                               [RSDDetectedSystemProperties].[Domain],
                               [RSDDetectedSystemProperties].[DnsName],
                               [RSDInterfaceProperties].[IPV4],
                               [RSDInterfaceProperties].[IPV6],
                               [RSDDetectedSystemProperties].[LastDetectedTime]
                        from [RSDDetectedSystemProperties], [RSDInterfaceProperties], [RSDDetectedSource]
                        where [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
                            and [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
                            and [RSDInterfaceProperties].[IPV4] = @IPV4;
				end
				else
				begin
                    insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
                        select [RSDDetectedSystemProperties].[HostID],
                               [RSDDetectedSystemProperties].[AgentGUID],
                               [RSDDetectedSource].[SourceID],
                               [RSDDetectedSource].[SourceType],
                               [RSDDetectedSource].[ExternalID],
                               [RSDInterfaceProperties].[MAC],
                               [RSDDetectedSystemProperties].[NetbiosName],
                               [RSDDetectedSystemProperties].[Domain],
                               [RSDDetectedSystemProperties].[DnsName],
                               [RSDInterfaceProperties].[IPV4],
                               [RSDInterfaceProperties].[IPV6],
                               [RSDDetectedSystemProperties].[LastDetectedTime]
                        from [RSDDetectedSystemProperties], [RSDInterfaceProperties], [RSDDetectedSource]
                        where [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
                            and [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
                            and [RSDInterfaceProperties].[IPV6] = @IPV6;
				end

                select @cnt = count(*) from @results;
                if (@cnt = 1)
                begin
                    set @done = 1;
                    select @HostID = HostID from @results;
                end
                if (@cnt > 1)
                begin
                    set @found = 1;
                end
			end
			else
			begin
                -- need to get the most recent, in case we drop to 0 in our count...
                select @HostID = HostID from @results order by LastDetectedTime desc;

				-- If this is IPV4, remove the IPV4 elements...
				if (@IPV4 is not null)
				begin
					delete R from @results as R where R.IPV4 <> @IPV4;
				end
				else
				begin
					delete R from @results as R where R.IPV6 <> @IPV6;
				end

                select @cnt = count(*) from @results;
                if (@cnt = 0)
                begin
                    -- use the host that was most recently detected
                    set @done = 1;
                end
                if (@cnt = 1)
                begin
                    set @done = 1;
                    select @HostID = HostID from @results;
                end
                if (@cnt > 1)
                begin
                    set @found = 1;
                end

			end
		end
	end

	-- Check for Hostname only!
	if (@done = 0 and @ComputerName is not null and @useHostname = 1)
	begin
		if (@found = 0)
		begin
			insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
				select [RSDDetectedSystemProperties].[HostID],
					   [RSDDetectedSystemProperties].[AgentGUID],
					   [RSDDetectedSource].[SourceID],
					   [RSDDetectedSource].[SourceType],
					   [RSDDetectedSource].[ExternalID],
					   [RSDInterfaceProperties].[MAC],
					   [RSDDetectedSystemProperties].[NetbiosName],
					   [RSDDetectedSystemProperties].[Domain],
					   [RSDDetectedSystemProperties].[DnsName],
					   [RSDInterfaceProperties].[IPV4],
					   [RSDInterfaceProperties].[IPV6],
					   [RSDDetectedSystemProperties].[LastDetectedTime]
				from [RSDDetectedSystemProperties], [RSDInterfaceProperties], [RSDDetectedSource]
				where [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
					and [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
					and [RSDDetectedSystemProperties].[NetbiosName] = @ComputerName;

			select @cnt = count(*) from @results;
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		else
		begin
			-- need to get the most recent, in case we drop to 0 in our count...
			select @HostID = HostID from @results order by LastDetectedTime desc;

			delete R from @results as R  where ComputerName <> @ComputerName;

			select @cnt = count(*) from @results;
			if (@cnt = 0)
			begin
				-- use the host that was most recently detected
				set @done = 1;
			end
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end

		end
	end

	-- If we never were able to narrow it down to just one, return the most recently detected host from our temp table
	if (@done = 0 and @cnt > 1)
	begin
		select @HostID = HostID from @results order by LastDetectedTime desc;
	end

END
GO

CREATE PROCEDURE [dbo].[RSDSP_GetDetectedSystemMergeCandidates]
(
	@HostID				int,
    @AgentGUID          uniqueidentifier,
	@SourceID			int,
	@SourceType			nvarchar(100),
	@ExternalID			nvarchar(1000),
    @MAC                nvarchar(12),
    @ComputerName       nvarchar(16),
    @Domain             nvarchar(16),
    @DnsName            nvarchar(255),
    @IPV4               int,
    @IPV6               binary (16)
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    declare @detectedMerging    int;

    -- The Configuration ID by default should always be 1
    select @detectedMerging = [RSDConfiguration].[DetectedMerging]
        from [dbo].[RSDConfiguration]
        where [RSDConfiguration].[ID] = 1;

    declare @useAgentGUID       bit;
    declare @useProductGUID     bit;
    declare @useMAC             bit;
    declare @useHostnameDomain  bit;
    declare @useDNSName         bit;
    declare @useIPAddress       bit;
    declare @useHostname        bit;

    set @useAgentGUID = @detectedMerging & 0x1;
    set @useProductGUID = @detectedMerging & 0x2;
    set @useMAC = @detectedMerging & 0x10;
    set @useHostnameDomain = @detectedMerging & 0x20;
    set @useDNSName = @detectedMerging & 0x40;
    set @useIPAddress = @detectedMerging & 0x80;
    set @useHostname = @detectedMerging & 0x100;

	declare @results table (
		HostID				int,
		AgentGUID		    uniqueidentifier,
		SourceID			int,
		SourceType			nvarchar(100),
		ExternalID			nvarchar(1000),
		MAC					nvarchar(12),
		ComputerName		nvarchar(16),
		Domain				nvarchar(16),
		DnsName				nvarchar(255),
		IPV4				int,
		IPV6				binary (16),
		LastDetectedTime	datetime
	);

	-- Build the @results table up with all the properties we've decided to match on...

	-- Check for a match on the agent guid
    if (@AgentGUID is not null and @useAgentGUID = 1)
    begin
		insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
			select [RSDDetectedSystemProperties].[HostID],
				   [RSDDetectedSystemProperties].[AgentGUID],
				   [RSDDetectedSource].[SourceID],
				   [RSDDetectedSource].[SourceType],
				   [RSDDetectedSource].[ExternalID],
				   [RSDInterfaceProperties].[MAC],
				   [RSDDetectedSystemProperties].[NetbiosName],
				   [RSDDetectedSystemProperties].[Domain],
				   [RSDDetectedSystemProperties].[DnsName],
				   [RSDInterfaceProperties].[IPV4],
				   [RSDInterfaceProperties].[IPV6],
				   [RSDDetectedSystemProperties].[LastDetectedTime]
			from [RSDDetectedSystemProperties], [RSDInterfaceProperties], [RSDDetectedSource]
			where [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
				and [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
				and [RSDDetectedSystemProperties].[AgentGUID] = @AgentGUID;
    end

	-- Like AgentGUID - this should uniquely identify a single system, if not, then we fall through to the user
	-- defined selections
	if (@SourceID is not null and @SourceType is not null and @ExternalID is not null and @useProductGUID = 1)
	begin
		insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
			select [RSDDetectedSystemProperties].[HostID],
				   [RSDDetectedSystemProperties].[AgentGUID],
				   [RSDDetectedSource].[SourceID],
				   [RSDDetectedSource].[SourceType],
				   [RSDDetectedSource].[ExternalID],
				   [RSDInterfaceProperties].[MAC],
				   [RSDDetectedSystemProperties].[NetbiosName],
				   [RSDDetectedSystemProperties].[Domain],
				   [RSDDetectedSystemProperties].[DnsName],
				   [RSDInterfaceProperties].[IPV4],
				   [RSDInterfaceProperties].[IPV6],
				   [RSDDetectedSystemProperties].[LastDetectedTime]
			from [RSDDetectedSystemProperties], [RSDInterfaceProperties], [RSDDetectedSource]
			where [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
				and [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
				and [RSDDetectedSource].[SourceID] = @SourceID
				and [RSDDetectedSource].[SourceType] = @SourceType
				and [RSDDetectedSource].[ExternalID] = @ExternalID;
	end


	-- Check for a match on the MAC address...
	if (@MAC is not null and @useMAC = 1)
	begin
		insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
			select [RSDDetectedSystemProperties].[HostID],
				   [RSDDetectedSystemProperties].[AgentGUID],
				   [RSDDetectedSource].[SourceID],
				   [RSDDetectedSource].[SourceType],
				   [RSDDetectedSource].[ExternalID],
				   [RSDInterfaceProperties].[MAC],
				   [RSDDetectedSystemProperties].[NetbiosName],
				   [RSDDetectedSystemProperties].[Domain],
				   [RSDDetectedSystemProperties].[DnsName],
				   [RSDInterfaceProperties].[IPV4],
				   [RSDInterfaceProperties].[IPV6],
				   [RSDDetectedSystemProperties].[LastDetectedTime]
			from [RSDDetectedSystemProperties], [RSDInterfaceProperties], [RSDDetectedSource]
			where [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
				and [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
				and [RSDInterfaceProperties].[MAC] = @MAC;
	end

	-- Next, do the ComputerName/Domain pair
	if (@ComputerName is not null and @Domain is not null and @useHostnameDomain = 1)
	begin
		insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
			select [RSDDetectedSystemProperties].[HostID],
				   [RSDDetectedSystemProperties].[AgentGUID],
				   [RSDDetectedSource].[SourceID],
				   [RSDDetectedSource].[SourceType],
				   [RSDDetectedSource].[ExternalID],
				   [RSDInterfaceProperties].[MAC],
				   [RSDDetectedSystemProperties].[NetbiosName],
				   [RSDDetectedSystemProperties].[Domain],
				   [RSDDetectedSystemProperties].[DnsName],
				   [RSDInterfaceProperties].[IPV4],
				   [RSDInterfaceProperties].[IPV6],
				   [RSDDetectedSystemProperties].[LastDetectedTime]
			from [RSDDetectedSystemProperties], [RSDInterfaceProperties], [RSDDetectedSource]
			where [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
				and [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
				and [RSDDetectedSystemProperties].[NetbiosName] = @ComputerName
				and [RSDDetectedSystemProperties].[Domain] = @Domain;
	end

	-- Use DNS name
	if (@DnsName is not null and @useDNSName = 1)
	begin
		insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
			select [RSDDetectedSystemProperties].[HostID],
				   [RSDDetectedSystemProperties].[AgentGUID],
				   [RSDDetectedSource].[SourceID],
				   [RSDDetectedSource].[SourceType],
				   [RSDDetectedSource].[ExternalID],
				   [RSDInterfaceProperties].[MAC],
				   [RSDDetectedSystemProperties].[NetbiosName],
				   [RSDDetectedSystemProperties].[Domain],
				   [RSDDetectedSystemProperties].[DnsName],
				   [RSDInterfaceProperties].[IPV4],
				   [RSDInterfaceProperties].[IPV6],
				   [RSDDetectedSystemProperties].[LastDetectedTime]
			from [RSDDetectedSystemProperties], [RSDInterfaceProperties], [RSDDetectedSource]
			where [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
				and [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
				and [RSDDetectedSystemProperties].[DnsName] = @DnsName;
	end

	-- This is the IP Address check, it's gonna be a little nasty...
	if (( @IPV4 is not null or @IPV6 is not null) and @useIPAddress = 1)
	begin
		-- convert IPV4 to IPV6 so we can just use a single algorithm :)
		declare @ipaddr binary(16);
		if (@IPV4 is not null)
		begin
			set @ipaddr = [dbo].[RSDFN_ConvertIntToIPV6Binary](@IPV4);
		end
		else
		begin
			set @ipaddr = @IPV6;
		end

		-- We only want to do anything if this IPAddress falls in the correct range
		if ([dbo].[RSDFN_IsInRSDConfigurationIPRange](@ipaddr) = 1)
		begin
			if (@IPV4 is not null)
			begin
                insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
                    select [RSDDetectedSystemProperties].[HostID],
                           [RSDDetectedSystemProperties].[AgentGUID],
                           [RSDDetectedSource].[SourceID],
                           [RSDDetectedSource].[SourceType],
                           [RSDDetectedSource].[ExternalID],
                           [RSDInterfaceProperties].[MAC],
                           [RSDDetectedSystemProperties].[NetbiosName],
                           [RSDDetectedSystemProperties].[Domain],
                           [RSDDetectedSystemProperties].[DnsName],
                           [RSDInterfaceProperties].[IPV4],
                           [RSDInterfaceProperties].[IPV6],
                           [RSDDetectedSystemProperties].[LastDetectedTime]
                    from [RSDDetectedSystemProperties], [RSDInterfaceProperties], [RSDDetectedSource]
                    where [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
                        and [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
                        and [RSDInterfaceProperties].[IPV4] = @IPV4;
			end
			else
			begin
                insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
                    select [RSDDetectedSystemProperties].[HostID],
                           [RSDDetectedSystemProperties].[AgentGUID],
                           [RSDDetectedSource].[SourceID],
                           [RSDDetectedSource].[SourceType],
                           [RSDDetectedSource].[ExternalID],
                           [RSDInterfaceProperties].[MAC],
                           [RSDDetectedSystemProperties].[NetbiosName],
                           [RSDDetectedSystemProperties].[Domain],
                           [RSDDetectedSystemProperties].[DnsName],
                           [RSDInterfaceProperties].[IPV4],
                           [RSDInterfaceProperties].[IPV6],
                           [RSDDetectedSystemProperties].[LastDetectedTime]
                    from [RSDDetectedSystemProperties], [RSDInterfaceProperties], [RSDDetectedSource]
                    where [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
                        and [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
                        and [RSDInterfaceProperties].[IPV6] = @IPV6;
			end
		end
	end

	-- Check for Hostname only!
	if (@ComputerName is not null and @useHostname = 1)
	begin
		insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
			select [RSDDetectedSystemProperties].[HostID],
				   [RSDDetectedSystemProperties].[AgentGUID],
				   [RSDDetectedSource].[SourceID],
				   [RSDDetectedSource].[SourceType],
				   [RSDDetectedSource].[ExternalID],
				   [RSDInterfaceProperties].[MAC],
				   [RSDDetectedSystemProperties].[NetbiosName],
				   [RSDDetectedSystemProperties].[Domain],
				   [RSDDetectedSystemProperties].[DnsName],
				   [RSDInterfaceProperties].[IPV4],
				   [RSDInterfaceProperties].[IPV6],
				   [RSDDetectedSystemProperties].[LastDetectedTime]
			from [RSDDetectedSystemProperties], [RSDInterfaceProperties], [RSDDetectedSource]
			where [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
				and [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
				and [RSDDetectedSystemProperties].[NetbiosName] = @ComputerName;
	end

	-- At this point, the table should be full of only the properties that all match our merging criteria.
	-- There should be at least ONE, since we just added a new machine that matched this criteria
	-- If there is not at least ONE - not sure what to do here...
	-- If there is only one, then NO MERGE is needed
	-- If there is more than one, then we need to send the list of HostIDs available for the "mergable" candidate

	-- Don't include the HostID we know about, that is the "target" system we are going to merge into
	select HostID from @results where HostID <> @HostID;

END
GO

CREATE PROCEDURE [dbo].[RSDSP_ExecuteMerge]
(
	@TargetHostID				int,
    @SourceHostID               int
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- First, find the interesting mergeable properties from the target - all non-null values will be left alone
    declare @DnsName            nvarchar(255);
    declare @OSPlatform         nvarchar(25);
    declare @OSFamily           nvarchar(128);
    declare @OSVersion          nvarchar(128);
    declare @Domain             nvarchar(16);
    declare @NetbiosName        nvarchar(16);
    declare @NetbiosComment     nvarchar(100);
    declare @Users              nvarchar(128);
    declare @AgentGUID          uniqueidentifier;
    declare @IPV4               int;
    declare @IPV6               binary (16);
    declare @MAC                nvarchar(12);
    declare @DetectedTime       datetime;
    declare @SourceType         nvarchar(100);

    select @DnsName = DnsName,
           @OSPlatform = OSPlatform,
           @OSFamily = OSFamily,
           @OSVersion = OSVersion,
           @Domain = [Domain],
           @NetbiosName = NetbiosName,
           @NetbiosComment = NetbiosComment,
           @Users = Users,
           @AgentGUID = AgentGUID,
           @IPV4 = IPV4,
           @IPV6 = IPV6,
           @MAC = MAC,
           @DetectedTime = LastDetectedTime,
           @SourceType = DetectedSourceType
    from [dbo].[RSDDetectedSystemProperties]
    where HostID = @TargetHostID;

	-- Now, go get all the relevant properties from the source - these values will overwrite null target values
    declare @_DnsName            nvarchar(255);
    declare @_OSPlatform         nvarchar(25);
    declare @_OSFamily           nvarchar(128);
    declare @_OSVersion          nvarchar(128);
    declare @_Domain             nvarchar(16);
    declare @_NetbiosName        nvarchar(16);
    declare @_NetbiosComment     nvarchar(100);
    declare @_Users              nvarchar(128);
    declare @_AgentGUID          uniqueidentifier;
    declare @_IPV4               int;
    declare @_IPV6               binary (16);
    declare @_MAC                nvarchar(12);
    declare @_DetectedTime       datetime;
    declare @_SourceType         nvarchar(100);

    select @_DnsName = DnsName,
           @_OSPlatform = OSPlatform,
           @_OSFamily = OSFamily,
           @_OSVersion = OSVersion,
           @_Domain = [Domain],
           @_NetbiosName = NetbiosName,
           @_NetbiosComment = NetbiosComment,
           @_Users = Users,
           @_AgentGUID = AgentGUID,
           @_IPV4 = IPV4,
           @_IPV6 = IPV6,
           @_MAC = MAC,
           @_DetectedTime = LastDetectedTime,
           @_SourceType = DetectedSourceType
    from [dbo].[RSDDetectedSystemProperties]
    where HostID = @SourceHostID;

    if (@DnsName is null or LEN(@DnsName) = 0)
        set @DnsName = @_DnsName;

	if ((@OSPlatform is null or LEN(@OSPlatform) = 0) or (@OSPlatform = N'Unknown' and @_OSPlatform <> N'Unknown'))
        set @OSPlatform = @_OSPlatform;

    if (@OSFamily is null or LEN(@OSFamily) = 0)
        set @OSFamily = @_OSFamily;

    if (@OSVersion is null or LEN(@OSVersion) = 0)
        set @OSVersion = @_OSVersion;

    if (@Domain is null or LEN(@Domain) = 0)
        set @Domain = @_Domain;

    if (@NetbiosName is null or LEN(@NetbiosName) = 0)
        set @NetbiosName = @_NetbiosName;

    if (@NetbiosComment is null or LEN(@NetbiosComment) = 0)
        set @NetbiosComment = @_NetbiosComment;

    if (@Users is null or LEN(@Users) = 0)
        set @Users = @_Users;

    set @AgentGUID = ISNULL(@AgentGUID, @_AgentGUID);

    if (@IPV4 = -2147483648 or @IPV4 is null)
        set @IPV4 = @_IPV4;

    set @IPV6 = ISNULL(@IPV6, @_IPV6);

    if (@MAC is null or LEN(@MAC) = 0)
        set @MAC = @_MAC;

    set @DetectedTime = ISNULL(@DetectedTime, @_DetectedTime);

    if (@SourceType is null or LEN(@SourceType) = 0)
        set @SourceType = @_SourceType;


    update [dbo].[RSDDetectedSystemProperties]
    set DnsName = @DnsName,
        OSPlatform = @OSPlatform,
        OSFamily = @OSFamily,
        OSVersion = @OSVersion,
        [Domain] = @Domain,
        NetbiosName = @NetbiosName,
        NetbiosComment = @NetbiosComment,
        Users = @Users,
        AgentGUID = @AgentGUID,
        IPV4 = @IPV4,
        IPV6 = @IPV6,
        MAC = @MAC,
        LastDetectedTime = @DetectedTime,
        DetectedSourceType = @SourceType
    where HostID = @TargetHostID;

	-- Now, update all the interfaces from the source to the target
	-- We'll do this by looping through the detected system interfaces for the source
    declare @iMAC					nvarchar(12);
	declare @iOUI					nvarchar (6);
    declare @iIPV4					int;
    declare @iIPV6					binary (16);
	declare @iSubnetID				int;
	declare @iLastDetectedTime		datetime;
	declare @iDetectedSourceType	nvarchar(100);

    DECLARE @cur CURSOR;
   	SET @cur = CURSOR FOR SELECT MAC, OUI, IPV4, IPV6, SubnetID, LastDetectedTime, DetectedSourceType
		FROM [dbo].[RSDInterfaceProperties]
		WHERE HostID = @SourceHostID;

   	-- open the cursor
   	OPEN @cur;

   	-- walk all items in the server cursor
   	FETCH NEXT FROM @cur INTO @iMAC, @iOUI, @iIPV4, @iIPV6, @iSubnetID, @iLastDetectedTime, @iDetectedSourceType
   	WHILE @@FETCH_STATUS = 0
	BEGIN

		declare @cnt int;

		select @cnt = count(*)
		from [dbo].[RSDInterfaceProperties]
		where HostID = @TargetHostID and (MAC is not null and MAC = @iMAC) and IPV4 = @iIPV4 and (IPV6 is not null and IPV6 = @iIPV6) and SubnetID = @iSubnetID;

		-- If there are no existing interfaces with the source data, then add it to the target host id
		if (@cnt = 0)
		begin
			insert into [dbo].[RSDInterfaceProperties] (HostID, MAC, OUI, IPV4, IPV6, SubnetID, LastDetectedTime, DetectedSourceType)
			values (@TargetHostID, @iMAC, @iOUI, @iIPV4, @iIPV6, @iSubnetID, @iLastDetectedTime, @iDetectedSourceType);
		end

   	FETCH NEXT FROM @cur INTO @iMAC, @iOUI, @iIPV4, @iIPV6, @iSubnetID, @iLastDetectedTime, @iDetectedSourceType
   	END;

   	-- close and release the server cursor.
   	CLOSE @cur;
   	DEALLOCATE @cur;


	-- Now, we should be good to go and be able to delete the SourceHostID
	-- The cascade on delete should take care of cleaning up any of the interfaces
	delete from [dbo].[RSDDetectedSystemProperties] where HostID = @SourceHostID;

	-- I suppose we could delete all the RSDInterfaceProperties where HostID = @SourceHostID to make sure...

END
GO

CREATE PROCEDURE [dbo].[RSDSP_UpdateInterfaces]
(
    @HostID             int,
    @MAC                nvarchar(12),
    @IPV4               int,
    @IPV4mask           int,
    @IPV4subnet         int,
    @IPV6               binary (16),
    @IPV6mask           binary (16),
    @IPV6subnet         binary (16),
    @DetectedTime       datetime,
    @SourceID           int,
    @SourceType         nvarchar(100),
    @ExternalID         nvarchar(1000)
)
AS
BEGIN
    declare @InterfaceID int;
    declare @cnt int;
    declare @isNew int;

    if (@MAC is not null)
    begin
        set @MAC = UPPER(@MAC);
    end;

    set @cnt = 0;

    select @cnt = count(*) from [dbo].[RSDInterfaceProperties] where (HostID = @HostID)
    if (@cnt > 0)
    begin
        if (@InterfaceID is null)
        begin
			-- Try to match on the MAC, this should work in most cases
            select @InterfaceID = InterfaceID from [dbo].[RSDInterfaceProperties] where (HostID = @HostID and @MAC is not null and MAC = @MAC)
			if (@InterfaceID is null)
            begin
	            -- If the MAC is null, try to match the interface on the IP address...
				select @InterfaceID = InterfaceID from [dbo].[RSDInterfaceProperties] where (HostID = @HostID and IPV4 is not null and IPV4 = @IPV4)
				if (@InterfaceID is null)
				begin
					-- Ok, try the IPV6 address...
					select @InterfaceID = InterfaceID from [dbo].[RSDInterfaceProperties] where (HostID = @HostID and IPV6 is not null and IPV6 = @IPV6)
				end
            end
        end
    end

    -- need to get the OUI
    declare @OUI nvarchar(6);
    if ( @MAC is not null )
    begin
        set @OUI = SUBSTRING(@MAC, 0, 7);
    end
    else
    begin
        set @OUI = 'FFFFFF';
    end

    -- find the appropriate subnet, if it exists... if not, create a subnet entry then use that one
    declare @SubnetID int;
    if ( (@IPV4subnet is null or @IPV4subnet = -2147483648) and (@IPV4mask is null or @IPV4mask = 2147483647))
    begin
        -- if the subnet and mask ARE null, then we need to loop through and see if the ip address we have
        -- is in any of the known subnet ranges...
        if (@IPV4 is not null)
        begin
            exec RSDSP_FindSubnetForIPAddress @IPV4, @SubnetID output
        end
    end
    else
    begin
        -- if the subnet and mask are not null, then we're good to go
        exec RSDSP_UpdateSubnets @IPV4subnet, @IPV4mask, @IPV6subnet, @IPV6mask, @SubnetID output
    end

    -- This is specific to RSD, this should be changed if any "SourceType" changes occur
    if (@SourceType like 'rsd.%')
    begin
        exec RSDSP_UpdateSensorToSubnet @SourceID, @SubnetID;
    end

    declare @ignoreSubnet bit;
    select @ignoreSubnet = Ignored from [dbo].[RSDSubnetProperties] where SubnetID = @SubnetID;

    if (@ignoreSubnet = 0)
    begin
        -- if the InterfaceID is not null, just update, otherwise add a new one
        if (@InterfaceID is not null)
        begin
            set @isNew = 0;

            declare @_MAC nvarchar(12);
            declare @_OUI nvarchar(6);
            declare @_IPV4 int;
            declare @_IPV6 int;

            select @_MAC = MAC,
                    @_OUI = OUI,
                    @_IPV4 = IPV4,
                    @_IPV6 = IPV6
            from [dbo].[RSDInterfaceProperties]
            where InterfaceID = @InterfaceID

            if (@MAC is null or LEN(@MAC) = 0)
                set @MAC = @_MAC;

            if (@OUI is null or LEN(@OUI) = 0)
                set @OUI = @_OUI;

            if (@IPV4 = -2147483648 or @IPV4 is null)
                set @IPV4 = @_IPV4;

            set @IPV6 = ISNULL(@IPV6, @_IPV6);

            update [dbo].[RSDInterfaceProperties]
            set MAC = @MAC,
                OUI = @OUI,
                IPV4 = @IPV4,
                IPV6 = @IPV6,
                SubnetID = @SubnetID,
                LastDetectedTime = @DetectedTime,
                DetectedSourceType = @SourceType
            where InterfaceID = @InterfaceID

        end
        else
        begin
            set @isNew = 1;

            -- need to make sure a subnet exists for this interface...
            insert into [dbo].[RSDInterfaceProperties] (HostID, MAC, OUI, IPV4, IPV6, SubnetID, LastDetectedTime, DetectedSourceType)
            values (@HostID, @MAC, @OUI, @IPV4, @IPV6, @SubnetID, @DetectedTime, @SourceType)

            select @InterfaceID = @@IDENTITY;

        end
    end
END
GO

-- UpdateDetectedSystems
CREATE PROCEDURE [dbo].[RSDSP_UpdateDetectedSystems]
(
    @DnsName            nvarchar(255),
    @OSPlatform         nvarchar(25),
    @OSFamily           nvarchar(128),
    @OSVersion          nvarchar(128),
    @Domain             nvarchar(16),
    @NetbiosName        nvarchar(16),
    @NetbiosComment     nvarchar(100),
    @Users              nvarchar(128),
    @AgentGUID          uniqueidentifier,
    @IPV4               int,
    @IPV6               binary (16),
    @MAC                nvarchar(12),
    @DetectedTime       datetime,
    @SourceID           int,
    @SourceType         nvarchar(100),
    @ExternalID         nvarchar(1000),
    @OutputHostID		int OUTPUT,
    @OutputNewDetection bit OUTPUT
)
AS
BEGIN
    declare @NewDetection bit;
    set @NewDetection = 0;

    declare @FriendlyName nvarchar(255);
    declare @HostID int;

    if (@MAC is not null)
    begin
        set @MAC = UPPER(@MAC);
    end;

	-- Match detected systems
	exec RSDSP_MatchDetectedSystems @AgentGUID, @SourceID, @SourceType, @ExternalID,
		@MAC, @NetbiosName, @Domain, @DnsName, @IPV4, @IPV6, @HostID output;

    -- If this identity algoritm returns a match, then update the DetectedSystem,
    -- Interfaces, DetectedSource, and Status with the new data
    if (@HostID is not null)
    begin
        -- We need to get the existing data and replace all non-null values with updated data
        declare @_DnsName            nvarchar(255);
        declare @_OSPlatform         nvarchar(25);
        declare @_OSFamily           nvarchar(128);
        declare @_OSVersion          nvarchar(128);
        declare @_Domain             nvarchar(16);
        declare @_NetbiosName        nvarchar(16);
        declare @_NetbiosComment     nvarchar(100);
        declare @_Users              nvarchar(128);
        declare @_AgentGUID          uniqueidentifier;
        declare @_IPV4               int;
        declare @_IPV6               binary (16);
        declare @_MAC                nvarchar(12);
        declare @_DetectedTime       datetime;
        declare @_SourceType         nvarchar(100);

        select @_DnsName = DnsName,
               @_OSPlatform = OSPlatform,
               @_OSFamily = OSFamily,
               @_OSVersion = OSVersion,
               @_Domain = [Domain],
               @_NetbiosName = NetbiosName,
               @_NetbiosComment = NetbiosComment,
               @_Users = Users,
               @_AgentGUID = AgentGUID,
               @_IPV4 = IPV4,
               @_IPV6 = IPV6,
               @_MAC = MAC,
               @_DetectedTime = LastDetectedTime,
               @_SourceType = DetectedSourceType
        from [dbo].[RSDDetectedSystemProperties]
        where HostID = @HostID;

		if (@DnsName is null or LEN(@DnsName) = 0)
			set @DnsName = @_DnsName;

		if ((@OSPlatform is null or LEN(@OSPlatform) = 0) or (@OSPlatform = N'Unknown' and @_OSPlatform <> N'Unknown'))
		    set @OSPlatform = @_OSPlatform;

		if (@OSFamily is null or LEN(@OSFamily) = 0)
			set @OSFamily = @_OSFamily;

		if (@OSVersion is null or LEN(@OSVersion) = 0)
			set @OSVersion = @_OSVersion;

		if (@Domain is null or LEN(@Domain) = 0)
			set @Domain = @_Domain;

		if (@NetbiosName is null or LEN(@NetbiosName) = 0)
			set @NetbiosName = @_NetbiosName;

		if (@NetbiosComment is null or LEN(@NetbiosComment) = 0)
			set @NetbiosComment = @_NetbiosComment;

		if (@Users is null or LEN(@Users) = 0)
			set @Users = @_Users;

        set @AgentGUID = ISNULL(@AgentGUID, @_AgentGUID);

        if (@IPV4 = -2147483648 or @IPV4 is null)
            set @IPV4 = @_IPV4;

        set @IPV6 = ISNULL(@IPV6, @_IPV6);

		if (@MAC is null or LEN(@MAC) = 0)
			set @MAC = @_MAC;

        set @DetectedTime = ISNULL(@DetectedTime, @_DetectedTime);

        set @FriendlyName = [dbo].[RSDFN_CreateFriendlyName](@DnsName, @NetbiosName, @IPV4, @MAC);

        update [dbo].[RSDDetectedSystemProperties]
        set DnsName = @DnsName,
            OSPlatform = @OSPlatform,
            OSFamily = @OSFamily,
            OSVersion = @OSVersion,
            [Domain] = @Domain,
            NetbiosName = @NetbiosName,
            NetbiosComment = @NetbiosComment,
            Users = @Users,
            AgentGUID = @AgentGUID,
            IPV4 = @IPV4,
            IPV6 = @IPV6,
            MAC = @MAC,
            LastDetectedTime = @DetectedTime,
            FriendlyName = @FriendlyName,
            DetectedSourceType = @SourceType
        where HostID = @HostID;

    end
    else
    begin
        -- Friendly name is determined by the following, whichever one is not null
        set @FriendlyName = [dbo].[RSDFN_CreateFriendlyName](@DnsName, @NetbiosName, @IPV4, @MAC);

        -- Otherwise, add a new row to the DetectedSystems, Interfaces, Status,
        -- DetectedSource and if the RDSSubnets doesn't have associated subnets
        -- we'll need to add in subnet tables, too...
        insert into [dbo].[RSDDetectedSystemProperties] (DnsName, OSPlatform, OSFamily, OSVersion, [Domain],
            NetbiosName, NetbiosComment, Users, AgentGUID, FriendlyName, IPV4, IPV6, MAC,
            LastDetectedTime, DetectedSourceType, Ignored)
        values (@DnsName, @OSPlatform, @OSFamily, @OSVersion, @Domain,
            @NetbiosName, @NetbiosComment, @Users, @AgentGUID, @FriendlyName, @IPV4, @IPV6, @MAC,
            @DetectedTime, @SourceType, 0);

        select @HostID = @@IDENTITY;

        set @NewDetection = 1;
    end

	declare @cnt int;
    set @cnt = 0;
    declare @DetectedSourceID int;

    -- if the external id is not null, then we're going to assume there is only one entry if it exists
    -- if there are multiple, this will just randomly pull the first one, as this should have been
    -- merged by this point to that use case should have been cleared by now...
    if (@ExternalID is not null)
    begin
        select @DetectedSourceID = AutoID from [dbo].[RSDDetectedSource]
        where ( HostID = @HostID and SourceID = @SourceID and SourceType = @SourceType and ExternalID = @ExternalID )
    end
    else
    begin
        -- equally, if we're not using the ExternalID, then we only want to update the existing, matching record
        select @DetectedSourceID = AutoID from [dbo].[RSDDetectedSource]
        where (HostID = @HostID and SourceID = @SourceID and SourceType = @SourceType )
    end

    declare @RecordedTime datetime;
    set @RecordedTime = GETUTCDATE();

    if (@DetectedSourceID is not null)
    begin
        update [dbo].[RSDDetectedSource]
        set HostID = @HostID,
            SourceID = @SourceID,
            SourceType = @SourceType,
            ExternalID = @ExternalID,
            LastDetectedTime = @DetectedTime,
            LastRecordedTime = @RecordedTime
        where AutoID = @DetectedSourceID
    end
    else
    begin
        insert into [dbo].[RSDDetectedSource] (HostID, SourceID, SourceType, ExternalID, FirstDetectedTime, LastDetectedTime, FirstRecordedTime, LastRecordedTime)
        values (@HostID, @SourceID, @SourceType, @ExternalID, @DetectedTime, @DetectedTime, @RecordedTime, @RecordedTime);
    end

	-- Updates the Detected System with the matching ManagedSystem, if it exists...
	exec RSDSP_MatchManagedSystems @HostID, @AgentGUID, @MAC, @NetbiosName, @Domain, @DnsName, @IPV4, @IPV6

    -- Gonna need a second stored procedure for the interfaces and subnets, so return the HostID for the
    -- next round of inserts

	set @OutputHostID = @HostID;
    set @OutputNewDetection = @NewDetection;
END
GO


CREATE PROCEDURE [dbo].[RSDSP_GetSubnets]
AS
BEGIN
    Select Distinct
        CONVERT(int, ([dbo].epoConvertIPStringToIPV4(SubnetAddress) - 2147483648)) AS SubnetAddressV4,
        CONVERT(int, ([dbo].epoConvertIPStringToIPV4(SubnetMask) - 2147483648)) AS SubnetMaskV4
    From EPOComputerProperties
    Order By SubnetAddressV4, SubnetMaskV4
END
GO

CREATE PROCEDURE [RSDSP_AddOrUpdateSubnets]
(
    @SubnetAddress nvarchar(15),
    @SubnetMask nvarchar(15)
)
AS
BEGIN
    DECLARE @Validate INT

    -- Validate NetAddress & SubnetMask
    EXEC EPOSP_IsValidAddress @SubnetAddress, @out=@Validate output
    IF (@Validate = 0)
        RETURN
    EXEC EPOSP_IsValidAddress @SubnetMask, @out=@Validate output
    IF (@Validate = 0)
        RETURN

    declare @IPV4 int;
    declare @IPV4mask int;
    declare @IPV6 binary(16);
    declare @IPV6mask binary(16);

    set @IPV4 = [dbo].[RSDFN_ConvertIPStringToInt](@SubnetAddress);
    set @IPV4mask = [dbo].[RSDFN_ConvertIPStringToInt](@SubnetMask);
    set @IPV6 = [dbo].[RSDFN_ConvertIntToIPV6Binary](@IPV4);
    set @IPV6mask = [dbo].[RSDFN_ConvertIntToIPV6Binary](@IPV4mask);

    declare @snid int;
    set @snid = [dbo].[RSDFN_GetSubnetID](@IPV4, @IPV4mask, @IPV6, @IPV6mask);
    -- If this subnet does not exist, then we need to add it...
    if (@snid is null)
    begin
        exec [dbo].[RSDSP_UpdateSubnets] @IPV4, @IPV4mask, @IPV6, @IPV6mask, @snid;
    end

END
GO

CREATE PROCEDURE [dbo].[RSDSP_UpdateDetectedSubnetsWithKnownManagedSubnets]
AS
BEGIN
    declare @subnet nvarchar(15);
    declare @mask nvarchar(15);

    DECLARE @cur CURSOR;
   	SET @cur = CURSOR FOR select distinct SubnetAddress, SubnetMask FROM [dbo].[EPOComputerProperties]

   	-- open the cursor
   	OPEN @cur;

   	-- walk all items in the server cursor
   	FETCH NEXT FROM @cur INTO @subnet, @mask;
   	WHILE @@FETCH_STATUS = 0
   	BEGIN
        exec [dbo].[RSDSP_AddOrUpdateSubnets] @subnet, @mask;
   	FETCH NEXT FROM @cur INTO @subnet, @mask;
   	END;

   	-- close and release the server cursor.
   	CLOSE @cur;
   	DEALLOCATE @cur;
END
GO


CREATE PROCEDURE [dbo].[RSDSP_UpdateOUIs]
(
    @OUIin      nvarchar(6),
    @OrgName    nvarchar(255)
)
AS
BEGIN
    declare @OUI nvarchar(6);
    set @OUI = UPPER(@OUIin);
    
    declare @cnt int;
    select @cnt = count(*) from [dbo].[OUIs] where OUIs.OUI = @OUI;
    if (@cnt = 0)
    begin
        insert into [dbo].[OUIs] (OUI, OrgName) values (@OUI, @OrgName);
    end
END
GO

CREATE PROCEDURE [dbo].[RSDSP_UpdateVMVendorOUIs]
(
    @OUIin    nvarchar(6)
)
AS
BEGIN
    declare @OUI nvarchar(6);
    set @OUI = UPPER(@OUIin);
    
    declare @cnt int;
    select @cnt = count(*) from [dbo].[RSDVMVendorOUIs] where RSDVMVendorOUIs.OUI = @OUI;
    if (@cnt = 0)
    begin
        insert into [dbo].[RSDVMVendorOUIs] (OUI) values (@OUI);
    end
END
GO

CREATE PROCEDURE [dbo].[RSDSP_SetUnknownSubnetName]
(
    @Name       nvarchar(255)
)
AS
BEGIN
	SET NOCOUNT ON;

    update [dbo].[RSDSubnetProperties] set SubnetName = @Name
    where IPV4 = -2147483648 and IPV4mask = 2147483647 and BitBucket = 1
END
GO


CREATE PROCEDURE [dbo].[RSDSP_GetSubnetToRogueCount]
AS
BEGIN
    select top 25 count (RSDDetectedSystemProperties.HostID) as 'count',
        RSDSubnetProperties.SubnetID, RSDSubnetProperties.SubnetName, RSDSubnetProperties.IPV4, RSDSubnetProperties.IPV4mask
    from [dbo].[RSDSubnetProperties]
    inner join [dbo].[RSDInterfaceProperties] on RSDInterfaceProperties.SubnetID = RSDSubnetProperties.SubnetID
    inner join [dbo].[RSDDetectedSystemProperties] on RSDDetectedSystemProperties.HostID = RSDInterfaceProperties.HostID
    where RSDSubnetProperties.Ignored = 0 and
        [dbo].[RSDFN_IsRogueDetectedSystem](RSDDetectedSystemProperties.HostID, GETUTCDATE()) = 1
    group by RSDSubnetProperties.IPV4, RSDSubnetProperties.SubnetName, RSDSubnetProperties.SubnetID, RSDSubnetProperties.IPV4mask
    order by count desc;

END
GO




CREATE PROCEDURE [dbo].[RSDSP_DetectedSystemTransaction_DetectedSystemByHostID]
(
    @HostID int
)
AS
BEGIN
    SET NOCOUNT ON;

    select RSDDetectedSystemProperties.AgentGUID,
        RSDDetectedSystemProperties.LastDetectedTime,
        RSDDetectedSystemProperties.DnsName,
        RSDDetectedSystemProperties.Domain,
        RSDDetectedSystemProperties.NetbiosComment,
        RSDDetectedSystemProperties.NetbiosName,
        RSDDetectedSystemProperties.OSFamily,
        RSDDetectedSystemProperties.OSPlatform,
        RSDDetectedSystemProperties.OSVersion,
        RSDDetectedSystemProperties.Users,
        RSDDetectedSystemProperties.FriendlyName
    from [dbo].[RSDDetectedSystemProperties] where HostID = @HostID;

END
GO

CREATE PROCEDURE [dbo].[RSDSP_DetectedSystemTransaction_InterfacesByHostID]
(
    @HostID int
)
AS
BEGIN
    SET NOCOUNT ON;

    select RSDInterfaceProperties.InterfaceID,
		RSDInterfaceProperties.OUI,
        RSDInterfaceProperties.LastDetectedTime,
		RSDInterfaceProperties.MAC,
        RSDInterfaceProperties.IPV4,
		RSDSubnetProperties.IPV4mask,
		RSDSubnetProperties.IPV4 as IPV4subnet
    from [dbo].[RSDInterfaceProperties] left join [dbo].[RSDSubnetProperties] on RSDInterfaceProperties.SubnetID = RSDSubnetProperties.SubnetID
    where RSDInterfaceProperties.HostID = @HostID;

END
GO

CREATE PROCEDURE [dbo].[RSDSP_DetectedSystemTransaction_DetectedSourceByHostID]
(
    @HostID int
)
AS
BEGIN
    SET NOCOUNT ON;

    select RSDDetectedSource.SourceID,
		RSDDetectedSource.SourceType,
        RSDDetectedSource.ExternalID,
		RSDDetectedSource.FirstDetectedTime,
        RSDDetectedSource.LastDetectedTime,
		RSDDetectedSource.FirstRecordedTime,
        RSDDetectedSource.LastRecordedTime,
		RSDDetectedSourceType.SourceName
    from [dbo].[RSDDetectedSource] left join [dbo].[RSDDetectedSourceType] on RSDDetectedSource.SourceType = RSDDetectedSourceType.SourceType
    where RSDDetectedSource.HostID = @HostID;

END
GO

CREATE PROCEDURE [dbo].[RSDSP_DetectedSourceTransaction_DetectedSourceBySourceAndHostID]
(
    @HostID int,
    @SourceID int,
    @SourceType nvarchar(100),
    @ExternalID nvarchar(1000)
)
AS
BEGIN
    SET NOCOUNT ON;

    if (@ExternalID is null)
    begin
        select RSDDetectedSource.FirstDetectedTime,
            RSDDetectedSource.LastDetectedTime,
            RSDDetectedSource.FirstRecordedTime,
            RSDDetectedSource.LastRecordedTime,
            RSDDetectedSourceType.SourceName
        from [dbo].[RSDDetectedSource]
        left join [dbo].[RSDDetectedSourceType] on RSDDetectedSource.SourceType = RSDDetectedSourceType.SourceType
        where RSDDetectedSource.HostID = @HostID
            and RSDDetectedSource.SourceID = @SourceID
            and RSDDetectedSource.SourceType = @SourceType;
    end
    else
    begin
        select RSDDetectedSource.FirstDetectedTime,
            RSDDetectedSource.LastDetectedTime,
            RSDDetectedSource.FirstRecordedTime,
            RSDDetectedSource.LastRecordedTime,
            RSDDetectedSourceType.SourceName
        from [dbo].[RSDDetectedSource]
        left join [dbo].[RSDDetectedSourceType] on RSDDetectedSource.SourceType = RSDDetectedSourceType.SourceType
        where RSDDetectedSource.HostID = @HostID
            and RSDDetectedSource.SourceID = @SourceID
            and RSDDetectedSource.SourceType = @SourceType
            and RSDDetectedSource.ExternalID = @ExternalID;
    end
END
GO


CREATE PROCEDURE [dbo].[RSDSP_CreateAgentUpdateDetection]
(
    @LeafNodeID   int
)
AS
BEGIN

	declare @DnsName			nvarchar(255);
	declare @OSPlatform         nvarchar(25);
	declare @OSPlatformStr		nvarchar(100);
	declare @OSVersion          nvarchar(128);
	declare @Domain             nvarchar(16);
	declare @NetbiosName        nvarchar(16);
	declare @Users              nvarchar(128);
	declare @AgentGUID          uniqueidentifier;

	declare @IPV4               int;
	declare @MAC                nvarchar(12);
	declare @MACStr             nvarchar(100);

	declare @DetectedTime       datetime;

	declare @SourceType         nvarchar(100);

	declare @OutputHostID		int;
	declare @OutputNewDetection bit;

	declare @IPV4maskStr        nvarchar(50);
	declare @IPV4subnetStr      nvarchar(50);
	declare @IPV4mask           int;
	declare @IPV4subnet         int;

	select @DnsName = EPOComputerProperties.IPHostName,
		@OSPlatformStr = EPOComputerProperties.OSType,
		@OSVersion = EPOComputerProperties.OSVersion,
		@Domain	= SUBSTRING(EPOComputerProperties.DomainName,1,16),
		@NetbiosName = SUBSTRING(EPOComputerProperties.ComputerName,1,16),
		@Users = EPOComputerProperties.UserName,
		@AgentGUID = EPOLeafNode.AgentGUID,
		@IPV4 = EPOComputerProperties.IPV4x,
		@IPV4maskStr = EPOComputerProperties.SubnetMask,
		@IPV4subnetStr = EPOComputerProperties.SubnetAddress,
		@MACStr = EPOComputerProperties.NetAddress
	from EPOLeafNode, EPOComputerProperties
	where EPOLeafNode.AutoID = @LeafNodeID and EPOComputerProperties.ParentID = @LeafNodeID;

    if (@IPV4 is null)
    begin
        return;
    end

    if (@MACStr is not null)
    begin
        set @MAC = UPPER(SUBSTRING(@MACStr,1,12));
    end

	if (@OSPlatformStr like '%Windows%')
	begin
		set @OSPlatform = 'Windows'
	end
	else if (@OSPlatformStr like '%Mac%' or @OSPlatformStr like '%Apple%')
	begin
		set @OSPlatform = 'Macintosh'
	end
	else if (@OSPlatformStr like '%Linux%')
	begin
		set @OSPlatform = 'Linux'
	end
	else if (@OSPlatformStr like '%BSD%')
	begin
		set @OSPlatform = 'BSD'
	end
	else if (@OSPlatformStr like '%IRIX%')
	begin
		set @OSPlatform = 'IRIX'
	end
	else if (@OSPlatformStr like '%HP-UX%')
	begin
		set @OSPlatform = 'HP-UX'
	end
	else if (@OSPlatformStr like '%AIX%')
	begin
		set @OSPlatform = 'AIX'
	end
	else if (@OSPlatformStr like '%Netware%' or @OSPlatformStr like '%Novell%')
	begin
		set @OSPlatform = 'Novell'
	end
	else if (@OSPlatformStr like '%Sun%' or @OSPlatformStr like '%Solaris%')
	begin
		set @OSPlatform = 'Sun'
	end
	else if (@OSPlatformStr like '%Unix%')
	begin
		set @OSPlatform = 'Unix'
	end
	else
	begin
		set @OSPlatform = 'Unknown'
	end

	if (@OSPlatform <> 'Windows')
	begin
		set @NetbiosName = null;
		set @Domain = null;
	end

	set @DetectedTime = GETUTCDATE();

	set @SourceType = 'epo.agent';

	set @IPV4mask = [dbo].[RSDFN_ConvertIPStringToInt] (@IPV4maskStr);
	set @IPV4subnet = [dbo].[RSDFN_ConvertIPStringToInt] (@IPV4subnetStr);

	exec [dbo].[RSDSP_UpdateDetectedSystems] @DnsName, @OSPlatform, null, @OSVersion, @Domain, @NetbiosName,
		null, @Users, @AgentGUID, @IPV4, null, @MAC, @DetectedTime, @LeafNodeID, @SourceType, null,
		@OutputHostID output, @OutputNewDetection output;

	exec [dbo].[RSDSP_UpdateInterfaces] @OutputHostID, @MAC, @IPV4, @IPV4mask, @IPV4subnet,
		null, null, null, @DetectedTime, @LeafNodeID, @SourceType, null;

END
GO





-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------
-- Triggers
-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------

CREATE TRIGGER [TR_RSDCleanup_EPOLeafNode_Delete] ON [dbo].[EPOLeafNode]
FOR DELETE
AS
BEGIN
	set nocount on;

    DECLARE @count int;
    SELECT @count = COUNT(*) FROM deleted;
    if (@count = 0)
        return;

    declare @AgentGUID uniqueidentifier;

	if (@count = 1)
	begin
	    select @AgentGUID = AgentGUID from deleted;
        DELETE RSDDetectedSystemProperties WHERE AgentGUID = @AgentGUID
        DELETE RSDSensorBlacklistTarget WHERE AgentGUID  = @AgentGUID
        DELETE RSDSensorProperties WHERE AgentGUID = @AgentGUID
	end
	else
	begin
		declare @cur cursor;
		set @cur = cursor for select AgentGUID from deleted;
		open @cur;

		fetch next from @cur into @AgentGUID;
		while (@@FETCH_STATUS = 0)
		begin
			DELETE RSDDetectedSystemProperties WHERE AgentGUID = @AgentGUID
			DELETE RSDSensorBlacklistTarget WHERE AgentGUID  = @AgentGUID
			DELETE RSDSensorProperties WHERE AgentGUID = @AgentGUID
			fetch next from @cur into @AgentGUID;
		end
		close @cur;
		deallocate @cur;
	end
END
GO

-- on RSDSubnet ignore, find RSDDetectedSystems to also ignore
CREATE TRIGGER [dbo].[TR_RSDSubnetProperties_OnUpdate] ON [dbo].[RSDSubnetProperties]
AFTER UPDATE
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF (UPDATE(Ignored))
	BEGIN
		-- build subnets that changed their ignored state.
        DECLARE @tblSubnets TABLE(SubnetID int, Ignored bit);
        INSERT INTO @tblSubnets(SubnetID, Ignored)
        	SELECT inserted.SubnetID as SubnetID, inserted.Ignored as Ignored
            FROM inserted INNER JOIN deleted
            ON inserted.SubnetID = deleted.SubnetID
            WHERE inserted.Ignored = 0 AND deleted.Ignored = 1
            OR inserted.Ignored = 1 AND deleted.Ignored = 0

        -- if a subnet moves from an ignore to an include state, there won't
        -- be any associations with that subnet to deal with until they're
        -- re-detected

		-- delete any detected system that had all interfaces in ignored subnets
        DELETE FROM RSDDetectedSystemProperties
        WHERE HostID IN
        	(SELECT DISTINCT RSDInterfaceProperties.HostID
            FROM RSDInterfaceProperties
            INNER JOIN @tblSubnets A ON RSDInterfaceProperties.SubnetID = A.SubnetID
           	WHERE A.Ignored = 1
            AND RSDInterfaceProperties.HostID NOT IN
            	(SELECT HostID FROM RSDInterfaceProperties
                WHERE SubnetID IN
                	(SELECT SubnetID FROM RSDSubnetProperties WHERE Ignored = 0)));
	END
END
GO


-- on RSDSubnet deletion::
CREATE TRIGGER [dbo].[TR_RSDSubnetProperties_OnDelete] ON [dbo].[RSDSubnetProperties]
AFTER DELETE
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	BEGIN

		-- delete any detected system that no longer has active interfaces;
		-- this is kind of costly but the cascading delete of the subnet
		-- wipes out the interface table for that subnet
		-- so there's no longer a meaningful way to map to it
        DELETE FROM RSDDetectedSystemProperties
        WHERE HostID NOT IN
            	(SELECT HostID FROM RSDInterfaceProperties
                WHERE SubnetID IN
                	(SELECT SubnetID FROM RSDSubnetProperties WHERE Ignored = 0));
	END
END
GO

CREATE TRIGGER [dbo].[TR_RSDInterfaceProperties_OnInsert]
   ON  [dbo].[RSDInterfaceProperties]
   FOR INSERT, UPDATE
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- invoke user-defined translation function for all all affected IP address columns
	-- get the inserted
	IF (UPDATE(IPV4))
	BEGIN
		UPDATE RSDInterfaceProperties
		SET IPV6 = 0x0000 + 0x0000 + 0x0000 + 0x0000 + 0x0000 + 0xFFFF + [dbo].[RSDFN_ConvertIntToIPV4Binary](B.IPV4)
		FROM inserted AS A INNER JOIN RSDInterfaceProperties AS B
		ON A.InterfaceID = B.InterfaceID;
	END
END
GO

CREATE TRIGGER [dbo].[TR_RSDDetectedSystemProperties_OnInsert]
   ON  [dbo].[RSDDetectedSystemProperties]
   FOR INSERT, UPDATE
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- invoke user-defined translation function for all all affected IP address columns
	-- get the inserted
	IF (UPDATE(IPV4))
	BEGIN
		UPDATE RSDDetectedSystemProperties
		SET IPV6 = 0x0000 + 0x0000 + 0x0000 + 0x0000 + 0x0000 + 0xFFFF + [dbo].[RSDFN_ConvertIntToIPV4Binary](B.IPV4)
		FROM inserted AS A INNER JOIN RSDDetectedSystemProperties AS B
		ON A.HostID = B.HostID;
	END
END
GO

CREATE TRIGGER [dbo].[TR_RSDSubnetProperties_OnInsert]
   ON  [dbo].[RSDSubnetProperties]
   FOR INSERT, UPDATE
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- invoke user-defined translation function for all all affected IP address columns
	-- get the inserted
	IF (UPDATE(IPV4))
	BEGIN
		UPDATE RSDSubnetProperties
		SET IPV6 = 0x0000 + 0x0000 + 0x0000 + 0x0000 + 0x0000 + 0xFFFF + [dbo].[RSDFN_ConvertIntToIPV4Binary](B.IPV4)
		FROM inserted AS A INNER JOIN RSDSubnetProperties AS B
		ON A.SubnetID = B.SubnetID;
	END

	IF (UPDATE(IPV4mask))
	BEGIN
		UPDATE RSDSubnetProperties
		SET IPV6mask = 0x0000 + 0x0000 + 0x0000 + 0x0000 + 0x0000 + 0xFFFF + [dbo].[RSDFN_ConvertIntToIPV4Binary](B.IPV4mask)
		FROM inserted AS A INNER JOIN RSDSubnetProperties AS B
		ON A.SubnetID = B.SubnetID;
	END
END
GO

CREATE TRIGGER [dbo].[TR_RSDSubnetProperties_EPOComputerProperties_OnInsert]
   ON  [dbo].[EPOComputerProperties]
   FOR INSERT, UPDATE
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- invoke user-defined translation function for all all affected IP address columns
	-- get the inserted
	IF (UPDATE(SubnetAddress) or UPDATE(SubnetMask))
	BEGIN
	    declare @SubnetAddress nvarchar(15);
	    declare @SubnetMask nvarchar(15);

	    select @SubnetAddress=SubnetAddress, @SubnetMask=SubnetMask from inserted;

        exec [dbo].[RSDSP_AddOrUpdateSubnets] @SubnetAddress, @SubnetMask;
	END
END
GO


-- Add a "detected system" on an agent update event
CREATE TRIGGER [dbo].[TR_RSDDetected_EPOLeafNode_OnUpdate] ON [dbo].[EPOLeafNode]
AFTER UPDATE
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @count int;
    SELECT @count = COUNT(*) FROM inserted;
    if (@count = 0 or not (UPDATE(LastUpdate)))
        return;

	-- Select the "detected system" properties
	declare @LeafNodeID int;
	declare @AgentGUID uniqueidentifier;
	declare @HostID int;
	declare @LastDetectedTime datetime;

	if (@count = 1)
	begin
        select @LeafNodeID = AutoID, @AgentGUID = AgentGUID from inserted;

		if (@AgentGUID is not null)
		begin
			select @HostID = HostID, @LastDetectedTime = LastDetectedTime from RSDDetectedSystemProperties where AgentGUID = @AgentGUID;
			if (@HostID is null or (@HostID > 0 and @LastDetectedTime < DATEADD(day, -7, GETUTCDATE())))
			begin
				exec [dbo].[RSDSP_CreateAgentUpdateDetection] @LeafNodeID;
			end
		end
	end
	else
	begin
	
		declare @cur cursor;
		set @cur = cursor for select AutoID, AgentGUID from inserted;
		open @cur;

		fetch next from @cur into @LeafNodeID, @AgentGUID;
		while (@@FETCH_STATUS = 0)
		begin
			if (@AgentGUID is not null)
			begin
				select @HostID = HostID, @LastDetectedTime = LastDetectedTime from RSDDetectedSystemProperties where AgentGUID = @AgentGUID;
    			if (@HostID is null or (@HostID > 0 and @LastDetectedTime < DATEADD(day, -7, GETUTCDATE())))
				begin
					exec [dbo].[RSDSP_CreateAgentUpdateDetection] @LeafNodeID;
				end
			end
			fetch next from @cur into @LeafNodeID, @AgentGUID;
		end
		close @cur;
		deallocate @cur;

	end
END
GO
