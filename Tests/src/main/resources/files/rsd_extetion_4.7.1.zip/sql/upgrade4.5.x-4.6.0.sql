
IF  EXISTS (SELECT * FROM [dbo].[sysindexes] WHERE id = OBJECT_ID(N'[dbo].[RSDDetectedSystemProperties]') AND name = N'IX_RSDDetectedSystemProperties_MAC')
DROP INDEX [dbo].[RSDDetectedSystemProperties].[IX_RSDDetectedSystemProperties_MAC]
GO

CREATE NONCLUSTERED INDEX [IX_RSDDetectedSystemProperties_MAC] ON [dbo].[RSDDetectedSystemProperties]
(
    [MAC] ASC
) ON [PRIMARY]
GO

-- BZ626753: Home Page Performance
IF  EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[RSDDetectedSystemProperties]') AND name = N'IX_RSDDetectedSystemProperties_HostID_LastDetectedTime_Exception_AgentGUID')
	DROP INDEX [IX_RSDDetectedSystemProperties_HostID_LastDetectedTime_Exception_AgentGUID] ON [dbo].[RSDDetectedSystemProperties];
GO
IF  EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[RSDDetectedSystemProperties]') AND name = N'IDX_RSDDetectedSystemProperties_HostID_LastDetectedTime_Exception_AgentGUID')
	DROP INDEX [IDX_RSDDetectedSystemProperties_HostID_LastDetectedTime_Exception_AgentGUID] ON [dbo].[RSDDetectedSystemProperties];
GO
CREATE NONCLUSTERED INDEX [IDX_RSDDetectedSystemProperties_HostID_LastDetectedTime_Exception_AgentGUID] ON [dbo].[RSDDetectedSystemProperties]
(
	[HostID] ASC,
	[LastDetectedTime] ASC,
	[Exception] ASC,
	[AgentGUID] ASC
);
GO

-- BZ626753: Home Page Performance
IF  EXISTS (SELECT * FROM dbo.sysindexes  WHERE id = OBJECT_ID(N'[dbo].[RSDSensorToSubnet]') AND name = N'IX_RSDSensorToSubnet_SensorID_SubnetID')
	DROP INDEX [IX_RSDSensorToSubnet_SensorID_SubnetID] ON [dbo].[RSDSensorToSubnet];
GO
IF  EXISTS (SELECT * FROM dbo.sysindexes  WHERE id = OBJECT_ID(N'[dbo].[RSDSensorToSubnet]') AND name = N'IDX_RSDSensorToSubnet_SensorID_SubnetID')
	DROP INDEX [IDX_RSDSensorToSubnet_SensorID_SubnetID] ON [dbo].[RSDSensorToSubnet];
GO
CREATE NONCLUSTERED INDEX [IDX_RSDSensorToSubnet_SensorID_SubnetID] ON [dbo].[RSDSensorToSubnet]
(
	[SensorID] ASC,
	[SubnetID] ASC
);
GO



IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_FindSensorNameForHostID]') )
DROP FUNCTION [dbo].[RSDFN_FindSensorNameForHostID]
GO

CREATE FUNCTION [dbo].[RSDFN_FindSensorNameForHostID]
(
	@HostID int
)
RETURNS nvarchar(255)
AS
BEGIN
	declare @SensorName nvarchar(255);

	select top 1 @SensorName = SensorName
		from RSDSensorProperties as sen
		left outer join RSDDetectedSource as dsrc on dsrc.SourceID = sen.SensorID
		left outer join RSDDetectedSystemProperties as dsys on dsys.HostID = dsrc.HostID
	where dsrc.HostID = @HostID;

	return @SensorName;
END
GO


IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_SystemAlreadyHasSensorDeploymentClientTask]') )
DROP FUNCTION [dbo].[RSDFN_SystemAlreadyHasSensorDeploymentClientTask]
GO


CREATE FUNCTION [dbo].[RSDFN_SystemAlreadyHasSensorDeploymentClientTask]
(
	@LeafNodeID int
)
RETURNS bit
AS
BEGIN
	-- added in response to bug 414160
	DECLARE @cnt int;

	select @cnt = COUNT(*) from EPOTaskObjects
		left join EPOTaskTypes on EPOTaskObjects.TaskTypeId = EPOTaskTypes.TaskTypeId
		left join EPOTaskAssignments on EPOTaskObjects.TaskObjectId = EPOTaskAssignments.TaskObjectId
		left join EPOTaskObjectSettings on EPOTaskObjects.TaskObjectId = EPOTaskObjectSettings.TaskObjectId
	where EPOTaskTypes.ProductCode = 'SNOWCAP_2000' and EPOTaskTypes.TaskType = 'SensorDeployment' and
		EPOTaskAssignments.NodeId = @LeafNodeID and
		EPOTaskObjectSettings.SectionName = 'Install' and
		EPOTaskObjectSettings.SettingName = 'NumInstalls' and
		EPOTaskObjectSettings.SettingValue = '1'

    if (@cnt = 1)
        return 1;

	return 0;
END
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_BlacklistSystemByAgentGUID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_BlacklistSystemByAgentGUID]
GO


CREATE PROCEDURE [dbo].[RSDSP_BlacklistSystemByAgentGUID]
(
    @AgentGUID          uniqueidentifier,
    @AddSystem          bit,
    @HasSensor          bit OUTPUT,
    @ComputerName       nvarchar(255) OUTPUT,
    @OutputAgentGUID    uniqueidentifier OUTPUT,
    @DidWork            bit OUTPUT
)
AS
BEGIN
    exec [dbo].[RSDSP_ManagedSystemHasSensorByAgentGUID] @AgentGUID, @HasSensor OUTPUT, @ComputerName OUTPUT;
    set @DidWork = 0;

    if (@AgentGUID is not null)
    begin
		select @OutputAgentGUID = AgentGUID from RSDSensorBlacklistTarget where AgentGUID = @AgentGUID;
        if (@AddSystem = 0)
        begin
			if (@OutputAgentGUID is not null)
			begin
				exec RSDSP_RemoveFromSensorBlacklist @AgentGUID;
				set @DidWork = 1;
			end
        end
        else
        begin
            declare @lnid int;
            select @lnid = AutoId from EPOLeafNode where AgentGUID = @AgentGUID;
            set @HasSensor = [dbo].[RSDFN_SystemAlreadyHasSensorDeploymentClientTask](@lnid);
            if (@HasSensor = 0 and @OutputAgentGUID is null)
            begin
                exec RSDSP_AddToSensorBlacklist null, @AgentGUID, @OutputAgentGUID OUTPUT;
                set @DidWork = 1;
            end
        end
    end
END
GO


-------------------------------------------------------------------------------
-- Begin: Update to RSD cleanup for EPOLeafNode triggers
-- Purpose: Considerably improve performance of mass-delete operations.
-- Function: Removes use of CURSOR enumerations, instead using JOIN operations.

EXEC [EPOCore_DropTrigger] N'TR_RSDCleanup_EPOLeafNode_Delete'
GO
CREATE TRIGGER [dbo].[TR_RSDCleanup_EPOLeafNode_Delete] ON [dbo].[EPOLeafNode]
FOR DELETE
AS
BEGIN

    DECLARE @count int;
    SELECT @count = COUNT(*) FROM deleted;
    if (@count = 0)
        return;
	
    SET NOCOUNT ON;
    
    -- detected system properties        
    DELETE RSDDetectedSystemProperties
    FROM deleted INNER JOIN RSDDetectedSystemProperties
    ON (deleted.AgentGUID = RSDDetectedSystemProperties.AgentGUID)
    WHERE (deleted.AgentGUID IS NOT NULL);
    
    -- blacklists
    DELETE RSDSensorBlacklistTarget
    FROM deleted INNER JOIN RSDSensorBlacklistTarget
    ON (deleted.AgentGUID = RSDSensorBlacklistTarget.AgentGUID)
    WHERE (deleted.AgentGUID IS NOT NULL);
    
    -- sensor properties
    DELETE RSDSensorProperties
    FROM deleted INNER JOIN RSDSensorProperties
    ON (deleted.AgentGUID = RSDSensorProperties.AgentGUID)
    WHERE (deleted.AgentGUID IS NOT NULL);
    
    -- unmanaged links
    DELETE RSDUnmanagedSystemsLink
    FROM deleted INNER JOIN RSDUnmanagedSystemsLink
    ON (deleted.AutoID = RSDUnmanagedSystemsLink.EPOLeafNodeID);
END
GO
-- End: Update to RSD cleanup for EPOLeafNode triggers
-------------------------------------------------------------------------------
