-- Upgrade from 2.0.0 to the ePO 4.5.0 code base
-- This includes any and all 2.0.x patches known prior to shipping 4.5.0

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go


-- Need to update the configuration RSD API schema version numbers
update [dbo].[RSDConfiguration]
set APISchemaVersion = 4500,
    RSDSchemaVersion = 4500
where ID = 1
GO


-- update RSDInterfaceProperties to contain subnet and subnetmask values
IF NOT EXISTS (SELECT * FROM [dbo].[syscolumns] WHERE id = OBJECT_ID(N'[dbo].[RSDInterfaceProperties]') AND [name] = 'IPV6Subnet')
BEGIN
	ALTER TABLE [dbo].[RSDInterfaceProperties]
		ADD [IPV6Subnet] [binary](16) NULL
END
GO
IF NOT EXISTS (SELECT * FROM [dbo].[syscolumns] WHERE id = OBJECT_ID(N'[dbo].[RSDInterfaceProperties]') AND [name] = 'IPV6Mask')
BEGIN
	ALTER TABLE [dbo].[RSDInterfaceProperties]
		ADD [IPV6Mask] [binary](16) NULL
END
GO

-- changes to RSDSubnetProperties. add subnet ranges.
IF NOT EXISTS (SELECT * FROM [dbo].[syscolumns] WHERE id = OBJECT_ID(N'[dbo].[RSDSubnetProperties]') AND [name] = 'IPV6Start')
BEGIN
	-- add subnet ranges
	ALTER TABLE [dbo].[RSDSubnetProperties]
		ADD [IPV6Start] [binary](16) NULL
END
GO
IF NOT EXISTS (SELECT * FROM [dbo].[syscolumns] WHERE id = OBJECT_ID(N'[dbo].[RSDSubnetProperties]') AND [name] = 'IPV6End')
BEGIN
	ALTER TABLE [dbo].[RSDSubnetProperties]
		ADD [IPV6End] [binary](16) NULL
END
GO


IF NOT EXISTS (SELECT * FROM [dbo].[sysobjects] WHERE id = object_id(N'[dbo].[RSDUnmanagedSystemsLink]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
    CREATE TABLE [dbo].[RSDUnmanagedSystemsLink] (
        [DetectedSystemHostID]      int NOT NULL,
        [EPOLeafNodeID]             int NOT NULL
    ) ON [PRIMARY]
GO

IF NOT EXISTS (SELECT * FROM [dbo].[sysobjects] WHERE id = OBJECT_ID(N'[dbo].[PK_RSDUnmanagedSystemsLink]') and type = 'K')
    ALTER TABLE [dbo].[RSDUnmanagedSystemsLink] WITH NOCHECK ADD
        CONSTRAINT [PK_RSDUnmanagedSystemsLink] PRIMARY KEY  CLUSTERED
        (
            [DetectedSystemHostID],
            [EPOLeafNodeID]
        )  ON [PRIMARY]
GO


IF NOT EXISTS (SELECT * FROM [dbo].[sysobjects] WHERE id = object_id(N'[dbo].[RSDScanBlacklist]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
    CREATE TABLE [dbo].[RSDScanBlacklist] (
        [MACorOUI]      nvarchar(12) UNIQUE NOT NULL
    ) ON [PRIMARY]
GO

--IF NOT EXISTS (SELECT * FROM [dbo].[sysobjects] WHERE id = object_id(N'[dbo].[RSDReportBlacklist]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
--    CREATE TABLE [dbo].[RSDReportBlacklist] (
--        [MACorOUI]      nvarchar(12) UNIQUE NOT NULL
--    ) ON [PRIMARY]
--GO

--IF NOT EXISTS (SELECT * FROM [dbo].[sysobjects] WHERE id = object_id(N'[dbo].[RSDGlobalPolicySettings]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
--    CREATE TABLE [dbo].[RSDGlobalPolicySettings] (
--		[ID]                int UNIQUE NOT NULL,
--		[UpdateExceptions]	bit NOT NULL DEFAULT 0,
--		[UpdateScan]        bit NOT NULL DEFAULT 0,
--        [UpdateReport]      bit NOT NULL DEFAULT 0
--    ) ON [PRIMARY]
--GO

--delete from [dbo].[RSDGlobalPolicySettings]
--GO

--insert into [dbo].[RSDGlobalPolicySettings] (ID) values (1)
--GO


-- given an IPV6 address, returns the minimum address based on the addr and subnet mask
EXEC EPOCore_DropFunction N'RSDFN_IPV6SubnetAddrStart';
GO
CREATE FUNCTION [dbo].[RSDFN_IPV6SubnetAddrStart](@IPV6 binary(16), @IPV6Mask binary(16))
RETURNS binary(16)
AS
BEGIN
	-- All the IPV6 bits
	declare @andhighv4 bigint;
	declare @andlowv4 bigint;
	set @andhighv4 = 0x0000000000000000;
	set @andlowv4 = 0x0000FFFFFFFFFFFF;

	declare @andhighv6 bigint;
	declare @andlowv6 bigint;
	set @andhighv6 = 0xFFFFFFFFFFFFFFFF;
	set @andlowv6 = 0xFFFFFFFFFFFFFFFF;

	declare @andhigh bigint;
	declare @andlow bigint;

	declare @nethigh bigint;
	declare @netlow bigint;
	declare @maskhigh bigint;
	declare @masklow bigint;

	declare @miniph bigint;
	declare @minipl bigint;
	declare @maxiph bigint;
	declare @maxipl bigint;

	if ([dbo].[RSDFN_IsIPAddressIPv4Compatible](@IPV6) = 1 and [dbo].[RSDFN_IsIPAddressIPv4Compatible](@IPV6Mask) = 1)
	begin
		set @andhigh = @andhighv4;
		set @andlow = @andlowv4;
	end
	else
	begin
		set @andhigh = @andhighv6;
		set @andlow = @andlowv6;
	end

	set @nethigh = convert(bigint, substring(@IPV6, 1, 8));
	set @netlow = convert(bigint, substring(@IPV6, 9, 8));
	set @maskhigh = convert(bigint, substring(@IPV6Mask, 1, 8));
	set @masklow = convert(bigint, substring(@IPV6Mask, 9, 8));
	set @miniph = @nethigh & @maskhigh;
	set @minipl = @netlow & @masklow;

	return convert(binary(8), @miniph) + convert(binary(8), @minipl);
END
GO

EXEC EPOCore_DropFunction N'RSDFN_IPV6SubnetAddrEnd';
GO
CREATE FUNCTION [dbo].[RSDFN_IPV6SubnetAddrEnd](@IPV6 binary(16), @IPV6Mask binary(16))
RETURNS binary(16)
AS
BEGIN
	-- All the IPV6 bits
	declare @andhighv4 bigint;
	declare @andlowv4 bigint;
	set @andhighv4 = 0x0000000000000000;
	set @andlowv4 = 0x0000FFFFFFFFFFFF;

	declare @andhighv6 bigint;
	declare @andlowv6 bigint;
	set @andhighv6 = 0xFFFFFFFFFFFFFFFF;
	set @andlowv6 = 0xFFFFFFFFFFFFFFFF;

	declare @andhigh bigint;
	declare @andlow bigint;

	declare @nethigh bigint;
	declare @netlow bigint;
	declare @maskhigh bigint;
	declare @masklow bigint;

	declare @miniph bigint;
	declare @minipl bigint;
	declare @maxiph bigint;
	declare @maxipl bigint;

	if ([dbo].[RSDFN_IsIPAddressIPv4Compatible](@IPV6) = 1 and [dbo].[RSDFN_IsIPAddressIPv4Compatible](@IPV6Mask) = 1)
	begin
		set @andhigh = @andhighv4;
		set @andlow = @andlowv4;
	end
	else
	begin
		set @andhigh = @andhighv6;
		set @andlow = @andlowv6;
	end

	set @nethigh = convert(bigint, substring(@IPV6, 1, 8));
	set @netlow = convert(bigint, substring(@IPV6, 9, 8));
	set @maskhigh = convert(bigint, substring(@IPV6Mask, 1, 8));
	set @masklow = convert(bigint, substring(@IPV6Mask, 9, 8));
	set @miniph = @nethigh & @maskhigh;
	set @minipl = @netlow & @masklow;
	set @maxiph = @miniph | ( (~@maskhigh) & @andhigh );
	set @maxipl = @minipl | ( (~@masklow) & @andlow );

	return convert(binary(8), @maxiph) + convert(binary(8), @maxipl);
END
GO




-- Fix the issue with the Domain only being 16 chars...
IF EXISTS(SELECT * FROM [dbo].[syscolumns] WHERE id = OBJECT_ID(N'[dbo].[RSDDetectedSystemProperties]') AND [name] = N'Domain')
	ALTER TABLE [dbo].[RSDDetectedSystemProperties]	ALTER COLUMN [Domain] [nvarchar](255) NULL
GO


-- This tries to select and match the incoming detected system with existing managed machines
EXEC EPOCore_DropStoredProc N'RSDSP_MatchDetectedSystems';
GO
CREATE PROCEDURE [dbo].[RSDSP_MatchDetectedSystems]
(
    @AgentGUID          uniqueidentifier,
	@SourceID			int,
	@SourceType			nvarchar(100),
	@ExternalID			nvarchar(1000),
    @MAC                nvarchar(12),
    @ComputerName       nvarchar(16),
    @Domain             nvarchar(255),
    @DnsName            nvarchar(255),
    @IPV4               int,
    @IPV6               binary (16),
	@HostID				int output
)
AS
BEGIN
    declare @detectedMatching    int;

    -- The Configuration ID by default should always be 1
    select @detectedMatching = [RSDConfiguration].[DetectedMatching]
        from [dbo].[RSDConfiguration]
        where [RSDConfiguration].[ID] = 1;

    declare @useAgentGUID       bit;
    declare @useProductGUID     bit;
    declare @useMAC             bit;
    declare @useHostnameDomain  bit;
    declare @useDNSName         bit;
    declare @useIPAddress       bit;
    declare @useHostname        bit;

    set @useAgentGUID = @detectedMatching & 0x1;
    set @useProductGUID = @detectedMatching & 0x2;
    set @useMAC = @detectedMatching & 0x10;
    set @useHostnameDomain = @detectedMatching & 0x20;
    set @useDNSName = @detectedMatching & 0x40;
    set @useIPAddress = @detectedMatching & 0x80;
    set @useHostname = @detectedMatching & 0x100;

    declare @found bit;
	declare @done bit;
	declare @cnt int;
	declare @results table (
		HostID				int,
		AgentGUID		    uniqueidentifier,
		SourceID			int,
		SourceType			nvarchar(100),
		ExternalID			nvarchar(1000),
		MAC					nvarchar(12),
		ComputerName		nvarchar(16),
		Domain				nvarchar(255),
		DnsName				nvarchar(255),
		IPV4				int,
		IPV6				binary (16),
		LastDetectedTime	datetime
	);

    set @found = 0;
	set @done = 0;
	set @cnt = 0;

	-- Check for a match on the agent guid
    if (@AgentGUID is not null and @useAgentGUID = 1)
    begin
		insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
			select [RSDDetectedSystemProperties].[HostID],
				   [RSDDetectedSystemProperties].[AgentGUID],
				   [RSDDetectedSource].[SourceID],
				   [RSDDetectedSource].[SourceType],
				   [RSDDetectedSource].[ExternalID],
				   [RSDInterfaceProperties].[MAC],
				   [RSDDetectedSystemProperties].[NetbiosName],
				   [RSDDetectedSystemProperties].[Domain],
				   [RSDDetectedSystemProperties].[DnsName],
				   [RSDInterfaceProperties].[IPV4],
				   [RSDInterfaceProperties].[IPV6],
				   [RSDDetectedSystemProperties].[LastDetectedTime]
			from [RSDDetectedSystemProperties] WITH (NOLOCK)
				 inner join [RSDInterfaceProperties] WITH (NOLOCK)
					on [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
				 inner join [RSDDetectedSource] WITH (NOLOCK)
					on [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
			where [RSDDetectedSystemProperties].[AgentGUID] = @AgentGUID;

		select @cnt = count(*) from @results;
		if (@cnt = 1)
		begin
			select @HostID = HostID from @results;
			set @done = 1;
		end
		if (@cnt > 1)
		begin
			set @found = 1;
		end
    end

	-- Like AgentGUID - this should uniquely identify a single system, if not, then we fall through to the user
	-- defined selections
	if (@done = 0 and @SourceType is not null and @ExternalID is not null and @useProductGUID = 1)
	begin
		insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
			select [RSDDetectedSystemProperties].[HostID],
				   [RSDDetectedSystemProperties].[AgentGUID],
				   [RSDDetectedSource].[SourceID],
				   [RSDDetectedSource].[SourceType],
				   [RSDDetectedSource].[ExternalID],
				   [RSDInterfaceProperties].[MAC],
				   [RSDDetectedSystemProperties].[NetbiosName],
				   [RSDDetectedSystemProperties].[Domain],
				   [RSDDetectedSystemProperties].[DnsName],
				   [RSDInterfaceProperties].[IPV4],
				   [RSDInterfaceProperties].[IPV6],
				   [RSDDetectedSystemProperties].[LastDetectedTime]
			from [RSDDetectedSystemProperties] WITH (NOLOCK)
				 inner join [RSDInterfaceProperties] WITH (NOLOCK)
					on [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
				 inner join [RSDDetectedSource] WITH (NOLOCK)
					on [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
			where [RSDDetectedSource].[SourceType] = @SourceType
				and [RSDDetectedSource].[ExternalID] = @ExternalID;

		select @cnt = count(*) from @results;
		if (@cnt = 1)
		begin
			set @done = 1;
			select @HostID = HostID from @results;
		end
		if (@cnt > 1)
		begin
			set @found = 1;
		end
	end


	-- Check for a match on the MAC address...
	if (@done = 0 and @MAC is not null and @useMAC = 1)
	begin
		if (@found = 0)
		begin
			insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
				select [RSDDetectedSystemProperties].[HostID],
					   [RSDDetectedSystemProperties].[AgentGUID],
					   [RSDDetectedSource].[SourceID],
					   [RSDDetectedSource].[SourceType],
					   [RSDDetectedSource].[ExternalID],
					   [RSDInterfaceProperties].[MAC],
					   [RSDDetectedSystemProperties].[NetbiosName],
					   [RSDDetectedSystemProperties].[Domain],
					   [RSDDetectedSystemProperties].[DnsName],
					   [RSDInterfaceProperties].[IPV4],
					   [RSDInterfaceProperties].[IPV6],
					   [RSDDetectedSystemProperties].[LastDetectedTime]
				from [RSDDetectedSystemProperties] WITH (NOLOCK)
					 inner join [RSDInterfaceProperties] WITH (NOLOCK)
						on [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
					 inner join [RSDDetectedSource] WITH (NOLOCK)
						on [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
				where [RSDInterfaceProperties].[MAC] = @MAC;

			select @cnt = count(*) from @results;
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		else
		begin
			-- need to get the most recent, in case we drop to 0 in our count...
			select @HostID = HostID from @results order by LastDetectedTime desc;

			delete R from @results as R  where MAC <> @MAC;

			select @cnt = count(*) from @results;
			if (@cnt = 0)
			begin
				-- use the host that was most recently detected
				set @done = 1;
			end
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end

		end
	end

	-- Next, do the ComputerName/Domain pair
	if (@done = 0 and @ComputerName is not null and @Domain is not null and @useHostnameDomain = 1)
	begin
		if (@found = 0)
		begin
			insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
				select [RSDDetectedSystemProperties].[HostID],
					   [RSDDetectedSystemProperties].[AgentGUID],
					   [RSDDetectedSource].[SourceID],
					   [RSDDetectedSource].[SourceType],
					   [RSDDetectedSource].[ExternalID],
					   [RSDInterfaceProperties].[MAC],
					   [RSDDetectedSystemProperties].[NetbiosName],
					   [RSDDetectedSystemProperties].[Domain],
					   [RSDDetectedSystemProperties].[DnsName],
					   [RSDInterfaceProperties].[IPV4],
					   [RSDInterfaceProperties].[IPV6],
					   [RSDDetectedSystemProperties].[LastDetectedTime]
				from [RSDDetectedSystemProperties] WITH (NOLOCK)
					 inner join [RSDInterfaceProperties] WITH (NOLOCK)
						on [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
					 inner join [RSDDetectedSource] WITH (NOLOCK)
						on [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
				where [RSDDetectedSystemProperties].[NetbiosName] = @ComputerName
					and [RSDDetectedSystemProperties].[Domain] = @Domain;

			select @cnt = count(*) from @results;
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		else
		begin
			-- need to get the most recent, in case we drop to 0 in our count...
			select @HostID = HostID from @results order by LastDetectedTime desc;

			delete R from @results as R  where ComputerName <> @ComputerName and Domain <> @Domain;

			select @cnt = count(*) from @results;
			if (@cnt = 0)
			begin
				-- use the host that was most recently detected
				set @done = 1;
			end
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end

		end
	end

	-- Use DNS name
	if (@done = 0 and @DnsName is not null and @useDNSName = 1)
	begin
		if (@found = 0)
		begin
			insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
				select [RSDDetectedSystemProperties].[HostID],
					   [RSDDetectedSystemProperties].[AgentGUID],
					   [RSDDetectedSource].[SourceID],
					   [RSDDetectedSource].[SourceType],
					   [RSDDetectedSource].[ExternalID],
					   [RSDInterfaceProperties].[MAC],
					   [RSDDetectedSystemProperties].[NetbiosName],
					   [RSDDetectedSystemProperties].[Domain],
					   [RSDDetectedSystemProperties].[DnsName],
					   [RSDInterfaceProperties].[IPV4],
					   [RSDInterfaceProperties].[IPV6],
					   [RSDDetectedSystemProperties].[LastDetectedTime]
				from [RSDDetectedSystemProperties] WITH (NOLOCK)
					 inner join [RSDInterfaceProperties] WITH (NOLOCK)
						on [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
					 inner join [RSDDetectedSource] WITH (NOLOCK)
						on [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
				where [RSDDetectedSystemProperties].[DnsName] = @DnsName;

			select @cnt = count(*) from @results;
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		else
		begin
			-- need to get the most recent, in case we drop to 0 in our count...
			select @HostID = HostID from @results order by LastDetectedTime desc;

			delete R from @results as R where DnsName <> @DnsName;

			select @cnt = count(*) from @results;
			if (@cnt = 0)
			begin
				-- use the host that was most recently detected
				set @done = 1;
			end
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end

		end
	end

	-- This is the IP Address check, it's gonna be a little nasty...
	if (@done = 0 and ( @IPV4 is not null or @IPV6 is not null) and @useIPAddress = 1)
	begin
		-- convert IPV4 to IPV6 so we can just use a single algorithm :)
		declare @ipaddr binary(16);
		if (@IPV4 is not null)
		begin
			set @ipaddr = [dbo].[RSDFN_ConvertIntToIPV6Binary](@IPV4);
		end
		else
		begin
			set @ipaddr = @IPV6;
		end

		-- We only want to do anything if this IPAddress falls in the correct range
		if ([dbo].[RSDFN_IsInRSDConfigurationIPRange](@ipaddr) = 1)
		begin
			if (@found = 0)
			begin
				if (@IPV4 is not null)
				begin
                    insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
                        select [RSDDetectedSystemProperties].[HostID],
                               [RSDDetectedSystemProperties].[AgentGUID],
                               [RSDDetectedSource].[SourceID],
                               [RSDDetectedSource].[SourceType],
                               [RSDDetectedSource].[ExternalID],
                               [RSDInterfaceProperties].[MAC],
                               [RSDDetectedSystemProperties].[NetbiosName],
                               [RSDDetectedSystemProperties].[Domain],
                               [RSDDetectedSystemProperties].[DnsName],
                               [RSDInterfaceProperties].[IPV4],
                               [RSDInterfaceProperties].[IPV6],
                               [RSDDetectedSystemProperties].[LastDetectedTime]
						from [RSDDetectedSystemProperties] WITH (NOLOCK)
							 inner join [RSDInterfaceProperties] WITH (NOLOCK)
								on [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
							 inner join [RSDDetectedSource] WITH (NOLOCK)
								on [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
						where [RSDInterfaceProperties].[IPV4] = @IPV4;
				end
				else
				begin
                    insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
                        select [RSDDetectedSystemProperties].[HostID],
                               [RSDDetectedSystemProperties].[AgentGUID],
                               [RSDDetectedSource].[SourceID],
                               [RSDDetectedSource].[SourceType],
                               [RSDDetectedSource].[ExternalID],
                               [RSDInterfaceProperties].[MAC],
                               [RSDDetectedSystemProperties].[NetbiosName],
                               [RSDDetectedSystemProperties].[Domain],
                               [RSDDetectedSystemProperties].[DnsName],
                               [RSDInterfaceProperties].[IPV4],
                               [RSDInterfaceProperties].[IPV6],
                               [RSDDetectedSystemProperties].[LastDetectedTime]
						from [RSDDetectedSystemProperties] WITH (NOLOCK)
							 inner join [RSDInterfaceProperties] WITH (NOLOCK)
								on [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
							 inner join [RSDDetectedSource] WITH (NOLOCK)
								on [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
						where [RSDInterfaceProperties].[IPV6] = @IPV6;
				end

                select @cnt = count(*) from @results;
                if (@cnt = 1)
                begin
                    set @done = 1;
                    select @HostID = HostID from @results;
                end
                if (@cnt > 1)
                begin
                    set @found = 1;
                end
			end
			else
			begin
                -- need to get the most recent, in case we drop to 0 in our count...
                select @HostID = HostID from @results order by LastDetectedTime desc;

				-- If this is IPV4, remove the IPV4 elements...
				if (@IPV4 is not null)
				begin
					delete R from @results as R where R.IPV4 <> @IPV4;
				end
				else
				begin
					delete R from @results as R where R.IPV6 <> @IPV6;
				end

                select @cnt = count(*) from @results;
                if (@cnt = 0)
                begin
                    -- use the host that was most recently detected
                    set @done = 1;
                end
                if (@cnt = 1)
                begin
                    set @done = 1;
                    select @HostID = HostID from @results;
                end
                if (@cnt > 1)
                begin
                    set @found = 1;
                end

			end
		end
	end

	-- Check for Hostname only!
	if (@done = 0 and @ComputerName is not null and @useHostname = 1)
	begin
		if (@found = 0)
		begin
			insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
				select [RSDDetectedSystemProperties].[HostID],
					   [RSDDetectedSystemProperties].[AgentGUID],
					   [RSDDetectedSource].[SourceID],
					   [RSDDetectedSource].[SourceType],
					   [RSDDetectedSource].[ExternalID],
					   [RSDInterfaceProperties].[MAC],
					   [RSDDetectedSystemProperties].[NetbiosName],
					   [RSDDetectedSystemProperties].[Domain],
					   [RSDDetectedSystemProperties].[DnsName],
					   [RSDInterfaceProperties].[IPV4],
					   [RSDInterfaceProperties].[IPV6],
					   [RSDDetectedSystemProperties].[LastDetectedTime]
				from [RSDDetectedSystemProperties] WITH (NOLOCK)
					 inner join [RSDInterfaceProperties] WITH (NOLOCK)
						on [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
					 inner join [RSDDetectedSource] WITH (NOLOCK)
						on [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
				where [RSDDetectedSystemProperties].[NetbiosName] = @ComputerName;

			select @cnt = count(*) from @results;
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		else
		begin
			-- need to get the most recent, in case we drop to 0 in our count...
			select @HostID = HostID from @results order by LastDetectedTime desc;

			delete R from @results as R  where ComputerName <> @ComputerName;

			select @cnt = count(*) from @results;
			if (@cnt = 0)
			begin
				-- use the host that was most recently detected
				set @done = 1;
			end
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end

		end
	end

	-- If we never were able to narrow it down to just one, return the most recently detected host from our temp table
	if (@done = 0 and @cnt > 1)
	begin
		select @HostID = HostID from @results order by LastDetectedTime desc;
	end
END
GO



if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_GetDetectedSystemMergeCandidates]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[RSDSP_GetDetectedSystemMergeCandidates]
GO

CREATE PROCEDURE [dbo].[RSDSP_GetDetectedSystemMergeCandidates]
(
	@HostID				int,
    @AgentGUID          uniqueidentifier,
	@SourceID			int,
	@SourceType			nvarchar(100),
	@ExternalID			nvarchar(1000),
    @MAC                nvarchar(12),
    @ComputerName       nvarchar(16),
    @Domain             nvarchar(255),
    @DnsName            nvarchar(255),
    @IPV4               int,
    @IPV6               binary (16)
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    declare @detectedMerging    int;

    -- The Configuration ID by default should always be 1
    select @detectedMerging = [RSDConfiguration].[DetectedMerging]
        from [dbo].[RSDConfiguration]
        where [RSDConfiguration].[ID] = 1;

    declare @useAgentGUID       bit;
    declare @useProductGUID     bit;
    declare @useMAC             bit;
    declare @useHostnameDomain  bit;
    declare @useDNSName         bit;
    declare @useIPAddress       bit;
    declare @useHostname        bit;

    set @useAgentGUID = @detectedMerging & 0x1;
    set @useProductGUID = @detectedMerging & 0x2;
    set @useMAC = @detectedMerging & 0x10;
    set @useHostnameDomain = @detectedMerging & 0x20;
    set @useDNSName = @detectedMerging & 0x40;
    set @useIPAddress = @detectedMerging & 0x80;
    set @useHostname = @detectedMerging & 0x100;

	declare @results table (
		HostID				int,
		AgentGUID		    uniqueidentifier,
		SourceID			int,
		SourceType			nvarchar(100),
		ExternalID			nvarchar(1000),
		MAC					nvarchar(12),
		ComputerName		nvarchar(16),
		Domain				nvarchar(255),
		DnsName				nvarchar(255),
		IPV4				int,
		IPV6				binary (16),
		LastDetectedTime	datetime
	);

	-- Build the @results table up with all the properties we've decided to match on...

	-- Check for a match on the agent guid
    if (@AgentGUID is not null and @useAgentGUID = 1)
    begin
		insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
			select [RSDDetectedSystemProperties].[HostID],
				   [RSDDetectedSystemProperties].[AgentGUID],
				   [RSDDetectedSource].[SourceID],
				   [RSDDetectedSource].[SourceType],
				   [RSDDetectedSource].[ExternalID],
				   [RSDInterfaceProperties].[MAC],
				   [RSDDetectedSystemProperties].[NetbiosName],
				   [RSDDetectedSystemProperties].[Domain],
				   [RSDDetectedSystemProperties].[DnsName],
				   [RSDInterfaceProperties].[IPV4],
				   [RSDInterfaceProperties].[IPV6],
				   [RSDDetectedSystemProperties].[LastDetectedTime]
			from [RSDDetectedSystemProperties], [RSDInterfaceProperties], [RSDDetectedSource]
			where [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
				and [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
				and [RSDDetectedSystemProperties].[AgentGUID] = @AgentGUID;
    end

	-- Like AgentGUID - this should uniquely identify a single system, if not, then we fall through to the user
	-- defined selections
	if (@SourceType is not null and @ExternalID is not null and @useProductGUID = 1)
	begin
		insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
			select [RSDDetectedSystemProperties].[HostID],
				   [RSDDetectedSystemProperties].[AgentGUID],
				   [RSDDetectedSource].[SourceID],
				   [RSDDetectedSource].[SourceType],
				   [RSDDetectedSource].[ExternalID],
				   [RSDInterfaceProperties].[MAC],
				   [RSDDetectedSystemProperties].[NetbiosName],
				   [RSDDetectedSystemProperties].[Domain],
				   [RSDDetectedSystemProperties].[DnsName],
				   [RSDInterfaceProperties].[IPV4],
				   [RSDInterfaceProperties].[IPV6],
				   [RSDDetectedSystemProperties].[LastDetectedTime]
			from [RSDDetectedSystemProperties], [RSDInterfaceProperties], [RSDDetectedSource]
			where [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
				and [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
				and [RSDDetectedSource].[SourceType] = @SourceType
				and [RSDDetectedSource].[ExternalID] = @ExternalID;
	end


	-- Check for a match on the MAC address...
	if (@MAC is not null and @useMAC = 1)
	begin
		insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
			select [RSDDetectedSystemProperties].[HostID],
				   [RSDDetectedSystemProperties].[AgentGUID],
				   [RSDDetectedSource].[SourceID],
				   [RSDDetectedSource].[SourceType],
				   [RSDDetectedSource].[ExternalID],
				   [RSDInterfaceProperties].[MAC],
				   [RSDDetectedSystemProperties].[NetbiosName],
				   [RSDDetectedSystemProperties].[Domain],
				   [RSDDetectedSystemProperties].[DnsName],
				   [RSDInterfaceProperties].[IPV4],
				   [RSDInterfaceProperties].[IPV6],
				   [RSDDetectedSystemProperties].[LastDetectedTime]
			from [RSDDetectedSystemProperties], [RSDInterfaceProperties], [RSDDetectedSource]
			where [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
				and [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
				and [RSDInterfaceProperties].[MAC] = @MAC;
	end

	-- Next, do the ComputerName/Domain pair
	if (@ComputerName is not null and @Domain is not null and @useHostnameDomain = 1)
	begin
		insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
			select [RSDDetectedSystemProperties].[HostID],
				   [RSDDetectedSystemProperties].[AgentGUID],
				   [RSDDetectedSource].[SourceID],
				   [RSDDetectedSource].[SourceType],
				   [RSDDetectedSource].[ExternalID],
				   [RSDInterfaceProperties].[MAC],
				   [RSDDetectedSystemProperties].[NetbiosName],
				   [RSDDetectedSystemProperties].[Domain],
				   [RSDDetectedSystemProperties].[DnsName],
				   [RSDInterfaceProperties].[IPV4],
				   [RSDInterfaceProperties].[IPV6],
				   [RSDDetectedSystemProperties].[LastDetectedTime]
			from [RSDDetectedSystemProperties], [RSDInterfaceProperties], [RSDDetectedSource]
			where [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
				and [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
				and [RSDDetectedSystemProperties].[NetbiosName] = @ComputerName
				and [RSDDetectedSystemProperties].[Domain] = @Domain;
	end

	-- Use DNS name
	if (@DnsName is not null and @useDNSName = 1)
	begin
		insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
			select [RSDDetectedSystemProperties].[HostID],
				   [RSDDetectedSystemProperties].[AgentGUID],
				   [RSDDetectedSource].[SourceID],
				   [RSDDetectedSource].[SourceType],
				   [RSDDetectedSource].[ExternalID],
				   [RSDInterfaceProperties].[MAC],
				   [RSDDetectedSystemProperties].[NetbiosName],
				   [RSDDetectedSystemProperties].[Domain],
				   [RSDDetectedSystemProperties].[DnsName],
				   [RSDInterfaceProperties].[IPV4],
				   [RSDInterfaceProperties].[IPV6],
				   [RSDDetectedSystemProperties].[LastDetectedTime]
			from [RSDDetectedSystemProperties], [RSDInterfaceProperties], [RSDDetectedSource]
			where [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
				and [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
				and [RSDDetectedSystemProperties].[DnsName] = @DnsName;
	end

	-- This is the IP Address check, it's gonna be a little nasty...
	if (( @IPV4 is not null or @IPV6 is not null) and @useIPAddress = 1)
	begin
		-- convert IPV4 to IPV6 so we can just use a single algorithm :)
		declare @ipaddr binary(16);
		if (@IPV4 is not null)
		begin
			set @ipaddr = [dbo].[RSDFN_ConvertIntToIPV6Binary](@IPV4);
		end
		else
		begin
			set @ipaddr = @IPV6;
		end

		-- We only want to do anything if this IPAddress falls in the correct range
		if ([dbo].[RSDFN_IsInRSDConfigurationIPRange](@ipaddr) = 1)
		begin
			if (@IPV4 is not null)
			begin
                insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
                    select [RSDDetectedSystemProperties].[HostID],
                           [RSDDetectedSystemProperties].[AgentGUID],
                           [RSDDetectedSource].[SourceID],
                           [RSDDetectedSource].[SourceType],
                           [RSDDetectedSource].[ExternalID],
                           [RSDInterfaceProperties].[MAC],
                           [RSDDetectedSystemProperties].[NetbiosName],
                           [RSDDetectedSystemProperties].[Domain],
                           [RSDDetectedSystemProperties].[DnsName],
                           [RSDInterfaceProperties].[IPV4],
                           [RSDInterfaceProperties].[IPV6],
                           [RSDDetectedSystemProperties].[LastDetectedTime]
                    from [RSDDetectedSystemProperties], [RSDInterfaceProperties], [RSDDetectedSource]
                    where [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
                        and [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
                        and [RSDInterfaceProperties].[IPV4] = @IPV4;
			end
			else
			begin
                insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
                    select [RSDDetectedSystemProperties].[HostID],
                           [RSDDetectedSystemProperties].[AgentGUID],
                           [RSDDetectedSource].[SourceID],
                           [RSDDetectedSource].[SourceType],
                           [RSDDetectedSource].[ExternalID],
                           [RSDInterfaceProperties].[MAC],
                           [RSDDetectedSystemProperties].[NetbiosName],
                           [RSDDetectedSystemProperties].[Domain],
                           [RSDDetectedSystemProperties].[DnsName],
                           [RSDInterfaceProperties].[IPV4],
                           [RSDInterfaceProperties].[IPV6],
                           [RSDDetectedSystemProperties].[LastDetectedTime]
                    from [RSDDetectedSystemProperties], [RSDInterfaceProperties], [RSDDetectedSource]
                    where [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
                        and [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
                        and [RSDInterfaceProperties].[IPV6] = @IPV6;
			end
		end
	end

	-- Check for Hostname only!
	if (@ComputerName is not null and @useHostname = 1)
	begin
		insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
			select [RSDDetectedSystemProperties].[HostID],
				   [RSDDetectedSystemProperties].[AgentGUID],
				   [RSDDetectedSource].[SourceID],
				   [RSDDetectedSource].[SourceType],
				   [RSDDetectedSource].[ExternalID],
				   [RSDInterfaceProperties].[MAC],
				   [RSDDetectedSystemProperties].[NetbiosName],
				   [RSDDetectedSystemProperties].[Domain],
				   [RSDDetectedSystemProperties].[DnsName],
				   [RSDInterfaceProperties].[IPV4],
				   [RSDInterfaceProperties].[IPV6],
				   [RSDDetectedSystemProperties].[LastDetectedTime]
			from [RSDDetectedSystemProperties], [RSDInterfaceProperties], [RSDDetectedSource]
			where [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
				and [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
				and [RSDDetectedSystemProperties].[NetbiosName] = @ComputerName;
	end

	-- At this point, the table should be full of only the properties that all match our merging criteria.
	-- There should be at least ONE, since we just added a new machine that matched this criteria
	-- If there is not at least ONE - not sure what to do here...
	-- If there is only one, then NO MERGE is needed
	-- If there is more than one, then we need to send the list of HostIDs available for the "mergable" candidate

	-- Don't include the HostID we know about, that is the "target" system we are going to merge into
	select HostID from @results where HostID <> @HostID;

END
GO


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_ExecuteMerge]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[RSDSP_ExecuteMerge]
GO


CREATE PROCEDURE [dbo].[RSDSP_ExecuteMerge]
(
	@TargetHostID				int,
    @SourceHostID               int
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- First, find the interesting mergeable properties from the target - all non-null values will be left alone
    declare @DnsName            nvarchar(255);
    declare @OSPlatform         nvarchar(25);
    declare @OSFamily           nvarchar(128);
    declare @OSVersion          nvarchar(128);
    declare @Domain             nvarchar(255);
    declare @NetbiosName        nvarchar(16);
    declare @NetbiosComment     nvarchar(100);
    declare @Users              nvarchar(128);
    declare @AgentGUID          uniqueidentifier;
    declare @IPV4               int;
    declare @IPV6               binary (16);
    declare @MAC                nvarchar(12);
    declare @DetectedTime       datetime;
    declare @SourceType         nvarchar(100);

    select @DnsName = DnsName,
           @OSPlatform = OSPlatform,
           @OSFamily = OSFamily,
           @OSVersion = OSVersion,
           @Domain = [Domain],
           @NetbiosName = NetbiosName,
           @NetbiosComment = NetbiosComment,
           @Users = Users,
           @AgentGUID = AgentGUID,
           @IPV4 = IPV4,
           @IPV6 = IPV6,
           @MAC = MAC,
           @DetectedTime = LastDetectedTime,
           @SourceType = DetectedSourceType
    from [dbo].[RSDDetectedSystemProperties]
    where HostID = @TargetHostID;

	-- Now, go get all the relevant properties from the source - these values will overwrite null target values
    declare @_DnsName            nvarchar(255);
    declare @_OSPlatform         nvarchar(25);
    declare @_OSFamily           nvarchar(128);
    declare @_OSVersion          nvarchar(128);
    declare @_Domain             nvarchar(255);
    declare @_NetbiosName        nvarchar(16);
    declare @_NetbiosComment     nvarchar(100);
    declare @_Users              nvarchar(128);
    declare @_AgentGUID          uniqueidentifier;
    declare @_IPV4               int;
    declare @_IPV6               binary (16);
    declare @_MAC                nvarchar(12);
    declare @_DetectedTime       datetime;
    declare @_SourceType         nvarchar(100);

    select @_DnsName = DnsName,
           @_OSPlatform = OSPlatform,
           @_OSFamily = OSFamily,
           @_OSVersion = OSVersion,
           @_Domain = [Domain],
           @_NetbiosName = NetbiosName,
           @_NetbiosComment = NetbiosComment,
           @_Users = Users,
           @_AgentGUID = AgentGUID,
           @_IPV4 = IPV4,
           @_IPV6 = IPV6,
           @_MAC = MAC,
           @_DetectedTime = LastDetectedTime,
           @_SourceType = DetectedSourceType
    from [dbo].[RSDDetectedSystemProperties]
    where HostID = @SourceHostID;

    if (@DnsName is null or LEN(@DnsName) = 0)
        set @DnsName = @_DnsName;

	if ((@OSPlatform is null or LEN(@OSPlatform) = 0) or (@OSPlatform = N'Unknown' and @_OSPlatform <> N'Unknown'))
        set @OSPlatform = @_OSPlatform;

    if (@OSFamily is null or LEN(@OSFamily) = 0)
        set @OSFamily = @_OSFamily;

    if (@OSVersion is null or LEN(@OSVersion) = 0)
        set @OSVersion = @_OSVersion;

    if (@Domain is null or LEN(@Domain) = 0)
        set @Domain = @_Domain;

    if (@NetbiosName is null or LEN(@NetbiosName) = 0)
        set @NetbiosName = @_NetbiosName;

    if (@NetbiosComment is null or LEN(@NetbiosComment) = 0)
        set @NetbiosComment = @_NetbiosComment;

    if (@Users is null or LEN(@Users) = 0)
        set @Users = @_Users;

    set @AgentGUID = ISNULL(@AgentGUID, @_AgentGUID);

    if (@IPV4 = -2147483648 or @IPV4 is null)
        set @IPV4 = @_IPV4;

    set @IPV6 = ISNULL(@IPV6, @_IPV6);

    if (@MAC is null or LEN(@MAC) = 0)
        set @MAC = @_MAC;

    set @DetectedTime = ISNULL(@DetectedTime, @_DetectedTime);

    if (@SourceType is null or LEN(@SourceType) = 0)
        set @SourceType = @_SourceType;


    update [dbo].[RSDDetectedSystemProperties]
    set DnsName = @DnsName,
        OSPlatform = @OSPlatform,
        OSFamily = @OSFamily,
        OSVersion = @OSVersion,
        [Domain] = @Domain,
        NetbiosName = @NetbiosName,
        NetbiosComment = @NetbiosComment,
        Users = @Users,
        AgentGUID = @AgentGUID,
        IPV4 = @IPV4,
        IPV6 = @IPV6,
        MAC = @MAC,
        LastDetectedTime = @DetectedTime,
        DetectedSourceType = @SourceType
    where HostID = @TargetHostID;

	-- Now, update all the interfaces from the source to the target
	-- We'll do this by looping through the detected system interfaces for the source
    declare @iMAC					nvarchar(12);
	declare @iOUI					nvarchar (6);
    declare @iIPV4					int;
    declare @iIPV6					binary (16);
	declare @iSubnetID				int;
	declare @iLastDetectedTime		datetime;
	declare @iDetectedSourceType	nvarchar(100);

    DECLARE @cur CURSOR;
   	SET @cur = CURSOR FOR SELECT MAC, OUI, IPV4, IPV6, SubnetID, LastDetectedTime, DetectedSourceType
		FROM [dbo].[RSDInterfaceProperties]
		WHERE HostID = @SourceHostID;

   	-- open the cursor
   	OPEN @cur;

   	-- walk all items in the server cursor
   	FETCH NEXT FROM @cur INTO @iMAC, @iOUI, @iIPV4, @iIPV6, @iSubnetID, @iLastDetectedTime, @iDetectedSourceType
   	WHILE @@FETCH_STATUS = 0
	BEGIN

		declare @cnt int;

		select @cnt = count(*)
		from [dbo].[RSDInterfaceProperties]
		where HostID = @TargetHostID and (MAC is not null and MAC = @iMAC) and IPV4 = @iIPV4 and (IPV6 is not null and IPV6 = @iIPV6) and SubnetID = @iSubnetID;

		-- If there are no existing interfaces with the source data, then add it to the target host id
		if (@cnt = 0)
		begin
			insert into [dbo].[RSDInterfaceProperties] (HostID, MAC, OUI, IPV4, IPV6, SubnetID, LastDetectedTime, DetectedSourceType)
			values (@TargetHostID, @iMAC, @iOUI, @iIPV4, @iIPV6, @iSubnetID, @iLastDetectedTime, @iDetectedSourceType);
		end

   	FETCH NEXT FROM @cur INTO @iMAC, @iOUI, @iIPV4, @iIPV6, @iSubnetID, @iLastDetectedTime, @iDetectedSourceType
   	END;

   	-- close and release the server cursor.
   	CLOSE @cur;
   	DEALLOCATE @cur;


	-- Now, we should be good to go and be able to delete the SourceHostID
	-- The cascade on delete should take care of cleaning up any of the interfaces
	delete from [dbo].[RSDDetectedSystemProperties] where HostID = @SourceHostID;

	-- I suppose we could delete all the RSDInterfaceProperties where HostID = @SourceHostID to make sure...

END
GO


IF NOT EXISTS(SELECT * FROM [dbo].[syscolumns] WHERE id = OBJECT_ID(N'[dbo].[RSDDetectedSystemProperties]') AND [name] = N'RecordedTime')
	ALTER TABLE [dbo].[RSDDetectedSystemProperties] ADD [RecordedTime] [datetime] NOT NULL DEFAULT GETUTCDATE()
GO

IF NOT EXISTS(SELECT * FROM [dbo].[syscolumns] WHERE id = OBJECT_ID(N'[dbo].[RSDDetectedSystemProperties]') AND [name] = N'NewDetection')
	ALTER TABLE [dbo].[RSDDetectedSystemProperties] ADD [NewDetection] [bit] NOT NULL DEFAULT 1
GO

IF NOT EXISTS(SELECT * FROM [dbo].[syscolumns] WHERE id = OBJECT_ID(N'[dbo].[RSDDetectedSystemProperties]') AND [name] = N'ExceptionCategoryID')
	ALTER TABLE [dbo].[RSDDetectedSystemProperties] ADD [ExceptionCategoryID] [int] NULL
GO

IF NOT EXISTS(SELECT * FROM [dbo].[syscolumns] WHERE id = OBJECT_ID(N'[dbo].[RSDDetectedSystemProperties]') AND [name] = N'DeviceType')
	ALTER TABLE [dbo].[RSDDetectedSystemProperties] ADD [DeviceType] [nvarchar] (100) NULL
GO

IF NOT EXISTS (SELECT * FROM [dbo].[sysobjects] WHERE id = object_id(N'[dbo].[OUIUpdatingSettings]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
	CREATE TABLE [dbo].[OUIUpdatingSettings]
	(
		[ID]            int UNIQUE NOT NULL,
		[LastUpdated]	datetime NULL,
		[UpdateURL]     nvarchar(500) NULL,
		[UpdateFile]    nvarchar(500) NULL
	) on [PRIMARY]
GO

-- This will always overwrite an existing setting with this value if necessary
if not exists (select * from [dbo].[OUIUpdatingSettings] where ID = 1)
	insert into [dbo].[OUIUpdatingSettings] (ID, UpdateURL)
		values (1, N'http://standards.ieee.org/regauth/oui/oui.txt')
GO

-- bug 450707
IF NOT EXISTS(SELECT * FROM [dbo].[syscolumns] WHERE id = OBJECT_ID(N'[dbo].[OUIUpdatingSettings]') AND [name] = N'LastUpdateSelection')
	ALTER TABLE [dbo].[OUIUpdatingSettings] ADD [LastUpdateSelection] [int] NULL
GO



IF NOT EXISTS (SELECT * FROM [dbo].[sysobjects] WHERE id = object_id(N'[dbo].[RSDConfigurationAlternateEpoServers]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
	CREATE TABLE [dbo].[RSDConfigurationAlternateEpoServers]
	(
		[ServerName]		nvarchar(255)	    UNIQUE NOT NULL,
	) on [PRIMARY]
GO

IF NOT EXISTS (SELECT * FROM [dbo].[sysobjects] WHERE id = object_id(N'[dbo].[RSDDetectedSystemAgentProperties]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
	CREATE TABLE [dbo].[RSDDetectedSystemAgentProperties]
	(
		[HostID]            int UNIQUE NOT NULL,
		[ComputerName]      nvarchar(255) NULL,
		[ServerName]        nvarchar(255) NULL,
		[AgentVersion]      nvarchar(100) NULL,
		[AgentGUID]         uniqueidentifier NULL
	) ON [PRIMARY]
GO


IF NOT EXISTS (SELECT * FROM [dbo].[sysobjects] WHERE id = object_id(N'[dbo].[RSDExceptionCategories]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
	CREATE TABLE [dbo].[RSDExceptionCategories]
	(
		[CategoryID]    [int] IDENTITY (1, 1) NOT NULL,
		[Name]          nvarchar(100) UNIQUE NOT NULL,
		[Description]   nvarchar(1000) NULL
	) on [PRIMARY]
GO


-- FS input on some performance enhancements to the RSDDetectedSystems view
if exists (select * from .[dbo].sysobjects where id = object_id(N'.[dbo].[RSDDetectedSystems]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[RSDDetectedSystems]
GO

CREATE VIEW [dbo].[RSDDetectedSystems]
AS
SELECT
	dsp.HostID,
	dsp.DnsName,
	dsp.OSPlatform,
	dsp.OSFamily,
	dsp.OSVersion,
	dsp.Domain,
	dsp.NetbiosName,
	dsp.NetbiosComment,
	dsp.Users,
	dsp.AgentGUID,
	dsp.FriendlyName,
	dsp.Ignored,
	dsp.Comments,
	dsp.IPV4,
	dsp.IPV6,
	dsp.MAC,
	dsp.Exception,
	dsp.RogueAction,
	dsp.LastDetectedTime,
	dsp.RecordedTime,
	dsp.NewDetection,
	dsp.DeviceType,
	o.OUI,
	o.OrgName,
	CASE
		WHEN dsp.AgentGUID IS NULL THEN 0
		WHEN ISNULL(ac.AgentCount, 0) = 0 THEN 1	-- This is an "Alien Agent"
		WHEN n.LastUpdate < DATEADD(day, -1 * c.LastAgentCommunication, GETUTCDATE()) THEN 2	-- This is a "Dead Agent"
		WHEN n.LastUpdate >= DATEADD(day, -1 * c.LastAgentCommunication, GETUTCDATE()) THEN -1	-- This is a "Managed" machine
		ELSE 0
	END	AS RogueState,
	CAST
	( CASE
		WHEN dsp.Exception = 0
			AND	dsp.AgentGUID IS NOT NULL
			AND	n.LastUpdate IS NOT NULL
			AND	n.LastUpdate >= DATEADD(day, -1 * c.LastAgentCommunication, GETUTCDATE()) THEN 1
		WHEN ((select ServerName from [dbo].[RSDDetectedSystemAgentProperties] where HostID = dsp.HostID and ServerName
					in (select ServerName from RSDConfigurationAlternateEpoServers)) is not null) THEN 1
		ELSE 0
	END AS BIT ) AS Managed,
	CAST
	( CASE
        WHEN ((select ServerName from [dbo].[RSDDetectedSystemAgentProperties] where HostID = dsp.HostID and ServerName
                in (select ServerName from RSDConfigurationAlternateEpoServers)) is not null) THEN 0
		WHEN
		(	dsp.AgentGUID IS NULL
			OR	ISNULL(ac.AgentCount, 0) = 0
			OR	n.LastUpdate < DATEADD(day, -1 * c.LastAgentCommunication, GETUTCDATE())
		)
		AND dsp.Exception = 0
		AND	dsp.LastDetectedTime >= DATEADD(day, -1 * c.LastSensorDetection, GETUTCDATE())
		THEN	1
		ELSE	0
	END AS BIT ) AS Rogue,
	CAST
	( CASE
		WHEN
		(	dsp.AgentGUID IS NULL
			OR	ISNULL(ac.AgentCount, 0) = 0
			OR	n.LastUpdate < DATEADD(day, -1 * c.LastAgentCommunication, GETUTCDATE())
		)
		AND dsp.Exception = 0
		AND	dsp.LastDetectedTime < DATEADD(day, -1 * c.LastSensorDetection, GETUTCDATE())
		THEN 1
		ELSE 0
	END	AS BIT ) AS Inactive,
	dst.SourceName AS DetectedSourceName,
	n.LastUpdate AS LastAgentCommunication,
	n.AgentVersion AS AgentVersion,
	CASE
		WHEN n.AutoID IS not null THEN (select top 1 ComputerName from [dbo].[EPOServerInfo])
		ELSE (select ServerName from [dbo].[RSDDetectedSystemAgentProperties] where HostID = dsp.HostID)
	END AS ServerName,
	(select [Name] from [dbo].[RSDExceptionCategories] where CategoryID = dsp.ExceptionCategoryID)
	AS ExceptionCategory
FROM
(
	dbo.RSDDetectedSystemProperties	dsp
	LEFT OUTER JOIN	dbo.EPOLeafNode n ON dsp.AgentGUID = n.AgentGUID
	LEFT OUTER JOIN	dbo.RSDDetectedSourceType dst ON dsp.DetectedSourceType	= dst.SourceType
	LEFT OUTER JOIN	dbo.OUIs o ON SUBSTRING(dsp.MAC, 1, 6) = o.OUI AND dsp.MAC IS NOT NULL
	LEFT OUTER JOIN
	(
		SELECT AgentGUID, COUNT(*) AS AgentCount FROM dbo.EPOLeafNode WHERE AgentGUID IS NOT NULL GROUP BY AgentGUID
	) ac ON dsp.AgentGUID = ac.AgentGUID
)
CROSS JOIN
(
	SELECT * FROM dbo.RSDConfiguration WHERE ID = 1
) c
WHERE dsp.Ignored=0
GO



EXEC EPOCore_DropStoredProc N'RSDSP_UpdateDetectedSystems';
GO
CREATE PROCEDURE [dbo].[RSDSP_UpdateDetectedSystems]
(
    @DnsName            nvarchar(255),
    @OSPlatform         nvarchar(25),
    @OSFamily           nvarchar(128),
    @OSVersion          nvarchar(128),
    @Domain             nvarchar(255),
    @NetbiosName        nvarchar(16),
    @NetbiosComment     nvarchar(100),
    @Users              nvarchar(128),
    @AgentGUID          uniqueidentifier,
    @IPV4               int,
    @IPV6               varbinary (16),
    @MAC                nvarchar(12),
    @DetectedTime       datetime,
    @DeviceType         nvarchar(100),
    @SourceID           int,
    @SourceType         nvarchar(100),
    @ExternalID         nvarchar(1000),
    @OutputHostID		int OUTPUT,
    @OutputNewDetection bit OUTPUT
)
AS
BEGIN
    declare @NewDetection bit;
    set @NewDetection = 0;

    declare @FriendlyName nvarchar(255);
    declare @HostID int;

    if (@MAC is not null)
    begin
        set @MAC = UPPER(@MAC);

		-- bug 431315 - if MAC is from a VPN or other "exclude this" list, then don't use it (set to null)
		declare @OUI nvarchar(6);
		set @OUI = SUBSTRING(@MAC, 0, 7);

		declare @vendorIdCount int;
		select @vendorIdCount = count(*) from EPOVirtualMacVendor where VendorID = @OUI;
		if (@vendorIdCount > 0)
		begin
			set @MAC = NULL;
		end
    end;

    if (DATALENGTH(@IPV6) = 4)
    begin
        set @IPV6 = 0x00000000000000000000FFFF + @IPV6;
    end

    -- Begin fix for 457424 / 457673
	-- If the interface is in an ignored subnet, do not add the interface
	-- and make sure we don't end up orphaning a detected system object
    declare @OutSubnetID int;
    if (@IPV6 is not null)
    begin
        exec RSDSP_FindSubnetForIPAddress @IPV6, @OutSubnetID output
    end
	-- If the subnetid is not null and the associated subnet is "ignored", then we don't want to continue
	if (@OutSubnetID is not null and (select Ignored from RSDSubnetProperties where SubnetID = @OutSubnetID) = 1)
	begin
		-- We're going to bail out of here now
		set @OutputHostID = 0;
		set @OutputNewDetection = 0;
		return;
	end
	-- End fix for 457424 / 457673

	-- Match detected systems
	exec RSDSP_MatchDetectedSystems @AgentGUID, @SourceID, @SourceType, @ExternalID,
		@MAC, @NetbiosName, @Domain, @DnsName, @IPV4, @IPV6, @HostID output;

    -- Keep track of when this item was recorded
    declare @RecordedTime datetime;
    set @RecordedTime = GETUTCDATE();

    -- If this identity algoritm returns a match, then update the DetectedSystem,
    -- Interfaces, DetectedSource, and Status with the new data
    if (@HostID is not null)
    begin
        -- We need to get the existing data and replace all non-null values with updated data
        declare @_DnsName            nvarchar(255);
        declare @_OSPlatform         nvarchar(25);
        declare @_OSFamily           nvarchar(128);
        declare @_OSVersion          nvarchar(128);
        declare @_Domain             nvarchar(255);
        declare @_NetbiosName        nvarchar(16);
        declare @_NetbiosComment     nvarchar(100);
        declare @_Users              nvarchar(128);
        declare @_AgentGUID          uniqueidentifier;
        declare @_IPV4               int;
        declare @_IPV6               varbinary (16);
        declare @_MAC                nvarchar(12);
        declare @_DetectedTime       datetime;
        declare @_DeviceType         nvarchar(100);
        declare @_SourceType         nvarchar(100);

        select TOP 1 @_DnsName = DnsName,
               @_OSPlatform = OSPlatform,
               @_OSFamily = OSFamily,
               @_OSVersion = OSVersion,
               @_Domain = [Domain],
               @_NetbiosName = NetbiosName,
               @_NetbiosComment = NetbiosComment,
               @_Users = Users,
               @_AgentGUID = AgentGUID,
               @_IPV4 = IPV4,
               @_IPV6 = IPV6,
               @_MAC = MAC,
               @_DetectedTime = LastDetectedTime,
               @_DeviceType = DeviceType,
               @_SourceType = DetectedSourceType
        from [dbo].[RSDDetectedSystemProperties]
        where HostID = @HostID;

		if (@DnsName is null or LEN(@DnsName) = 0)
			set @DnsName = @_DnsName;

		if ((@OSPlatform is null or LEN(@OSPlatform) = 0) or (@OSPlatform = N'Unknown' and @_OSPlatform <> N'Unknown'))
		    set @OSPlatform = @_OSPlatform;

		if (@OSFamily is null or LEN(@OSFamily) = 0)
			set @OSFamily = @_OSFamily;

		if (@OSVersion is null or LEN(@OSVersion) = 0)
			set @OSVersion = @_OSVersion;

		if (@Domain is null or LEN(@Domain) = 0)
			set @Domain = @_Domain;

		if (@NetbiosName is null or LEN(@NetbiosName) = 0)
			set @NetbiosName = @_NetbiosName;

		if (@NetbiosComment is null or LEN(@NetbiosComment) = 0)
			set @NetbiosComment = @_NetbiosComment;

		if (@Users is null or LEN(@Users) = 0)
			set @Users = @_Users;

        set @AgentGUID = ISNULL(@AgentGUID, @_AgentGUID);

        if (@IPV4 = -2147483648 or @IPV4 is null)
            set @IPV4 = @_IPV4;

        set @IPV6 = ISNULL(@IPV6, @_IPV6);

		if (@MAC is null or LEN(@MAC) = 0)
			set @MAC = @_MAC;

        set @DetectedTime = ISNULL(@DetectedTime, @_DetectedTime);

		if (@DeviceType is null or LEN(@DeviceType) = 0)
			set @DeviceType = @_DeviceType;

        set @FriendlyName = [dbo].[RSDFN_CreateCanonicalName](@DnsName, @NetbiosName, @IPV6, @IPV4, @MAC);

        update [dbo].[RSDDetectedSystemProperties]
        set DnsName = @DnsName,
            OSPlatform = @OSPlatform,
            OSFamily = @OSFamily,
            OSVersion = @OSVersion,
            [Domain] = @Domain,
            NetbiosName = @NetbiosName,
            NetbiosComment = @NetbiosComment,
            Users = @Users,
            AgentGUID = @AgentGUID,
            IPV4 = @IPV4,
            IPV6 = @IPV6,
            MAC = @MAC,
            LastDetectedTime = @DetectedTime,
            FriendlyName = @FriendlyName,
            DetectedSourceType = @SourceType,
            RecordedTime = @RecordedTime,
            DeviceType = @DeviceType,
            NewDetection = 0
        where HostID = @HostID;
    end
    else
    begin
        -- Friendly name is determined by the following, whichever one is not null
		set nocount on;
        set @FriendlyName = [dbo].[RSDFN_CreateCanonicalName](@DnsName, @NetbiosName, @IPV6, @IPV4, @MAC);

        -- Otherwise, add a new row to the DetectedSystems, Interfaces, Status,
        -- DetectedSource and if the RDSSubnets doesn't have associated subnets
        -- we'll need to add in subnet tables, too...
        insert into [dbo].[RSDDetectedSystemProperties] (DnsName, OSPlatform, OSFamily, OSVersion, [Domain],
            NetbiosName, NetbiosComment, Users, AgentGUID, FriendlyName, IPV4, IPV6, MAC,
            LastDetectedTime, DetectedSourceType, Ignored, RecordedTime, DeviceType, NewDetection)
        values (@DnsName, @OSPlatform, @OSFamily, @OSVersion, @Domain,
            @NetbiosName, @NetbiosComment, @Users, @AgentGUID, @FriendlyName, @IPV4, @IPV6, @MAC,
            @DetectedTime, @SourceType, 0, @RecordedTime, @DeviceType, 1);
        select @HostID = SCOPE_IDENTITY();

        set @NewDetection = 1;
    end

	-- Updates the Detected System with the matching ManagedSystem, if it exists...
	 exec RSDSP_MatchManagedSystems @HostID, @AgentGUID, @MAC, @NetbiosName, @Domain, @DnsName, @IPV4, @IPV6

	-- if the external id is provided, use it as further qualification when performing
	--  the detected source update. otherwise use the base info.
	if (@HostID IS NOT NULL)
	begin
		declare @dsid int;
		if (@ExternalID is not null)
		begin
			select @dsid = AutoID from RSDDetectedSource
				where (HostID = @HostID)
				and (SourceID = @SourceID)
				and (SourceType = @SourceType)
				and (ExternalID = @ExternalID);
		end
		else
		begin
			select @dsid = AutoID from RSDDetectedSource
				where (HostID = @HostID)
				and (SourceID = @SourceID)
				and (SourceType = @SourceType);
		end

		-- update source record timestamps
		if (@dsid is not null)
		begin
			update RSDDetectedSource
				set LastDetectedTime = @DetectedTime, LastRecordedTime = @RecordedTime
				where AutoID = @dsid;
		end
		else
		begin
			-- add  detected source record, which couldn't have existed prior because there was no hostid.
			insert into RSDDetectedSource (HostID, SourceID, SourceType, ExternalID, FirstDetectedTime, LastDetectedTime, FirstRecordedTime, LastRecordedTime)
			values (@HostID, @SourceID, @SourceType, @ExternalID, @DetectedTime, @DetectedTime, @RecordedTime, @RecordedTime);
		end
	end

    -- Gonna need a second stored procedure for the interfaces and subnets, so return the HostID for the
    -- next round of inserts
	set @OutputHostID = @HostID;
    set @OutputNewDetection = @NewDetection;
END
GO




-- All for solaris agent bug 449222
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_ValidateMACString]') )
DROP FUNCTION [dbo].[RSDFN_ValidateMACString]
GO

CREATE FUNCTION [dbo].[RSDFN_ValidateMACString]
(
	@MACin nvarchar(100)
)
RETURNS nvarchar(12)
AS
BEGIN
	set @MACin = UPPER(LTRIM(RTRIM(@MACin)));
	if (LEN(@MACin) > 12 or (select CHARINDEX(':', @MACin)) <> 0 or (select CHARINDEX('-', @MACin)) <> 0)
	begin
		if ((select CHARINDEX(':', @MACin)) <> 0)
		begin
			SELECT @MACin = REPLACE(@MACin, ':', '');
		end
		if ((select CHARINDEX('-', @MACin)) <> 0)
		begin
			SELECT @MACin = REPLACE(@MACin, '-', '');
		end
	end
	declare @MAC nvarchar(12);
	set @MAC = SUBSTRING(@MACin,1,12);
	if (LEN(@MAC) <> 12)
		RETURN NULL;

	RETURN @MAC;
END
GO


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_CreateAgentUpdateDetection]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[RSDSP_CreateAgentUpdateDetection]
GO

CREATE PROCEDURE [dbo].[RSDSP_CreateAgentUpdateDetection]
(
    @LeafNodeID   int,
    @AgentGUID    uniqueidentifier,
	@DnsName			nvarchar(255),
	@OSPlatformStr		nvarchar(100),
	@OSVersion          nvarchar(128),
	@Domain             nvarchar(255),
	@ComputerName       nvarchar(255),
	@Users              nvarchar(128),
	@IPV6               binary(16),
	@IPV6mask           binary(16),
	@IPV6subnet         binary(16),
	@MACStr             nvarchar(100)
)
AS
BEGIN

	declare @NetbiosName		nvarchar(16);
	declare @OSPlatform         nvarchar(25);
	declare @MAC                nvarchar(12);
	declare @DetectedTime       datetime;
	declare @SourceType         nvarchar(100);
    declare @DeviceType         nvarchar(100);

	declare @OutputHostID		int;
	declare @OutputNewDetection bit;

    if (@IPV6 is null)
    begin
        return;
    end

	set @NetbiosName = SUBSTRING(@ComputerName,1,16);

    if (@MACStr is not null)
    begin
        -- Handle solaris agent problem (bug 449222)
        set @MAC = [dbo].[RSDFN_ValidateMACString](@MACStr);
    end

	if (@OSPlatformStr like '%Windows%')
	begin
		set @OSPlatform = 'Windows'
	end
	else if (@OSPlatformStr like '%Mac%' or @OSPlatformStr like '%Apple%')
	begin
		set @OSPlatform = 'Macintosh'
	end
	else if (@OSPlatformStr like '%Linux%')
	begin
		set @OSPlatform = 'Linux'
	end
	else if (@OSPlatformStr like '%BSD%')
	begin
		set @OSPlatform = 'BSD'
	end
	else if (@OSPlatformStr like '%IRIX%')
	begin
		set @OSPlatform = 'IRIX'
	end
	else if (@OSPlatformStr like '%HP-UX%')
	begin
		set @OSPlatform = 'HP-UX'
	end
	else if (@OSPlatformStr like '%AIX%')
	begin
		set @OSPlatform = 'AIX'
	end
	else if (@OSPlatformStr like '%Netware%' or @OSPlatformStr like '%Novell%')
	begin
		set @OSPlatform = 'Novell'
	end
	else if (@OSPlatformStr like '%Sun%' or @OSPlatformStr like '%Solaris%')
	begin
		set @OSPlatform = 'Sun'
	end
	else if (@OSPlatformStr like '%Unix%')
	begin
		set @OSPlatform = 'Unix'
	end
	else
	begin
		set @OSPlatform = 'Unknown'
	end

	if (@OSPlatform <> 'Windows')
	begin
		set @NetbiosName = null;
		set @Domain = null;
	end


    if (@OSPlatform = 'Unknown')
    begin
        set @DeviceType = 'unknown';
    end
    else
    begin
        set @DeviceType = 'computer';
    end


	set @DetectedTime = GETUTCDATE();

	set @SourceType = 'epo.agent';

	exec [dbo].[RSDSP_UpdateDetectedSystems] @DnsName, @OSPlatform, null, @OSVersion, @Domain, @NetbiosName,
		null, @Users, @AgentGUID, null, @IPV6, @MAC, @DetectedTime, @DeviceType, @LeafNodeID, @SourceType, null,
		@OutputHostID output, @OutputNewDetection output;

	exec [dbo].[RSDSP_UpdateInterfaces] @OutputHostID, @MAC, null, null, null, @IPV6, @IPV6mask, @IPV6subnet,
		@DetectedTime, @LeafNodeID, @SourceType, null;

END
GO





-- Update any existing stored procs


-- Add new stored procs


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_AddDetectedSystemToEPOSystemTreeAndSort]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[RSDSP_AddDetectedSystemToEPOSystemTreeAndSort]
GO



-- PROCEDURE [RSDSP_AddDetectedSystemToEPOSystemTreeAndSort]
--
-- This will add the data from a Detected System to the ePO System Tree
--
-- INPUT	@HostID - The HostID of the detected system to add to the ePO System Tree
--          @BranchNodeID - The place in the tree to add this, if null, add to global root
--          @AllowDuplicates - If false, search the entire DB for existing leaf node entry
--          @DirSort - If true, will tell ePO to sort the computer immediately after
-- OUTPUT	@ResultCode contains the result code of the operation
--   0 - Success
--   1 - No detected system exists for HostID
--   2 - AgentGUID exists, not usable as this system is already "managed"
--   3 - Unable to add host, IP address already exists in system tree
--   4 - Duplicate node already exists in the tree
-- OUTPUT	@ResultMessage contains a string that can be used for logging - it is not localized; localized version should
--   come from translating the @ResultCode value in the UI if necessary
CREATE PROCEDURE [dbo].[RSDSP_AddDetectedSystemToEPOSystemTreeAndSort]
(
    @HostID             int,
    @BranchNodeID       int,
    @AllowDuplicates    bit,
    @DirSort            bit,
    @ResultHostName     nvarchar(255) OUTPUT,
    @ResultCode         int OUTPUT,
    @ResultMessage      nvarchar(1000) OUTPUT
)
AS
BEGIN

    set nocount on;

    -- Find the detected system, gather up all the available properties
    declare @DnsName            nvarchar(255)
    declare @OSPlatform         nvarchar(25)
    declare @OSFamily           nvarchar(128)
    declare @OSVersion          nvarchar(128)
    declare @Domain             nvarchar(255)
    declare @NetbiosName        nvarchar(16)
    declare @NetbiosComment     nvarchar(100)
    declare @Users              nvarchar(128)
    declare @AgentGUID          uniqueidentifier
    declare @IPV6               binary (16)
    declare @MAC                nvarchar(12)
    declare @FriendlyName       nvarchar(255)

    -- TODO: What happens when there are multiple interfaces???  EPO only cares about a single MAC/IP, where
    -- the detected systems has a many to one relationship...  What if the "last detected" MAC/IP is different
    -- than the one expected???  May not be much of an issue for Foundstone with this first cut, but WILL be more
    -- important as the API evolves...  Need to handle this issue via documentation AT A MINIMUM for this release...
    select @DnsName = DnsName,
        @OSPlatform = OSPlatform,
        @OSFamily = OSFamily,
        @OSVersion = OSVersion,
        @Domain = Domain,
        @NetbiosName = NetbiosName,
        @NetbiosComment = NetbiosComment,
        @Users = Users,
        @AgentGUID = AgentGUID,
        @FriendlyName = FriendlyName,
        @IPV6 = IPV6,
        @MAC = MAC
    from [dbo].[RSDDetectedSystemProperties]
    where HostID = @HostID;

    -- If the NetbiosName is null, we should use the IP address as the name
    if (@NetbiosName is null and @IPV6 is not null)
    begin
        set @NetbiosName = [dbo].[RSDFN_ConvertIPAddrToDisplayString](@IPV6);
    end
    if (@NetbiosName is null and @MAC is not null)
    begin
        set @NetbiosName = @MAC;
    end

    set @ResultHostName = @FriendlyName;

    -- TODO: If an AgentGUID is found, should we "exit"???  These, technically, should not ever be "managed" machines...
    if (@AgentGUID is not null)
    begin
        set @ResultCode = 2;
        set @ResultMessage = N'AgentGUID already exists for ' + @FriendlyName + ' (HostID '+CONVERT(NVARCHAR(10), @HostID)+')';
		return;
    end

    -- If the user passed in a branch node, use that one, otherwise use the global lost and found
    if (@BranchNodeID is null)
    begin
        -- Find the global Lost&Found group, which is where this data will go initially
        -- retrieve default home, which is the global Lost&Found group
        DECLARE @DirectoryID int
        SELECT @DirectoryID = AutoID
            FROM [dbo].[EPOBranchNode]
            WHERE ([Type] = 4);

        -- global lost and found is the only type(5) child of directory
        SELECT @BranchNodeID = AutoID
            FROM [dbo].[EPOBranchNode]
            WHERE ([ParentID] = @DirectoryID)
            AND ([Type] = 5);
    end

    declare @dupcnt int;
    if (@AllowDuplicates = 0)
    begin
		-- If we don't allow duplicates, then we search the entire tree
        select @dupcnt = count(*) from EPOLeafNode where NodeName = @NetbiosName;
	end
	else
	begin
		-- If we do allow duplicates, then we search just make sure we don't allow them in the same branch
		select @dupcnt = COUNT(*) from EPOLeafNode where NodeName = @NetbiosName and ParentID = @BranchNodeID;
    end

    if (@dupcnt > 0)
    begin
        set @ResultCode = 4;
        set @ResultMessage = N'Node already exists named ' + @NetbiosName + ' (HostID '+CONVERT(NVARCHAR(10), @HostID)+')';
        return;
    end

    declare @iMAC           nvarchar(12)
    declare @iIPV6          binary(16)

    declare @SubnetID       int
    declare @Subnet         int
    declare @SubnetMask     int

    select @iMAC = MAC,
        @iIPV6 = IPV6,
        @SubnetID = SubnetID
    from [dbo].[RSDInterfaceProperties]
    where HostID = @HostID;

    -- If there are properties found, use these one over the ones found in the RSDDetectedSystemProperties table
    if (@iMAC is not null) set @MAC = @iMAC;
    if (@iIPV6 is not null) set @IPV6 = @iIPV6;

    select @Subnet = IPV6,
        @SubnetMask = IPV6mask
    from [dbo].[RSDSubnetProperties]
    where SubnetID = @SubnetID;

	-- IPV6 must be something, otherwise this can't be added to ePO...
	if (@IPV6 is null or @IPV6 = 0x00000000000000000000FFFFFFFFFFFF)
	begin
		set @ResultCode = 1;
		set @ResultMessage = N'No IP address exists, cannot add '+@FriendlyName+' to System Tree (HostID '+CONVERT(NVARCHAR(10), @HostID)+')';
		return;
	end

	-- Also check the IP address if we have a "don't allow duplicates" set...
    if (@AllowDuplicates = 0)
    begin
		-- If we don't allow duplicates, then we search the entire tree
		select @dupcnt = count(*) from [dbo].[EPOComputerProperties] where IPV6 = @IPV6 or ComputerName = @NetbiosName;
	end
	else
	begin
		-- If we do allow duplicates, then we search just make sure we don't allow them in the same branch
		select @dupcnt = count(*) from [dbo].[EPOComputerProperties]
			left join [dbo].[EPOLeafNode] on [dbo].[EPOComputerProperties].ParentID = [dbo].[EPOLeafNode].AutoID
			where (EPOComputerProperties.IPV6 = @IPV6 or EPOComputerProperties.ComputerName = @NetbiosName) and (EPOLeafNode.ParentID = @BranchNodeID);
    end

	if (@dupcnt > 0)
	begin
		set @ResultCode = 3;
		set @ResultMessage = N'IP address already exists, cannot add '+@FriendlyName+' to System Tree (HostID '+CONVERT(NVARCHAR(10), @HostID)+')';
		return;
	end

    -- Create an EPOLeafNode record (which also magically creates me an EPOComputerProperties record)
    declare @LeafNodeID int;
    insert into [dbo].[EPOLeafNode] (NodeName, Type, ParentID, ResortEnabled, ResortedOnce)
    values (@NetbiosName, 1, @BranchNodeID, 1, 0)

    select @LeafNodeID = SCOPE_IDENTITY();

    -- Update all the EPOComputerProperties columns from the detected system object now
    -- The IP Address also triggers the IPV4x, IPV4 and IPV6 columns to be set with values...
    update [dbo].[EPOComputerProperties]
    set DomainName = @Domain,
        IPAddress = [dbo].[RSDFN_ConvertIntToIPString]([dbo].[RSDFN_ConvertIPV6BinaryToInt](@IPV6)),
        IPV6 = @IPV6,
        OSType = @OSFamily,
        OSVersion = @OSVersion,
        OSPlatform = @OSPlatform,
        Description = @NetbiosComment,
        UserName = @Users,
        IPHostName = @DnsName,
        NetAddress = @MAC
    where ParentID = @LeafNodeID;

    -- Should we tag and sort this node or not?
    if (@DirSort = 1)
    begin
        exec [dbo].[EPOTags_AutoTagComputerASCI] @LeafNodeID;
        exec [dbo].[EPODirSort_ResortSingleComputerASCI] @LeafNodeID, DEFAULT, DEFAULT, DEFAULT;
    end

    -- Now, delete any existing links for this HostID in the link table, we'll create a new one...
    delete from [dbo].[RSDUnmanagedSystemsLink] where DetectedSystemHostID = @HostID;
    insert into [dbo].[RSDUnmanagedSystemsLink]  (DetectedSystemHostID, EPOLeafNodeID) values (@HostID, @LeafNodeID);

    -- All done, eh...
    set @ResultCode = 0;
    set @ResultMessage = 'Success';

END
GO


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_AddDetectedSystemToEPOSystemTree]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[RSDSP_AddDetectedSystemToEPOSystemTree]
GO



-- PROCEDURE [RSDSP_AddDetectedSystemToEPOSystemTree]
--
-- This will add the data from a Detected System to the ePO System Tree
--
-- INPUT	@HostID - The HostID of the detected system to add to the ePO System Tree
--          @BranchNodeID - The place in the tree to add this, if null, add to global root
--          @AllowDuplicates - If false, search the entire DB for existing leaf node entry
-- OUTPUT	@ResultCode contains the result code of the operation
--   0 - Success
--   1 - No detected system exists for HostID
--   2 - AgentGUID exists, not usable as this system is already "managed"
--   3 - Unable to add host, IP address already exists in system tree
--   4 - Duplicate node already exists in the tree
-- OUTPUT	@ResultMessage contains a string that can be used for logging - it is not localized; localized version should
--   come from translating the @ResultCode value in the UI if necessary
CREATE PROCEDURE [dbo].[RSDSP_AddDetectedSystemToEPOSystemTree]
(
    @HostID             int,
    @BranchNodeID       int,
    @AllowDuplicates    bit,
    @ResultCode         int OUTPUT,
    @ResultMessage      nvarchar(1000) OUTPUT
)
AS
BEGIN
    declare @reshost nvarchar(255);
    EXEC [dbo].[RSDSP_AddDetectedSystemToEPOSystemTreeAndSort] @HostID, @BranchNodeID, @AllowDuplicates, 0, @reshost, @ResultCode, @ResultMessage;

END
GO





if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TR_RSDCleanup_EPOLeafNode_Delete]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
    drop trigger [dbo].[TR_RSDCleanup_EPOLeafNode_Delete]
GO

CREATE TRIGGER [TR_RSDCleanup_EPOLeafNode_Delete] ON [dbo].[EPOLeafNode]
FOR DELETE
AS
BEGIN
	set nocount on;

    DECLARE @count int;
    SELECT @count = COUNT(*) FROM deleted;
    if (@count = 0)
        return;

    declare @AgentGUID uniqueidentifier;
    declare @LeafNodeID int;

	if (@count = 1)
	begin
	    select @AgentGUID = AgentGUID, @LeafNodeID = AutoID from deleted;
        DELETE RSDDetectedSystemProperties WHERE AgentGUID = @AgentGUID
        DELETE RSDSensorBlacklistTarget WHERE AgentGUID  = @AgentGUID
        DELETE RSDSensorProperties WHERE AgentGUID = @AgentGUID
        DELETE RSDUnmanagedSystemsLink WHERE EPOLeafNodeID = @LeafNodeID
	end
	else
	begin
		declare @cur cursor;
		set @cur = cursor for select AgentGUID, AutoID from deleted;
		open @cur;

		fetch next from @cur into @AgentGUID, @LeafNodeID;
		while (@@FETCH_STATUS = 0)
		begin
			DELETE RSDDetectedSystemProperties WHERE AgentGUID = @AgentGUID
			DELETE RSDSensorBlacklistTarget WHERE AgentGUID  = @AgentGUID
			DELETE RSDSensorProperties WHERE AgentGUID = @AgentGUID
            DELETE RSDUnmanagedSystemsLink WHERE EPOLeafNodeID = @LeafNodeID
			fetch next from @cur into @AgentGUID, @LeafNodeID;
		end
		close @cur;
		deallocate @cur;
	end
END
GO


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TR_RSDDetected_EPOLeafNode_OnUpdate]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
    drop trigger [dbo].[TR_RSDDetected_EPOLeafNode_OnUpdate]
GO


CREATE TRIGGER [TR_RSDDetected_EPOLeafNode_OnUpdate] ON [dbo].[EPOLeafNode]
AFTER UPDATE
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @count int;
    SELECT @count = COUNT(*) FROM inserted;
    if (@count = 0 or not (UPDATE(LastUpdate)))
        return;

    -- TODO: THIS IS WRONG - we need to indicate WHICH source has "seen" this object if we're going to do this...

    -- flag the detected systems as "seen"
--    update [dbo].[RSDDetectedSystemProperties]
--        set LastDetectedTime = GETUTCDATE()
--        where AgentGUID in (select AgentGUID from inserted where AgentGUID is not null)

    -- remove any RSDUnmanagedSystemsLinks...
    delete from RSDUnmanagedSystemsLink where EPOLeafNodeID in (select AutoID from inserted)

END
GO




if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_UpdateDetectedSystemPropertiesByHostID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[RSDSP_UpdateDetectedSystemPropertiesByHostID]
GO


CREATE PROCEDURE [dbo].[RSDSP_UpdateDetectedSystemPropertiesByHostID]
(
	@HostID				int,
    @DnsName            nvarchar(255),
    @OSPlatform         nvarchar(25),
    @OSFamily           nvarchar(128),
    @OSVersion          nvarchar(128),
    @Domain             nvarchar(255),
    @NetbiosName        nvarchar(16),
    @NetbiosComment     nvarchar(100),
    @Users              nvarchar(128)
)
AS
BEGIN
	if (@HostID is null or @HostID = 0)
	begin
		-- Not set, can't do anything useful...
		return;
	end

    -- We need to get the existing data and replace all non-null values with updated data
    declare @_DnsName            nvarchar(255);
    declare @_OSPlatform         nvarchar(25);
    declare @_OSFamily           nvarchar(128);
    declare @_OSVersion          nvarchar(128);
    declare @_Domain             nvarchar(255);
    declare @_NetbiosName        nvarchar(16);
    declare @_NetbiosComment     nvarchar(100);
    declare @_Users              nvarchar(128);

    select @_DnsName = DnsName,
           @_OSPlatform = OSPlatform,
           @_OSFamily = OSFamily,
           @_OSVersion = OSVersion,
           @_Domain = [Domain],
           @_NetbiosName = NetbiosName,
           @_NetbiosComment = NetbiosComment,
           @_Users = Users
    from [dbo].[RSDDetectedSystemProperties]
    where HostID = @HostID;

	if (@DnsName is null or LEN(@DnsName) = 0)
		set @DnsName = @_DnsName;

	if ((@OSPlatform is null or LEN(@OSPlatform) = 0) or (@OSPlatform = N'Unknown' and @_OSPlatform <> N'Unknown'))
	    set @OSPlatform = @_OSPlatform;

	if (@OSFamily is null or LEN(@OSFamily) = 0)
		set @OSFamily = @_OSFamily;

	if (@OSVersion is null or LEN(@OSVersion) = 0)
		set @OSVersion = @_OSVersion;

	if (@Domain is null or LEN(@Domain) = 0)
		set @Domain = @_Domain;

	if (@NetbiosName is null or LEN(@NetbiosName) = 0)
		set @NetbiosName = @_NetbiosName;

	if (@NetbiosComment is null or LEN(@NetbiosComment) = 0)
		set @NetbiosComment = @_NetbiosComment;

	if (@Users is null or LEN(@Users) = 0)
		set @Users = @_Users;

    update [dbo].[RSDDetectedSystemProperties]
    set DnsName = @DnsName,
        OSPlatform = @OSPlatform,
        OSFamily = @OSFamily,
        OSVersion = @OSVersion,
        [Domain] = @Domain,
        NetbiosName = @NetbiosName,
        NetbiosComment = @NetbiosComment,
        Users = @Users
    where HostID = @HostID;

END
GO

-- bug 427453 because a poc went out for this, need to make sure the view is dropped before adding in the patch
if exists (select * from .[dbo].sysobjects where id = object_id(N'.[dbo].[RSDManagedSystemsForSubnet]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[RSDManagedSystemsForSubnet]
GO

CREATE VIEW [dbo].[RSDManagedSystemsForSubnet]
AS
SELECT EPOComputerProperties.ParentID,
	EPOComputerProperties.ComputerName,
    EPOComputerProperties.DomainName,
    EPOComputerProperties.IPHostName,
    EPOComputerProperties.IPAddress,
    EPOComputerProperties.OSType,
    EPOComputerProperties.CPUType,
    EPOComputerProperties.NumOfCPU,
    EPOComputerProperties.TotalDiskSpace,
    EPOComputerProperties.FreeDiskSpace,
    EPOComputerProperties.TotalPhysicalMemory,
    EPOComputerProperties.FreeMemory,
	EPOComputerProperties.IPSubnet,
	EPOComputerProperties.IPSubnetMask,
	[dbo].[RSDFN_ManagedSystemHasSensor](EPOComputerProperties.ParentID) AS HasSensor,
	[dbo].[RSDFN_IsInSensorBlacklist](EPOLeafNode.AgentGUID) AS InBlacklist
    from [dbo].[EPOComputerProperties]
    inner join EPOLeafNode on EPOComputerProperties.ParentID = EPOLeafNode.AutoID
GO



-- update system props to include bulk-insert id used by matching algorithm
IF NOT EXISTS(SELECT * FROM [dbo].[syscolumns] WHERE id = OBJECT_ID(N'[dbo].[RSDDetectedSystemProperties]') AND [name] = N'BulkInsertID')
	ALTER TABLE [dbo].[RSDDetectedSystemProperties]	ADD [BulkInsertID] uniqueidentifier
go


-- update to cleanup trigger when a detected system is delted
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[TR_RSDCleanup_RSDDetectedSystemProperties_Delete]'))
	DROP TRIGGER [dbo].[TR_RSDCleanup_RSDDetectedSystemProperties_Delete]
GO
CREATE TRIGGER [dbo].[TR_RSDCleanup_RSDDetectedSystemProperties_Delete] ON [dbo].[RSDDetectedSystemProperties]
FOR DELETE
AS
BEGIN
	-- squelch rowcount reports
	SET NOCOUNT ON;

	-- skip everything on no rows.
    DECLARE @count int;
    SELECT @count = COUNT(*) FROM deleted;
    if (@count = 0)
        return;

	-- at least one row is being deleted.
    DELETE rsdUSL
	FROM RSDUnmanagedSystemsLink rsdUSL	inner join deleted
	on (deleted.HostID = rsdUSL.DetectedSystemHostID);
END
GO

-- on RSDSubnet ignore, find RSDDetectedSystems to also ignore
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[TR_RSDSubnetProperties_OnUpdate]'))
	DROP TRIGGER [dbo].[TR_RSDSubnetProperties_OnUpdate]
GO
CREATE TRIGGER [dbo].[TR_RSDSubnetProperties_OnUpdate] ON [dbo].[RSDSubnetProperties]
AFTER UPDATE
AS
BEGIN
	-- squelch rowcount reports
	SET NOCOUNT ON;

	IF (UPDATE(Ignored))
	BEGIN
		-- build subnets that changed ignored state to 1 from 0
		DECLARE @tblSubnets TABLE(SubnetID int);
		INSERT INTO @tblSubnets(SubnetID)
			SELECT inserted.SubnetID
			FROM inserted join deleted
			ON (inserted.SubnetID = deleted.SubnetID)
			AND (inserted.Ignored = 1)
			AND (deleted.Ignored = 0);

		-- delete all detected systems properties that have no interfaces
		--  being managed by non-ignored subnets.
		IF (@@rowcount != 0)
		BEGIN
			DELETE rsdDSP
			FROM RSDDetectedSystemProperties rsdDSP
			INNER JOIN RSDInterfaceProperties rsdIP	ON (rsdIP.HostID = rsdDSP.HostID)
			INNER JOIN @tblSubnets A ON (rsdIP.SubnetID = A.SubnetID)
			WHERE NOT EXISTS
			(
				SELECT 1
				FROM RSDSubnetProperties rsdSP
				WHERE rsdSP.SubnetID = rsdIP.SubnetID
				AND (rsdSP.Ignored = 0)
			)
		END
	END
END
GO


-------------------------------------------------------------------------------
-- BEGIN RSD Bulk Update API
-------------------------------------------------------------------------------

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDSP_Bulk_MatchDetectedSystems]') AND xtype in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[RSDSP_Bulk_MatchDetectedSystems]
GO

CREATE PROCEDURE [dbo].[RSDSP_Bulk_MatchDetectedSystems]
AS
BEGIN--{
	set nocount on
	--get detected Systems matching config
	declare @detectedMatching    int;

    -- The Configuration ID by default should always be 1
    select @detectedMatching = [RSDConfiguration].[DetectedMatching]
	from [dbo].[RSDConfiguration]
	where [RSDConfiguration].[ID] = 1;

    declare @useAgentGUID       bit;
    declare @useProductGUID     bit;
    declare @useMAC             bit;
    declare @useHostnameDomain  bit;
    declare @useDNSName         bit;
    declare @useIPAddress       bit;
    declare @useHostname        bit;

    set @useAgentGUID = @detectedMatching & 0x1;
    set @useProductGUID = @detectedMatching & 0x2;
    set @useMAC = @detectedMatching & 0x10;
    set @useHostnameDomain = @detectedMatching & 0x20;
    set @useDNSName = @detectedMatching & 0x40;
    set @useIPAddress = @detectedMatching & 0x80;
    set @useHostname = @detectedMatching & 0x100;

	--temp table for rsd matching
	CREATE TABLE #MatchResult(SourceID int, HostID int)

	--Check agent GUID
	if (@useAgentGUID = 1 and exists (select 1 from #RSDAssets where HostID = 0 and [AgentGUID] is not NULL))
	begin--{
		--update HostID if one agent Guid match
		if exists(select 1 from #RSDAssets assets
					join [RSDDetectedSystemProperties] rsd
					on assets.HostID = 0 and assets.[AgentGUID] is not NULL and assets.[AgentGUID] = rsd.[AgentGUID]
					group by assets.SourceID having count(*) = 1)
		begin--{
			update assets
			set assets.HostID = rsd.HostID
			from #RSDAssets assets
			join RSDDetectedSystemProperties rsd
			on assets.HostID = 0 and assets.AgentGUID is not NULL and assets.[AgentGUID] = rsd.[AgentGUID]
			where exists
				(select 1 from #RSDAssets assets2
					join [RSDDetectedSystemProperties] rsd2 on assets2.HostID = 0 and assets2.AgentGUID is not NULL and assets2.[AgentGUID] = rsd2.[AgentGUID]
				where assets.SourceID=assets2.SourceID group by assets2.SourceID having count(*) = 1)
		end--}

		--save to tmp table is multi match on agent Guid
		if exists(select 1 from #RSDAssets assets
					join [RSDDetectedSystemProperties] rsd
					on assets.HostID = 0 and assets.[AgentGUID] is not NULL and assets.[AgentGUID] = rsd.[AgentGUID]
					group by assets.SourceID having count(*) > 1)
		begin--{
			insert #RSDMatch(SourceID, HostID)
			select assets.SourceID, rsd.HostID
			from #RSDAssets assets
			join RSDDetectedSystemProperties rsd
			on assets.HostID = 0 and assets.AgentGUID is not NULL and assets.[AgentGUID] = rsd.[AgentGUID]
			where exists
				(select 1 from #RSDAssets assets2
					join [RSDDetectedSystemProperties] rsd2 on assets2.HostID = 0 and assets2.AgentGUID is not NULL and assets2.[AgentGUID] = rsd2.[AgentGUID]
				where assets.SourceID=assets2.SourceID group by assets2.SourceID having count(*) > 1)
			order by rsd.[LastDetectedTime]
		end--}
	end--}

	--Check externalID

	if (@useProductGUID = 1 and exists (select 1 from #RSDAssets where HostID = 0 and SourceType is not NULL and ExternalID is not NULL))
	begin--{
		--update HostID if one match
		if exists(select 1 from #RSDAssets assets
					join dbo.RSDDetectedSource rsd
					on assets.HostID = 0
					and assets.SourceType is not NULL and assets.ExternalID is not NULL
					and rsd.SourceType is not NULL and rsd.ExternalID is not NULL
					and assets.SourceType=rsd.SourceType and assets.ExternalID=rsd.ExternalID
					group by assets.SourceID, assets.ExternalID having count(*) = 1)
		begin--{
			update assets
			set assets.HostID = rsd.HostID
			from #RSDAssets assets
			join RSDDetectedSource rsd
			on assets.HostID = 0
						and assets.SourceType is not NULL and assets.ExternalID is not NULL
						and rsd.SourceType is not NULL and rsd.ExternalID is not NULL
						and assets.SourceType=rsd.SourceType and assets.ExternalID=rsd.ExternalID
			where exists
				(select 1 from #RSDAssets assets2
				join RSDDetectedSource rsd2
				on assets2.HostID = 0
				and assets2.SourceType is not NULL and assets2.ExternalID is not NULL
				and rsd2.SourceType is not NULL and rsd2.ExternalID is not NULL
				and assets2.SourceType=rsd2.SourceType and assets2.ExternalID=rsd2.ExternalID
				where assets.SourceID=assets2.SourceID
				group by assets2.SourceID, assets2.ExternalID having count(*) = 1)
		end--}
		--save to tmp table is multi matches
		if exists(select 1 from #RSDAssets assets
					join RSDDetectedSource rsd
					on assets.HostID = 0
					and assets.SourceType is not NULL and assets.ExternalID is not NULL
					and rsd.SourceType is not NULL and rsd.ExternalID is not NULL
					and assets.SourceType=rsd.SourceType and assets.ExternalID=rsd.ExternalID
					group by assets.SourceID, assets.ExternalID having count(*) > 1)
		begin--{
			insert #RSDMatch(SourceID, HostID)
			select assets.SourceID, rsd.HostID
			from #RSDAssets assets
			join RSDDetectedSource rsd
			on assets.HostID = 0
					and assets.SourceType is not NULL and assets.ExternalID is not NULL
					and rsd.SourceType is not NULL and rsd.ExternalID is not NULL
					and assets.SourceType=rsd.SourceType and assets.ExternalID=rsd.ExternalID
			where exists
				(select 1 from #RSDAssets assets2
				join RSDDetectedSource rsd2
				on assets2.HostID = 0
				and assets2.SourceType is not NULL and assets2.ExternalID is not NULL
				and rsd2.SourceType is not NULL and rsd2.ExternalID is not NULL
				and assets2.SourceType=rsd2.SourceType and assets2.ExternalID=rsd2.ExternalID
				where assets.SourceID=assets2.SourceID
				group by assets2.SourceID, assets2.ExternalID having count(*) > 1)
			order by rsd.[LastDetectedTime]
		end--}
	end--}

	--check MAC, similar to proc "RSDSP_Bulk_MatchManagedSystems" logic, try to delete the matching table, if all deleteed insert it back
	if(@useMAC = 1 and exists (select 1 from #RSDAssets where HostID = 0 and MAC is not NULL))
	begin--{
		if exists (select 1 from #RSDMatch)
		begin--{

			--store the last matchresult in case all get deleted
			insert #MatchResult(SourceID, HostID)
			select SourceID, HostID from #RSDMatch where Id in
			(select max(Id) from #RSDMatch group by SourceID)

			--delete assets with no matching MAC
			Delete m from #RSDMatch m join #RSDAssets assets on m.SourceID=assets.SourceID
			where not exists
			(
				select 1 from RSDInterfaceProperties i where m.HostID=i.HostID and i.[MAC]=assets.MAC
			)

			--add back to macth list if all deleted
			--print 'Before add back MAC Match...' + Convert(varchar(255),getdate(),121)
			insert #RSDMatch(SourceID, HostID)
			select mc.SourceID, mc.HostID from #MatchResult mc
			where not exists(select 1 from #RSDMatch m where m.SourceID=mc.SourceID)

			truncate table #MatchResult
		end --}

		--get matched assets
		insert #RSDMatch(SourceID, HostID)
		select assets.SourceID, ri.HostID
		from #RSDAssets assets join [RSDInterfaceProperties] ri
		on assets.HostID = 0 and assets.MAC is not NULL and assets.MAC = ri.MAC
		join [RSDDetectedSystemProperties] rsd on ri.HostID=rsd.HostID
		order by rsd.[LastDetectedTime]

		--clean up duplicates
		delete from #RSDMatch where id not in (select max(id) from #RSDMatch group by SourceID, HostID)

		--update hostid of assets with one match, we are done for those assets
		update assets
		set assets.HostID=m.HostID
		from #RSDAssets assets join #RSDMatch m on m.SourceID=assets.SourceID
		where exists
		(select 1 from #RSDMatch m2 where m2.SourceID=assets.SourceID group by m2.SourceID having count(*)=1)

		--delete updated matches from the temp table
		delete m from #RSDMatch m
		where exists(select 1 from #RSDMatch where SourceID=m.SourceID group by SourceID having count(*)=1)

	end--}

	--check Host and Domain, similar to MAc
	if(@useHostnameDomain = 1 and exists (select 1 from #RSDAssets where HostID = 0 and [NetbiosName] is not null and Domain is not null))
	begin--{
		if exists (select 1 from #RSDMatch)
		begin--{
			--store the last matchresult in case all get deleted
			insert #MatchResult(SourceID, HostID)
			select SourceID, HostID from #RSDMatch where Id in
			(select max(Id) from #RSDMatch group by SourceID)

			--delete assets with no matching
			Delete m from #RSDMatch m join #RSDAssets assets on m.SourceID=assets.SourceID
			join RSDDetectedSystemProperties rsd on rsd.HostID=m.HostID
			where not (assets.[NetbiosName]=rsd.[NetbiosName] and assets.Domain=rsd.[Domain])

			--add back to macth list if all deleted
			insert #RSDMatch(SourceID, HostID)
			select mc.SourceID, mc.HostID from #MatchResult mc
			where not exists(select 1 from #RSDMatch m where m.SourceID=mc.SourceID)

			truncate table #MatchResult
		end --}

		--get matched assets
		insert #RSDMatch(SourceID, HostID)
		select assets.SourceID, rsd.HostID
		from #RSDAssets assets join [RSDDetectedSystemProperties] rsd
		on assets.HostID = 0 and assets.[NetbiosName] is not NULL and assets.Domain is not null
		and rsd.[NetbiosName] is not NULL and rsd.Domain is not null
		and assets.[NetbiosName] = rsd.[NetbiosName] and assets.Domain = rsd.[Domain]
		order by rsd.[LastDetectedTime]

		--clean up duplicates
		delete from #RSDMatch where id not in (select max(id) from #RSDMatch group by SourceID, HostID)

		--update hostid of assets with one match
		update assets
		set assets.HostID=m.HostID
		from #RSDAssets assets join #RSDMatch m on m.SourceID=assets.SourceID
		where exists
		(select 1 from #RSDMatch m2 where m2.SourceID=assets.SourceID group by m2.SourceID having count(*)=1)

		--delete updated matches from the temp table
		delete m from #RSDMatch m
		where exists(select 1 from #RSDMatch where SourceID=m.SourceID group by SourceID having count(*)=1)

	end--}

	--check DNSName
	if(@useDNSName = 1 and exists (select 1 from #RSDAssets where HostID = 0 and [DnsName] is not null))
	begin--{
		if exists (select 1 from #RSDMatch)
		begin--{
			--store the last matchresult in case all get deleted
			insert #MatchResult(SourceID, HostID)
			select SourceID, HostID from #RSDMatch where Id in
			(select max(Id) from #RSDMatch group by SourceID)

			--delete assets with no matching
			Delete m from #RSDMatch m join #RSDAssets assets on m.SourceID=assets.SourceID
			join RSDDetectedSystemProperties rsd on rsd.HostID=m.HostID
			where not (assets.[DnsName]=rsd.[DnsName])

			--add back to macth list if all deleted
			insert #RSDMatch(SourceID, HostID)
			select mc.SourceID, mc.HostID from #MatchResult mc
			where not exists(select 1 from #RSDMatch m where m.SourceID=mc.SourceID)

			truncate table #MatchResult
		end --}

		--get matched assets
		insert #RSDMatch(SourceID, HostID)
		select assets.SourceID, rsd.HostID
		from #RSDAssets assets join [RSDDetectedSystemProperties] rsd
		on assets.HostID = 0 and assets.[DnsName] is not NULL
		and rsd.[DnsName] is not NULL and assets.[DnsName] = rsd.[DnsName]
		order by rsd.[LastDetectedTime]

		--clean up duplicates
		delete from #RSDMatch where id not in (select max(id) from #RSDMatch group by SourceID, HostID)

		--update hostid of assets with one match
		update assets
		set assets.HostID=m.HostID
		from #RSDAssets assets join #RSDMatch m on m.SourceID=assets.SourceID
		where exists
		(select 1 from #RSDMatch m2 where m2.SourceID=assets.SourceID group by m2.SourceID having count(*)=1)

		--delete updated matches from the temp table
		delete m from #RSDMatch m
		where exists(select 1 from #RSDMatch where SourceID=m.SourceID group by SourceID having count(*)=1)
	end--}

	--check IPV6
	if(@useIPAddress = 1 and exists (select 1 from #RSDAssets where HostID = 0 and IPV6 is not null))
	begin--{
		if exists (select 1 from #RSDMatch)
		begin--{

			--store the last match result in case all get deleted
			insert #MatchResult(SourceID, HostID)
			select SourceID, HostID from #RSDMatch where Id in
			(select max(Id) from #RSDMatch group by SourceID)

			--delete assets with no matching
			Delete m from #RSDMatch m join #RSDAssets assets on m.SourceID=assets.SourceID
			where not exists
			(
				select 1 from RSDInterfaceProperties i where m.HostID=i.HostID and i.IPV6=assets.IPV6
			)

			--add back to match list if all deleted
			insert #RSDMatch(SourceID, HostID)
			select mc.SourceID, mc.HostID from #MatchResult mc
			where not exists(select 1 from #RSDMatch m where m.SourceID=mc.SourceID)

			truncate table #MatchResult
		end --}

		--get matched assets
		insert #RSDMatch(SourceID, HostID)
		select assets.SourceID, ri.HostID
		from #RSDAssets assets join [RSDInterfaceProperties] ri
		on assets.HostID = 0 and assets.IPV6 is not NULL and assets.IPV6 = ri.IPV6
		join [RSDDetectedSystemProperties] rsd on ri.HostID=rsd.HostID
		order by rsd.[LastDetectedTime]

		--clean up duplicates
		delete from #RSDMatch where id not in (select max(id) from #RSDMatch group by SourceID, HostID)

		--update hostid of assets with one match
		update assets
		set assets.HostID=m.HostID
		from #RSDAssets assets join #RSDMatch m on m.SourceID=assets.SourceID
		where exists
		(select 1 from #RSDMatch m2 where m2.SourceID=assets.SourceID group by m2.SourceID having count(*)=1)

		--delete updated matches from the temp table
		delete m from #RSDMatch m
		where exists(select 1 from #RSDMatch where SourceID=m.SourceID group by SourceID having count(*)=1)
	end--}

	--check hostname
	if(@useHostname = 1 and exists (select 1 from #RSDAssets where HostID = 0 and [NetbiosName] is not null))
	begin--{
		if exists (select 1 from #RSDMatch)
		begin--{
			--store the last matchresult in case all get deleted
			insert #MatchResult(SourceID, HostID)
			select SourceID, HostID from #RSDMatch where Id in
			(select max(Id) from #RSDMatch group by SourceID)

			--delete assets with no matching
			Delete m from #RSDMatch m join #RSDAssets assets on m.SourceID=assets.SourceID
			join RSDDetectedSystemProperties rsd on rsd.HostID=m.HostID
			where not (assets.[NetbiosName]=rsd.[NetbiosName])

			--add back to macth list if all deleted
			insert #RSDMatch(SourceID, HostID)
			select mc.SourceID, mc.HostID from #MatchResult mc
			where not exists(select 1 from #RSDMatch m where m.SourceID=mc.SourceID)
		end --}

		--get matched assets
		insert #RSDMatch(SourceID, HostID)
		select assets.SourceID, rsd.HostID
		from #RSDAssets assets join [RSDDetectedSystemProperties] rsd
		on assets.HostID = 0 and assets.[NetbiosName] is not NULL
		and rsd.[NetbiosName] is not NULL and assets.[NetbiosName] = rsd.[NetbiosName]
		order by rsd.[LastDetectedTime]

		--clean up duplicates
		delete from #RSDMatch where id not in (select max(id) from #RSDMatch group by SourceID, HostID)

		--update hostid of assets with one match
		update assets
		set assets.HostID=m.HostID
		from #RSDAssets assets join #RSDMatch m on m.SourceID=assets.SourceID
		where exists
		(select 1 from #RSDMatch m2 where m2.SourceID=assets.SourceID group by m2.SourceID having count(*)=1)

		--delete updated matches from the temp table
		delete m from #RSDMatch m
		where exists(select 1 from #RSDMatch where SourceID=m.SourceID group by SourceID having count(*)=1)
	end--}
	drop table #MatchResult
	-- If we never were able to narrow it down to just one, return the most recently detected host from our temp table
	delete from #RSDMatch where id not in (select max(id) from #RSDMatch group by SourceID)

	--update HostID
	update assets
	set assets.HostID=m.HostID
	from #RSDAssets assets join #RSDMatch m on m.SourceID=assets.SourceID

	truncate table #RSDMatch

END--}
GO

-- matches against epo tables
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDSP_Bulk_MatchManagedSystems]') AND xtype in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[RSDSP_Bulk_MatchManagedSystems]
GO

CREATE PROCEDURE [dbo].[RSDSP_Bulk_MatchManagedSystems]
AS
BEGIN--{
	set nocount on

	--get Managed Systems matching config
	declare @managedMatching    int;

    -- The Configuration ID by default should always be 1
    select @managedMatching = [RSDConfiguration].[ManagedMatching]
        from [dbo].[RSDConfiguration]
        where [RSDConfiguration].[ID] = 1;

    declare @useAgentGUID       bit;
    declare @useMAC             bit;
    declare @useHostnameDomain  bit;
    declare @useDNSName         bit;
    declare @useIPAddress       bit;
    declare @useHostname        bit;

    set @useAgentGUID = @managedMatching & 0x1;
    set @useMAC = @managedMatching & 0x10;
    set @useHostnameDomain = @managedMatching & 0x20;
    set @useDNSName = @managedMatching & 0x40;
    set @useIPAddress = @managedMatching & 0x80;
    set @useHostname = @managedMatching & 0x100;

	--final RSD, EPOLeafNode maching table
	Create Table #RSDManagedMatch
	(
		HostID int not NULL primary key,
		AgentGUID uniqueidentifier null
	)
	Create Table #RSDManagedSubMatch
	(
		Id int IDENTITY(1,1),
		HostID int,
		AgentGUID uniqueidentifier,
		EPOLeafNodeID int
	)
	--matching temp tables
	Create Table #RSDEpoMatch
	(
		HostID int not NULL primary key,
		AgentGUID uniqueidentifier,
		EPOLeafNodeID int
	)
	-- insert into final matching table
	insert #RSDManagedMatch(HostID)
	select distinct HostID from #RSDAssets

	--Check agent GUID, update the final table if any matches
	if (@useAgentGUID = 1)
	begin--{
		update m
		set m.AgentGUID=epo.AgentGUID
		from #RSDManagedMatch m join dbo.RSDDetectedSystemProperties rsd on m.HostID=rsd.HostID
		join dbo.EPOLeafNode epo on rsd.AgentGUID is not null and epo.AgentGUID is not null and rsd.AgentGUID=epo.AgentGUID
	end--}

	--check MAC
	if(@useMAC = 1 and exists
		(select 1 from #RSDManagedMatch m
		join dbo.RSDInterfaceProperties i on m.HostID=i.HostID and m.AgentGUID is null and i.MAC is not NULL))
	begin--{
		--put into temp match table first.
		insert #RSDManagedSubMatch(HostID,AgentGUID, EPOLeafNodeID)
		select m.HostID, epo.AgentGUID, epo.AutoID from #RSDManagedMatch m join dbo.RSDInterfaceProperties i
		on m.HostID=i.HostID and m.AgentGUID is null and i.MAC is not NULL
		join dbo.EPOComputerProperties p on p.NetAddress is not null and p.NetAddress=i.MAC
		join dbo.EPOLeafNode epo on p.ParentID=epo.AutoID
		where epo.AgentGUID is not NULL
		order by i.LastDetectedTime

		delete from #RSDManagedSubMatch where id not in
		(select max(id) from #RSDManagedSubMatch group by HostID,AgentGUID, EPOLeafNodeID)
		--update guid match for those have one match
		update m
		set m.AgentGUID=s.AgentGUID
		from #RSDManagedMatch m join #RSDManagedSubMatch s on m.HostID=s.HostID
		where s.HostID in
			(select HostID from #RSDManagedSubMatch group by HostID having count(*)=1)
		--delete the ones done
		delete from #RSDManagedSubMatch where HostID in
			(select HostID from #RSDManagedSubMatch group by HostID having count(*)=1)
	end--}

	--check Host and Domain
	if(@useHostnameDomain = 1 and exists
		(select 1 from #RSDManagedMatch m
		join dbo.RSDDetectedSystemProperties rsd
		on m.HostID=rsd.HostID and m.AgentGUID is null
		and rsd.NetbiosName is not null and rsd.Domain is not NULL))
	begin--{
		--try to delete the existing matching temp table and delete them with curent matching rule, if those get all delete, inert them back
		if exists (select 1 from #RSDManagedSubMatch)
		begin--{
			--store the last matchresult in case all get deleted
			insert #RSDEpoMatch(HostID,AgentGUID, EPOLeafNodeID)
			select HostID,AgentGUID,EPOLeafNodeID from #RSDManagedSubMatch where Id in
			(select max(Id) from #RSDManagedSubMatch group by HostID)

			--delete assets with no matching
			Delete s from #RSDManagedSubMatch s
			join dbo.RSDDetectedSystemProperties rsd on s.HostID=rsd.HostID
			join dbo.EPOComputerProperties epo on s.EPOLeafNodeID=epo.ParentID
			where not (rsd.NetbiosName=epo.ComputerName and rsd.Domain=epo.DomainName)

			insert #RSDManagedSubMatch(HostID,AgentGUID,EPOLeafNodeID)
			select mc.HostID, mc.AgentGUID, mc.EPOLeafNodeID from #RSDEpoMatch mc
			where not exists(select 1 from #RSDManagedSubMatch m where m.HostID=mc.HostID)

			truncate table #RSDEpoMatch
		end--}
		--same as MAC matching, if one matching we are done for those.
		insert #RSDManagedSubMatch(HostID,AgentGUID, EPOLeafNodeID)
		select m.HostID, epo.AgentGUID, epo.AutoID
		from #RSDManagedMatch m
		join dbo.RSDDetectedSystemProperties rsd on m.AgentGUID is null and m.HostID=rsd.HostID
		and rsd.NetbiosName is not null and rsd.Domain is not NULL
		join dbo.EPOComputerProperties p
		on p.ComputerName is not null and p.DomainName is not null
		and rsd.NetbiosName=p.ComputerName and rsd.Domain=p.DomainName
		join dbo.EPOLeafNode epo on p.ParentID=epo.AutoID
		where epo.AgentGUID is not NULL
		order by rsd.LastDetectedTime

		delete from #RSDManagedSubMatch where id not in
		(select max(id) from #RSDManagedSubMatch group by HostID,AgentGUID, EPOLeafNodeID)

		update m
		set m.AgentGUID=s.AgentGUID
		from #RSDManagedMatch m join #RSDManagedSubMatch s on m.HostID=s.HostID
		where s.HostID in
			(select HostID from #RSDManagedSubMatch group by HostID having count(*)=1)

		delete from #RSDManagedSubMatch where HostID in
			(select HostID from #RSDManagedSubMatch group by HostID having count(*)=1)

	end--}

	--check DnsName
	if(@useDNSName = 1 and exists
		(select 1 from #RSDManagedMatch m
		join dbo.RSDDetectedSystemProperties rsd
		on m.HostID=rsd.HostID and m.AgentGUID is null
		and rsd.DnsName is not NULL))
	begin--{
		if exists (select 1 from #RSDManagedSubMatch)
		begin--{
			--store the last matchresult in case all get deleted
			insert #RSDEpoMatch(HostID,AgentGUID, EPOLeafNodeID)
			select HostID,AgentGUID,EPOLeafNodeID from #RSDManagedSubMatch where Id in
			(select max(Id) from #RSDManagedSubMatch group by HostID)

			--delete assets with no matching
			Delete s from #RSDManagedSubMatch s
			join dbo.RSDDetectedSystemProperties rsd on s.HostID=rsd.HostID
			join dbo.EPOComputerProperties epo on s.EPOLeafNodeID=epo.ParentID
			where not (rsd.DnsName=epo.IPHostName)

			insert #RSDManagedSubMatch(HostID,AgentGUID,EPOLeafNodeID)
			select mc.HostID, mc.AgentGUID, mc.EPOLeafNodeID from #RSDEpoMatch mc
			where not exists(select 1 from #RSDManagedSubMatch m where m.HostID=mc.HostID)

			truncate table #RSDEpoMatch
		end--}

		insert #RSDManagedSubMatch(HostID,AgentGUID, EPOLeafNodeID)
		select m.HostID, epo.AgentGUID, epo.AutoID
		from #RSDManagedMatch m
		join dbo.RSDDetectedSystemProperties rsd on m.AgentGUID is null and m.HostID=rsd.HostID
		and rsd.DnsName is not NULL
		join dbo.EPOComputerProperties p
		on p.IPHostName is not null and rsd.DnsName=p.IPHostName
		join dbo.EPOLeafNode epo on p.ParentID=epo.AutoID
		where epo.AgentGUID is not NULL
		order by rsd.LastDetectedTime

		delete from #RSDManagedSubMatch where id not in
		(select max(id) from #RSDManagedSubMatch group by HostID,AgentGUID, EPOLeafNodeID)

		update m
		set m.AgentGUID=s.AgentGUID
		from #RSDManagedMatch m join #RSDManagedSubMatch s on m.HostID=s.HostID
		where s.HostID in
			(select HostID from #RSDManagedSubMatch group by HostID having count(*)=1)

		delete from #RSDManagedSubMatch where HostID in
			(select HostID from #RSDManagedSubMatch group by HostID having count(*)=1)

	end--}

	--check IPV6
	if(@useIPAddress = 1 and exists
		(select 1 from #RSDManagedMatch m
		join dbo.RSDDetectedSystemProperties rsd
		on m.HostID=rsd.HostID and m.AgentGUID is null
		and rsd.IPV6 is not NULL))
	begin--{
		if exists (select 1 from #RSDManagedSubMatch)
		begin--{
			--store the last matchresult in case all get deleted
			insert #RSDEpoMatch(HostID,AgentGUID, EPOLeafNodeID)
			select HostID,AgentGUID,EPOLeafNodeID from #RSDManagedSubMatch where Id in
			(select max(Id) from #RSDManagedSubMatch group by HostID)

			--delete assets with no matching
			Delete s from #RSDManagedSubMatch s
			join dbo.RSDDetectedSystemProperties rsd on s.HostID=rsd.HostID
			join dbo.EPOComputerProperties epo on s.EPOLeafNodeID=epo.ParentID
			where not (rsd.IPV6=epo.IPV6)

			insert #RSDManagedSubMatch(HostID,AgentGUID,EPOLeafNodeID)
			select mc.HostID, mc.AgentGUID, mc.EPOLeafNodeID from #RSDEpoMatch mc
			where not exists(select 1 from #RSDManagedSubMatch m where m.HostID=mc.HostID)

			truncate table #RSDEpoMatch
		end--}

		insert #RSDManagedSubMatch(HostID,AgentGUID, EPOLeafNodeID)
		select m.HostID, epo.AgentGUID, epo.AutoID
		from #RSDManagedMatch m
		join dbo.RSDDetectedSystemProperties rsd on m.AgentGUID is null and m.HostID=rsd.HostID
		and rsd.IPV6 is not NULL
		join dbo.EPOComputerProperties p
		on p.IPV6 is not null and rsd.IPV6=p.IPV6
		join dbo.EPOLeafNode epo on p.ParentID=epo.AutoID
		where epo.AgentGUID is not NULL
		order by rsd.LastDetectedTime

		delete from #RSDManagedSubMatch where id not in
		(select max(id) from #RSDManagedSubMatch group by HostID,AgentGUID, EPOLeafNodeID)

		update m
		set m.AgentGUID=s.AgentGUID
		from #RSDManagedMatch m join #RSDManagedSubMatch s on m.HostID=s.HostID
		where s.HostID in
			(select HostID from #RSDManagedSubMatch group by HostID having count(*)=1)

		delete from #RSDManagedSubMatch where HostID in
			(select HostID from #RSDManagedSubMatch group by HostID having count(*)=1)

	end--}

	--check hostname
	if(@useHostname = 1 and exists
		(select 1 from #RSDManagedMatch m
		join dbo.RSDDetectedSystemProperties rsd
		on m.HostID=rsd.HostID and m.AgentGUID is null
		and rsd.NetbiosName is not NULL))
	begin--{
		if exists (select 1 from #RSDManagedSubMatch)
		begin--{
			--store the last matchresult in case all get deleted
			insert #RSDEpoMatch(HostID,AgentGUID, EPOLeafNodeID)
			select HostID,AgentGUID,EPOLeafNodeID from #RSDManagedSubMatch where Id in
			(select max(Id) from #RSDManagedSubMatch group by HostID)

			--delete assets with no matching
			Delete s from #RSDManagedSubMatch s
			join dbo.RSDDetectedSystemProperties rsd on s.HostID=rsd.HostID
			join dbo.EPOComputerProperties epo on s.EPOLeafNodeID=epo.ParentID
			where not (rsd.NetbiosName=epo.[ComputerName])

			insert #RSDManagedSubMatch(HostID,AgentGUID,EPOLeafNodeID)
			select mc.HostID, mc.AgentGUID, mc.EPOLeafNodeID from #RSDEpoMatch mc
			where not exists(select 1 from #RSDManagedSubMatch m where m.HostID=mc.HostID)

			truncate table #RSDEpoMatch
		end--}

		insert #RSDManagedSubMatch(HostID,AgentGUID, EPOLeafNodeID)
		select m.HostID, epo.AgentGUID, epo.AutoID
		from #RSDManagedMatch m
		join dbo.RSDDetectedSystemProperties rsd on m.AgentGUID is null and m.HostID=rsd.HostID
		and rsd.NetbiosName is not NULL
		join dbo.EPOComputerProperties p
		on p.[ComputerName] is not null and rsd.NetbiosName=p.[ComputerName]
		join dbo.EPOLeafNode epo on p.ParentID=epo.AutoID
		where epo.AgentGUID is not NULL
		order by rsd.LastDetectedTime

		delete from #RSDManagedSubMatch where id not in
		(select max(id) from #RSDManagedSubMatch group by HostID,AgentGUID, EPOLeafNodeID)

		update m
		set m.AgentGUID=s.AgentGUID
		from #RSDManagedMatch m join #RSDManagedSubMatch s on m.HostID=s.HostID
		where s.HostID in
			(select HostID from #RSDManagedSubMatch group by HostID having count(*)=1)

		delete from #RSDManagedSubMatch where HostID in
			(select HostID from #RSDManagedSubMatch group by HostID having count(*)=1)

	end--}


	-- If we never were able to narrow it down to just one, return the most recently detected host from our temp table
	delete from #RSDManagedSubMatch where id not in (select max(id) from #RSDManagedSubMatch group by HostID)

	update m
	set m.AgentGUID=s.AgentGUID
	from #RSDManagedMatch m join #RSDManagedSubMatch s on m.HostID=s.HostID
	-- update RSD with Match Agent GUID
	update rsd
	set rsd.AgentGUID=isnull(m.AgentGUID,rsd.AgentGUID),
		rsd.RogueAction = case m.AgentGUID when null then rsd.RogueAction else 0 end
	from [dbo].[RSDDetectedSystemProperties] rsd join #RSDManagedMatch m on rsd.HostID=m.HostID

	Drop Table #RSDManagedMatch
	Drop Table #RSDManagedSubMatch
	Drop Table #RSDEpoMatch

END--}
GO


-- update grouping table for matches
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDSP_Bulk_MatchNewDetectedSystems]') AND xtype in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[RSDSP_Bulk_MatchNewDetectedSystems]
GO
CREATE PROCEDURE [dbo].[RSDSP_Bulk_MatchNewDetectedSystems]
AS
BEGIN--{
	set nocount on;
	--get maching Config
	declare @detectedMatching    int;
	select @detectedMatching = [RSDConfiguration].[DetectedMatching]
	from [dbo].[RSDConfiguration]
	where [RSDConfiguration].[ID] = 1;

    declare @useAgentGUID       bit;
    declare @useProductGUID     bit;
    declare @useMAC             bit;
    declare @useHostnameDomain  bit;
    declare @useDNSName         bit;
    declare @useIPAddress       bit;
    declare @useHostname        bit;

    set @useAgentGUID = @detectedMatching & 0x1;
    set @useProductGUID = @detectedMatching & 0x2;
    set @useMAC = @detectedMatching & 0x10;
    set @useHostnameDomain = @detectedMatching & 0x20;
    set @useDNSName = @detectedMatching & 0x40;
    set @useIPAddress = @detectedMatching & 0x80;
    set @useHostname = @detectedMatching & 0x100;

	--insert default values into grouping tables
	insert #mgAsset
	(
		SourceID,
		GuidGroupID,
		SourceGroupID,
		MACGroupID,
		HostDomainGroupID,
		DnsGroupID,
		IpGroupID,
		HostGroupID
	)
	select
		SourceID
		,SourceID
		,SourceID
		,SourceID
		,SourceID
		,SourceID
		,SourceID
		,SourceID
	from #RSDAssets

	--check AgentGUID
	if (@useAgentGUID = 1)
	begin--{
		--group assets with AgentGUID, nulls are considered as different values
		update m
		set m.GuidGroupID=n.MinSourceID
		from #mgAsset m
		join #RSDAssets a on m.SourceID=a.SourceID
		join
			(select AgentGUID, min(SourceID) MinSourceID
			from #RSDAssets
			Where AgentGUID is not null
			group by AgentGUID) n
		on a.AgentGUID is not null and a.AgentGUID=n.AgentGUID and m.GuidGroupID<>n.MinSourceID
	end--}

	--check SourceType and ExternalID
	if(@useProductGUID = 1)
	begin--{
		--group assets with SourceType and ExternalID, nulls are considered as different values
		update m
		set m.SourceGroupID=n.MinSourceID
		from #mgAsset m
		join #RSDAssets a on m.SourceID=a.SourceID
		join
			(select SourceType, ExternalID, min(SourceID) MinSourceID
			from #RSDAssets
			Where SourceType is not NULL and ExternalID is not null
			group by SourceType, ExternalID) n
		on a.SourceType is not NULL and a.ExternalID is not null
			and a.SourceType=n.SourceType and a.ExternalID=n.ExternalID and m.SourceGroupID<>n.MinSourceID
	end--}

	--check MAC
	if(@useMAC = 1)
	begin--{
		update m
		set m.MACGroupID=n.MinSourceID
		from #mgAsset m
		join #RSDAssets a on m.SourceID=a.SourceID
		join
			(select MAC, min(SourceID) MinSourceID
			from #RSDAssets
			Where MAC is not null
			group by MAC) n
		on a.MAC is not null and a.MAC=n.MAC and m.MACGroupID<>n.MinSourceID
	end--}

	--check Hostname/Domain
	if(@useHostnameDomain = 1)
	begin--{
		update m
		set m.HostDomainGroupID=n.MinSourceID
		from #mgAsset m
		join #RSDAssets a on m.SourceID=a.SourceID
		join
			(select NetbiosName, [Domain], min(SourceID) MinSourceID
			from #RSDAssets
			Where NetbiosName is not NULL and [Domain] is not null
			group by NetbiosName, [Domain]) n
		on a.NetbiosName is not NULL and a.[Domain] is not null
			and a.NetbiosName=n.NetbiosName and a.[Domain]=n.[Domain] and m.HostDomainGroupID<>n.MinSourceID
	end--}

	--check DNSName
	if(@useDNSName = 1)
	begin--{
		update m
		set m.DnsGroupID=n.MinSourceID
		from #mgAsset m
		join #RSDAssets a on m.SourceID=a.SourceID
		join
			(select DnsName, min(SourceID) MinSourceID
			from #RSDAssets
			Where DnsName is not null
			group by DnsName) n
		on a.DnsName is not null and a.DnsName=n.DnsName and m.DnsGroupID<>n.MinSourceID
	end--}

	--check IPV6
	if(@useIPAddress = 1)
	begin--{
		update m
		set m.IpGroupID=n.MinSourceID
		from #mgAsset m
		join #RSDAssets a on m.SourceID=a.SourceID
		join
			(select IPV6, min(SourceID) MinSourceID
			from #RSDAssets
			Where IPV6 is not null
			group by IPV6) n
		on a.IPV6 is not null and a.IPV6=n.IPV6 and m.IpGroupID<>n.MinSourceID
	end--}

	--check NetbiosName
	if(@useHostname = 1)
	begin--{
		update m
		set m.HostGroupID=n.MinSourceID
		from #mgAsset m
		join #RSDAssets a on m.SourceID=a.SourceID
		join
			(select NetbiosName, min(SourceID) MinSourceID
			from #RSDAssets
			Where NetbiosName is not null
			group by NetbiosName) n
		on a.NetbiosName is not null and a.NetbiosName=n.NetbiosName and m.HostGroupID<>n.MinSourceID
	end--}

	--merging
	Begin
		if (@useAgentGUID = 1)
		begin
			update #mgAsset
			set GroupID = GuidGroupID
			where GuidGroupID < SourceID
		end
		if (@useProductGUID = 1)
		begin
			update #mgAsset
			set GroupID = SourceGroupID
			where GroupID is null and SourceGroupID < SourceID
		end
		if (@useMAC = 1)
		begin
			update #mgAsset
			set GroupID = MACGroupID
			where GroupID is null and MACGroupID < SourceID
		end
		if (@useHostnameDomain = 1)
		begin
			update #mgAsset
			set GroupID = HostDomainGroupID
			where GroupID is null and HostDomainGroupID < SourceID
		end
		if (@useDNSName = 1)
		begin
			update #mgAsset
			set GroupID = DnsGroupID
			where GroupID is null and DnsGroupID < SourceID
		end
		if (@useIPAddress = 1)
		begin
			update #mgAsset
			set GroupID = IpGroupID
			where GroupID is null and IpGroupID < SourceID
		end
		if (@useHostname = 1)
		begin
			update #mgAsset
			set GroupID = HostGroupID
			where GroupID is null and HostGroupID < SourceID
		end

		update #mgAsset
		set GroupID = SourceID
		where GroupID is NULL

		declare @LoopCount int, @MaxLoop int
		select  @MaxLoop = count(*)
		from #mgAsset
		set @LoopCount = 0
		while (@LoopCount < @MaxLoop)
		begin--{
			set @LoopCount = @LoopCount + 1
			update a
			set a.GroupID = b.GroupID
			from #mgAsset a join #mgAsset b on a.GroupID = b.SourceID and a.GroupID>b.GroupID
			if (@@rowcount = 0)
				break
		end--}

		--consider MAC and Hostpair/Domain exceptions
		if (@useMAC = 1 and @useHostnameDomain = 1)
		begin
			update m
			set m.GroupID = n.GroupID
			from #mgAsset m join #RSDAssets a
			on a.SourceID=m.SourceID and a.NetbiosName is not NULL
			and a.[Domain] is not null and a.MAC is not null and m.HostDomainGroupID < a.SourceID
			join #RSDAssets b on m.HostDomainGroupID=b.SourceID and b.MAC is not null and a.MAC = b.MAC
			join #mgAsset n on b.SourceID=n.SourceID and n.GroupID < m.HostDomainGroupID
		end

		--consider MAC, Hostpair/Domain and DNSName exceptions
		if (@useMAC = 1 and @useHostnameDomain = 1 and @useDNSName = 1)
		begin
			update m
			set m.GroupID = n.GroupID
			from #mgAsset m join #RSDAssets a
			on a.SourceID=m.SourceID and a.DnsName is not NULL
			and ((a.NetbiosName is not NULL and a.[Domain] is not null) or a.MAC is not null)
			and m.DnsGroupID < a.SourceID
			join #RSDAssets b on m.DnsGroupID=b.SourceID
			and ((b.MAC is not null and a.MAC = b.MAC) or
					(b.NetbiosName is not NULL and b.[Domain] is not null
						and a.NetbiosName=b.NetbiosName and a.[Domain]=b.[Domain]))
			join #mgAsset n on b.SourceID=n.SourceID and n.GroupID < m.DnsGroupID
		end
	end
END--}
GO


-- update detected systems from #RSDAssets
IF  EXISTS (SELECT * FROM [dbo].[sysobjects] WHERE id = OBJECT_ID(N'[dbo].[RSDSP_Bulk_UpdateDetectedSystems]') AND xtype in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[RSDSP_Bulk_UpdateDetectedSystems]
GO
CREATE PROCEDURE [dbo].[RSDSP_Bulk_UpdateDetectedSystems]
AS
BEGIN--{

	set nocount on
	declare @RecordedTime datetime;
	set @RecordedTime = GETUTCDATE();

	--use bitbucket for unknown subnets.
	declare @BitBucketID int;
	select top 1 @BitBucketID=SubnetID from dbo.RSDSubnetProperties where BitBucket=1;

	--update one-match rsd first
	--insert to temp table for one-match update

	insert #RSDMatch(SourceID, HostID)
	select m.SourceID, m.HostID
	from #RSDAssets m
	join (
			select HostID from #RSDAssets
			where HostID>0
			group by HostID
			having count(*)=1
		) d
		on m.HostID = d.HostID
	order by m.LastDetectedTime

	if exists(select * from #RSDMatch)
	begin--{
		--update properties in the temp table
		update assets
		set assets.DnsName = isnull(assets.DnsName,rsd.DnsName),
			assets.OSPlatform = isnull(assets.OSPlatform,rsd.OSPlatform),
			assets.OSFamily = isnull(assets.OSFamily,rsd.OSFamily),
			assets.OSVersion = isnull(assets.OSVersion,rsd.OSVersion),
			assets.[Domain] = isnull(assets.Domain,rsd.[Domain]),
			assets.NetbiosName = isnull(assets.NetbiosName,rsd.NetbiosName),
			assets.NetbiosComment = isnull(assets.NetbiosComment,rsd.NetbiosComment),
			assets.Users = isnull(assets.Users,rsd.Users),
			assets.AgentGUID = isnull(assets.AgentGUID,rsd.AgentGUID),
			assets.IPV6 = case when assets.IPV6 is null then rsd.IPV6 else assets.IPV6 end,
			assets.MAC = isnull(assets.MAC,rsd.MAC),
			assets.LastDetectedTime = isnull(assets.[LastDetectedTime],rsd.LastDetectedTime),
			assets.SourceType = isnull(assets.SourceType,rsd.DetectedSourceType),
			assets.Active=1
		from RSDDetectedSystemProperties rsd
		join #RSDMatch m on m.HostID=rsd.HostID
		join #RSDAssets assets on m.SourceID=assets.SourceID

		update #RSDAssets
		set FriendlyName =
			case when DnsName is not null then DnsName
				 when NetbiosName is not null then NetbiosName
				 when IPAddress is not null then IPAddress
				 when MAC is not null then MAC
			else ''
			end
		where Active=1

		--Update RSD properties
		update rsd
		set	rsd.DnsName = assets.DnsName,
			rsd.OSPlatform = assets.OSPlatform,
			rsd.OSFamily = assets.OSFamily,
			rsd.OSVersion = assets.OSVersion,
			rsd.[Domain] = assets.Domain,
			rsd.NetbiosName = assets.NetbiosName,
			rsd.NetbiosComment = assets.NetbiosComment,
			rsd.Users = assets.Users,
			rsd.AgentGUID = assets.AgentGUID,
			rsd.IPV6 = assets.IPV6,
			rsd.MAC = assets.MAC,
			rsd.LastDetectedTime = assets.[LastDetectedTime],
			rsd.FriendlyName = assets.FriendlyName,
			rsd.DetectedSourceType = assets.SourceType
		from RSDDetectedSystemProperties rsd
		join #RSDAssets assets on rsd.HostID=assets.HostID and assets.Active=1

		--update or create RSDDetectedSource
		if exists(select 1 from #RSDAssets where Active=1 and ExternalID is not NULL)
		begin
			update ds
			set ds.LastDetectedTime = assets.[LastDetectedTime],
				ds.LastRecordedTime = @RecordedTime
			from [RSDDetectedSource] ds
			join #RSDAssets assets on ds.HostID=assets.HostID and assets.Active=1 and assets.ExternalID is not NULL
			and ds.SourceType = assets.SourceType and ds.SourceID=assets.SourceID and ds.ExternalID = assets.ExternalID

			insert [RSDDetectedSource](HostID, SourceID, SourceType, ExternalID, FirstDetectedTime, LastDetectedTime, FirstRecordedTime, LastRecordedTime)
			select assets.HostID, assets.SourceID, assets.SourceType, assets.ExternalID, assets.LastDetectedTime, assets.LastDetectedTime, @RecordedTime, @RecordedTime
			from #RSDMatch m
			join #RSDAssets assets on assets.Active=1 and m.SourceID=assets.SourceID and assets.ExternalID is not NULL
			left join [RSDDetectedSource] ds
				on ds.HostID=assets.HostID and ds.SourceType = assets.SourceType and ds.ExternalID = assets.ExternalID and ds.SourceID=assets.SourceID
			where ds.HostID is null
		end

		update ds
		set ds.LastDetectedTime = assets.LastDetectedTime,
			ds.LastRecordedTime = @RecordedTime
		from [RSDDetectedSource] ds
		join #RSDAssets assets on assets.HostID=ds.HostID and assets.Active=1 and assets.ExternalID is NULL
		and ds.SourceType = assets.SourceType and ds.SourceID=assets.SourceID and ds.ExternalID is null

		insert [RSDDetectedSource](HostID, SourceID, SourceType, ExternalID, FirstDetectedTime, LastDetectedTime, FirstRecordedTime, LastRecordedTime)
		select distinct assets.HostID, assets.SourceID, assets.SourceType, assets.ExternalID, assets.LastDetectedTime, assets.LastDetectedTime, @RecordedTime, @RecordedTime
		from #RSDMatch m
		join #RSDAssets assets on assets.Active=1 and m.SourceID=assets.SourceID and assets.ExternalID is NULL
		left join [RSDDetectedSource] ds
			on assets.HostID=ds.HostID and ds.SourceType = assets.SourceType and ds.SourceID=assets.SourceID and ds.ExternalID is NULL
		where ds.HostID is null

		--handle interfaces
		--get interfaces IDs for updates
		update m
		set m.InterfaceID=i.InterfaceID
		from [RSDInterfaceProperties] i
		join #RSDMatch m on i.HostID=m.HostID
		join #RSDAssets assets on m.SourceID=assets.SourceID and assets.MAC is NOT NULL and assets.MAC=i.MAC

		if exists(select 1 from #RSDMatch where HostID > 0 and InterfaceID is null)
			update m
			set m.InterfaceID=i.InterfaceID
			from [RSDInterfaceProperties] i
			join #RSDMatch m on i.HostID=m.HostID and m.InterfaceID is null
			join #RSDAssets assets on m.SourceID=assets.SourceID and assets.IPV6 =i.IPV6

		--update subnetID
		update m
		set m.SubnetID=s.SubnetID
		from #RSDMatch m
		join #RSDAssets assets on m.SourceID=assets.SourceID and m.SubnetID is null
		join RSDSubnetProperties s on (assets.IPV6 is not null) 
		and (assets.IPV6 between s.IPV6Start and s.IPV6End)

		update #RSDMatch
			set SubnetID=@BitBucketID
			where SubnetID is null

		--update interfaces
		update i
		set	MAC = assets.MAC,
			OUI = case assets.MAC
					when null then 'FFFFFF'
					when '' then i.OUI
					else SUBSTRING(assets.MAC, 0, 7)
					end,
			IPV6 = assets.IPV6,
			SubnetID = m.SubnetID,
			LastDetectedTime = assets.LastDetectedTime,
			DetectedSourceType = assets.SourceType
		from [RSDInterfaceProperties] i
		join #RSDMatch m on m.InterfaceID=i.InterfaceID
		join #RSDAssets assets on m.SourceID=assets.SourceID

		--insert interfaces for new ones
		insert[RSDInterfaceProperties](HostID,MAC,OUI,IPV6,SubnetID,LastDetectedTime,DetectedSourceType)
		select distinct
			m.HostID,
			assets.MAC,
			OUI = case assets.MAC
					when null then 'FFFFFF'
					else SUBSTRING(assets.MAC, 0, 7)
					end,
			IPV6 = assets.IPV6,
			SubnetID = m.SubnetID,
			LastDetectedTime = assets.LastDetectedTime,
			DetectedSourceType = assets.SourceType
		from #RSDMatch m
		join #RSDAssets assets on m.SourceID=assets.SourceID
		where m.HostID > 0 and m.InterfaceID is null

		truncate table #RSDMatch
	end--}

	--insert multi matches
	--update multi matches
	insert #RSDMatch(SourceID, HostID)
	select m.SourceID, m.HostID
	from #RSDAssets m
	join (
			select HostID from #RSDAssets
			where HostID>0
			group by HostID
			having count(*)>1
		) d
		on m.HostID = d.HostID
	order by m.LastDetectedTime

	if exists(select * from #RSDMatch)
	begin
		--set latest one for updates
		update assets
		set assets.Active=1
		from #RSDAssets assets join #RSDMatch m on m.SourceID=assets.SourceID
		join (select max(id) maxID from #RSDMatch group by HostID) l on m.Id=l.maxID

		--merge properties
		--update DNSName
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.DnsName is null and m.SourceID=assets.SourceID and assets.Active=1
				)
		begin
			update assets
			set assets.DnsName=f.DnsName
			from #RSDAssets assets join #RSDMatch m on assets.DnsName is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join
			(select m2.HostID, assets2.DnsName
			from #RSDAssets assets2 join #RSDMatch m2 on m2.SourceID=assets2.SourceID
				join
				(select max(m1.id) mid
				from #RSDMatch m1 join #RSDAssets assets1 on m1.SourceID=assets1.SourceID
				where assets1.DnsName is not null group by m1.HostID) n on m2.id=n.mid) f
			on m.HostID=f.HostID
		end
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.DnsName is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin
			update assets
			set assets.DnsName=rsd.DnsName
			from #RSDAssets assets join #RSDMatch m on assets.DnsName is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join RSDDetectedSystemProperties rsd on m.HostID=rsd.HostID
		end

		--update OSPlatform
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.OSPlatform is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin
			update assets
			set assets.OSPlatform=f.OSPlatform
			from #RSDAssets assets join #RSDMatch m on assets.OSPlatform is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join
			(select m2.HostID, assets2.OSPlatform
			from #RSDAssets assets2 join #RSDMatch m2 on m2.SourceID=assets2.SourceID
				join
				(select max(m1.id) mid
				from #RSDMatch m1 join #RSDAssets assets1 on m1.SourceID=assets1.SourceID
				where assets1.OSPlatform is not null group by m1.HostID) n on m2.id=n.mid) f
			on m.HostID=f.HostID
		end
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.OSPlatform is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin
			update assets
			set assets.OSPlatform=rsd.OSPlatform
			from #RSDAssets assets join #RSDMatch m on assets.OSPlatform is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join RSDDetectedSystemProperties rsd on m.HostID=rsd.HostID
		end

		--update OSFamily
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.OSFamily is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin
			update assets
			set assets.OSFamily=f.OSFamily
			from #RSDAssets assets join #RSDMatch m on assets.OSFamily is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join
			(select m2.HostID, assets2.OSFamily
			from #RSDAssets assets2 join #RSDMatch m2 on m2.SourceID=assets2.SourceID
				join
				(select max(m1.id) mid
				from #RSDMatch m1 join #RSDAssets assets1 on m1.SourceID=assets1.SourceID
				where assets1.OSFamily is not null group by m1.HostID) n on m2.id=n.mid) f
			on m.HostID=f.HostID
		end
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.OSFamily is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin
			update assets
			set assets.OSFamily=rsd.OSFamily
			from #RSDAssets assets join #RSDMatch m on assets.OSFamily is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join RSDDetectedSystemProperties rsd on m.HostID=rsd.HostID
		end

		--update OSVersion
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.OSVersion is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin
			update assets
			set assets.OSVersion=f.OSVersion
			from #RSDAssets assets join #RSDMatch m on assets.OSVersion is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join
			(select m2.HostID, assets2.OSVersion
			from #RSDAssets assets2 join #RSDMatch m2 on m2.SourceID=assets2.SourceID
				join
				(select max(m1.id) mid
				from #RSDMatch m1 join #RSDAssets assets1 on m1.SourceID=assets1.SourceID
				where assets1.OSVersion is not null group by m1.HostID) n on m2.id=n.mid) f
			on m.HostID=f.HostID
		end
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.OSVersion is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin
			update assets
			set assets.OSVersion=rsd.OSVersion
			from #RSDAssets assets join #RSDMatch m on assets.OSVersion is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join RSDDetectedSystemProperties rsd on m.HostID=rsd.HostID
		end

		--update Domain
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.Domain is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin
			update assets
			set assets.Domain=f.Domain
			from #RSDAssets assets join #RSDMatch m on assets.Domain is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join
			(select m2.HostID, assets2.Domain
			from #RSDAssets assets2 join #RSDMatch m2 on m2.SourceID=assets2.SourceID
				join
				(select max(m1.id) mid
				from #RSDMatch m1 join #RSDAssets assets1 on m1.SourceID=assets1.SourceID
				where assets1.Domain is not null group by m1.HostID) n on m2.id=n.mid) f
			on m.HostID=f.HostID
		end
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.Domain is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin
			update assets
			set assets.Domain=rsd.Domain
			from #RSDAssets assets join #RSDMatch m on assets.Domain is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join RSDDetectedSystemProperties rsd on m.HostID=rsd.HostID
		end

		--update NetbiosName
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.NetbiosName is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin
			update assets
			set assets.NetbiosName=f.NetbiosName
			from #RSDAssets assets join #RSDMatch m on assets.NetbiosName is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join
			(select m2.HostID, assets2.NetbiosName
			from #RSDAssets assets2 join #RSDMatch m2 on m2.SourceID=assets2.SourceID
				join
				(select max(m1.id) mid
				from #RSDMatch m1 join #RSDAssets assets1 on m1.SourceID=assets1.SourceID
				where assets1.NetbiosName is not null group by m1.HostID) n on m2.id=n.mid) f
			on m.HostID=f.HostID
		end
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.NetbiosName is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin
			update assets
			set assets.NetbiosName=rsd.NetbiosName
			from #RSDAssets assets join #RSDMatch m on assets.NetbiosName is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join RSDDetectedSystemProperties rsd on m.HostID=rsd.HostID
		end

		--update NetbiosComment
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.NetbiosComment is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin
			update assets
			set assets.NetbiosComment=f.NetbiosComment
			from #RSDAssets assets join #RSDMatch m on assets.NetbiosComment is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join
			(select m2.HostID, assets2.NetbiosComment
			from #RSDAssets assets2 join #RSDMatch m2 on m2.SourceID=assets2.SourceID
				join
				(select max(m1.id) mid
				from #RSDMatch m1 join #RSDAssets assets1 on m1.SourceID=assets1.SourceID
				where assets1.NetbiosComment is not null group by m1.HostID) n on m2.id=n.mid) f
			on m.HostID=f.HostID
		end
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.NetbiosComment is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin
			update assets
			set assets.NetbiosComment=rsd.NetbiosComment
			from #RSDAssets assets join #RSDMatch m on assets.NetbiosComment is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join RSDDetectedSystemProperties rsd on m.HostID=rsd.HostID
		end

		--update Users
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.Users is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin
			update assets
			set assets.Users=f.Users
			from #RSDAssets assets join #RSDMatch m on assets.Users is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join
			(select m2.HostID, assets2.Users
			from #RSDAssets assets2 join #RSDMatch m2 on m2.SourceID=assets2.SourceID
				join
				(select max(m1.id) mid
				from #RSDMatch m1 join #RSDAssets assets1 on m1.SourceID=assets1.SourceID
				where assets1.Users is not null group by m1.HostID) n on m2.id=n.mid) f
			on m.HostID=f.HostID
		end
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.Users is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin
			update assets
			set assets.Users=rsd.Users
			from #RSDAssets assets join #RSDMatch m on assets.Users is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join RSDDetectedSystemProperties rsd on m.HostID=rsd.HostID
		end

		--update AgentGUID
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.AgentGUID is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin
			update assets
			set assets.AgentGUID=f.AgentGUID
			from #RSDAssets assets join #RSDMatch m on assets.AgentGUID is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join
			(select m2.HostID, assets2.AgentGUID
			from #RSDAssets assets2 join #RSDMatch m2 on m2.SourceID=assets2.SourceID
				join
				(select max(m1.id) mid
				from #RSDMatch m1 join #RSDAssets assets1 on m1.SourceID=assets1.SourceID
				where assets1.AgentGUID is not null group by m1.HostID) n on m2.id=n.mid) f
			on m.HostID=f.HostID
		end
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.AgentGUID is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin
			update assets
			set assets.AgentGUID=rsd.AgentGUID
			from #RSDAssets assets join #RSDMatch m on assets.AgentGUID is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join RSDDetectedSystemProperties rsd on m.HostID=rsd.HostID
		end

		--update IPV6
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.IPV6 is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin
			update assets
			set assets.IPV6=f.IPV6,
				assets.IPAddress=f.IPAddress
			from #RSDAssets assets join #RSDMatch m on assets.IPV6 is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join
			(select m2.HostID, assets2.IPV6, assets2.IPAddress
			from #RSDAssets assets2 join #RSDMatch m2 on m2.SourceID=assets2.SourceID
				join
				(select max(m1.id) mid
				from #RSDMatch m1 join #RSDAssets assets1 on m1.SourceID=assets1.SourceID
				where assets1.IPV6 is not null group by m1.HostID) n on m2.id=n.mid) f
			on m.HostID=f.HostID
		end
		
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.IPV6 is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin
			update assets
			set assets.IPV6=rsd.IPV6,
				assets.IPAddress=[dbo].RSDFN_ConvertIPAddrToDisplayString(rsd.IPV6)
			from #RSDAssets assets join #RSDMatch m on assets.IPV6 is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join RSDDetectedSystemProperties rsd on m.HostID=rsd.HostID
		end

		--update MAC
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.MAC is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin
			update assets
			set assets.MAC=f.MAC
			from #RSDAssets assets join #RSDMatch m on assets.MAC is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join
			(select m2.HostID, assets2.MAC
			from #RSDAssets assets2 join #RSDMatch m2 on m2.SourceID=assets2.SourceID
				join
				(select max(m1.id) mid
				from #RSDMatch m1 join #RSDAssets assets1 on m1.SourceID=assets1.SourceID
				where assets1.MAC is not null group by m1.HostID) n on m2.id=n.mid) f
			on m.HostID=f.HostID
		end
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.MAC is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin
			update assets
			set assets.MAC=rsd.MAC
			from #RSDAssets assets join #RSDMatch m on assets.MAC is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join RSDDetectedSystemProperties rsd on m.HostID=rsd.HostID
		end

		--update LastDetectedTime
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.LastDetectedTime is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin
			update assets
			set assets.LastDetectedTime=f.LastDetectedTime
			from #RSDAssets assets join #RSDMatch m on assets.LastDetectedTime is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join
			(select m2.HostID, assets2.LastDetectedTime
			from #RSDAssets assets2 join #RSDMatch m2 on m2.SourceID=assets2.SourceID
				join
				(select max(m1.id) mid
				from #RSDMatch m1 join #RSDAssets assets1 on m1.SourceID=assets1.SourceID
				where assets1.LastDetectedTime is not null group by m1.HostID) n on m2.id=n.mid) f
			on m.HostID=f.HostID
		end
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.LastDetectedTime is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin
			update assets
			set assets.LastDetectedTime=rsd.LastDetectedTime
			from #RSDAssets assets join #RSDMatch m on assets.LastDetectedTime is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join RSDDetectedSystemProperties rsd on m.HostID=rsd.HostID
		end
		--set FriendlyName
		update assets
		set assets.FriendlyName =
			case when DnsName is not null then DnsName
				 when NetbiosName is not null then NetbiosName
				 when IPAddress is not null then IPAddress
				 when MAC is not null then MAC
			else ''
			end
		from #RSDMatch m join #RSDAssets assets
			on assets.Active=1 and m.SourceID=assets.SourceID
		--update RSD
		update rsd
		set	rsd.DnsName = assets.DnsName,
			rsd.OSPlatform = assets.OSPlatform,
			rsd.OSFamily = assets.OSFamily,
			rsd.OSVersion = assets.OSVersion,
			rsd.[Domain] = assets.Domain,
			rsd.NetbiosName = assets.NetbiosName,
			rsd.NetbiosComment = assets.NetbiosComment,
			rsd.Users = assets.Users,
			rsd.AgentGUID = assets.AgentGUID,
			rsd.IPV6 = assets.IPV6,
			rsd.MAC = assets.MAC,
			rsd.LastDetectedTime = assets.[LastDetectedTime],
			rsd.FriendlyName = assets.FriendlyName,
			rsd.DetectedSourceType = assets.SourceType
		from #RSDAssets assets join #RSDMatch m on assets.Active=1 and m.SourceID=assets.SourceID
		join RSDDetectedSystemProperties rsd on m.HostID=rsd.HostID

		--update sources
		if exists(select 1 from #RSDAssets assets join #RSDMatch m on assets.Active=1 and m.SourceID=assets.SourceID where assets.ExternalID is not NULL)
		begin
			update ds
			set ds.LastDetectedTime = assets.[LastDetectedTime],
				ds.LastRecordedTime = @RecordedTime
			from [RSDDetectedSource] ds
			join #RSDMatch m on m.HostID=ds.HostID and m.SourceID=ds.SourceID
			join #RSDAssets assets on assets.Active=1 and m.SourceID=assets.SourceID and assets.ExternalID is not NULL
			and ds.SourceType = assets.SourceType and ds.ExternalID = assets.ExternalID

			insert [RSDDetectedSource](HostID, SourceID, SourceType, ExternalID, FirstDetectedTime, LastDetectedTime, FirstRecordedTime, LastRecordedTime)
			select m.HostID, assets.SourceID, assets.SourceType, assets.ExternalID, assets.LastDetectedTime, assets.LastDetectedTime, @RecordedTime, @RecordedTime
			from #RSDMatch m
			join #RSDAssets assets on assets.Active=1 and m.SourceID=assets.SourceID and assets.ExternalID is not NULL
			left join [RSDDetectedSource] ds on m.HostID=ds.HostID and m.SourceID=ds.SourceID
			and ds.SourceType = assets.SourceType and ds.ExternalID = assets.ExternalID
			where ds.HostID is null
		end

		update ds
		set ds.LastDetectedTime = assets.LastDetectedTime,
			ds.LastRecordedTime = @RecordedTime
		from [RSDDetectedSource] ds
		join #RSDMatch m on m.HostID=ds.HostID and m.SourceID=ds.SourceID
		join #RSDAssets assets on assets.Active=1 and m.SourceID=assets.SourceID
		and ds.SourceType = assets.SourceType and assets.ExternalID is NULL and ds.ExternalID is NULL

		insert [RSDDetectedSource](HostID, SourceID, SourceType, ExternalID, FirstDetectedTime, LastDetectedTime, FirstRecordedTime, LastRecordedTime)
		select m.HostID, assets.SourceID, assets.SourceType, assets.ExternalID, assets.LastDetectedTime, assets.LastDetectedTime, @RecordedTime, @RecordedTime
		from #RSDMatch m
		join #RSDAssets assets on assets.Active=1 and m.SourceID=assets.SourceID and assets.ExternalID is NULL
		left join [RSDDetectedSource] ds on m.HostID=ds.HostID and m.SourceID=ds.SourceID
		and ds.SourceType = assets.SourceType and ds.ExternalID is NULL
		where ds.HostID is null

		--handle interfaces
		update m
		set m.InterfaceID=i.InterfaceID
		from [RSDInterfaceProperties] i
		join #RSDMatch m on i.HostID=m.HostID
		join #RSDAssets assets on m.SourceID=assets.SourceID and assets.MAC is NOT NULL and assets.MAC=i.MAC

		if exists(select 1 from #RSDMatch where InterfaceID is null)
			update m
			set m.InterfaceID=i.InterfaceID
			from [RSDInterfaceProperties] i
			join #RSDMatch m on i.HostID=m.HostID
			join #RSDAssets assets on m.SourceID=assets.SourceID and assets.IPV6 is NOT NULL and assets.IPV6=i.IPV6

		--update subnetID
		update m
		set m.SubnetID=s.SubnetID
		from #RSDMatch m
		join #RSDAssets assets on m.SourceID=assets.SourceID
		join RSDSubnetProperties s on (assets.IPV6 is NOT NULL)
		and (assets.IPV6 between s.IPV6Start and s.IPV6End);

		update #RSDMatch
			set SubnetID=@BitBucketID
			where SubnetID is null

		--update interfaces
		update i
		set	MAC = assets.MAC,
			OUI = case assets.MAC
					when null then 'FFFFFF'
					when '' then i.OUI
					else SUBSTRING(assets.MAC, 0, 7)
					end,
			IPV6 = assets.IPV6,
			SubnetID = m.SubnetID,
			LastDetectedTime = assets.LastDetectedTime,
			DetectedSourceType = assets.SourceType
		from [RSDInterfaceProperties] i
		join #RSDMatch m on m.InterfaceID=i.InterfaceID
		join #RSDAssets assets on m.SourceID=assets.SourceID
		join
			(select Max(id) mid, InterfaceID  from #RSDMatch
			where InterfaceID is not NULL group by InterfaceID) m2
				on m.id=m2.mid and m.InterfaceID=m2.InterfaceID

		--insert interfaces
		insert[RSDInterfaceProperties](HostID,MAC,OUI,IPV6,SubnetID,LastDetectedTime,DetectedSourceType)
		select distinct
			m.HostID,
			assets.MAC,
			OUI = case assets.MAC
					when null then 'FFFFFF'
					else SUBSTRING(assets.MAC, 0, 7)
					end,
			IPV6 = assets.IPV6,
			SubnetID = m.SubnetID,
			LastDetectedTime = assets.LastDetectedTime,
			DetectedSourceType = assets.SourceType
		from #RSDMatch m
		join #RSDAssets assets on m.SourceID=assets.SourceID
		where m.HostID > 0 and m.InterfaceID is null
		truncate table #RSDMatch
	end
END--}
GO


-- update newly detected systems
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDSP_Bulk_UpdateNewDetectedSystems]') AND xtype in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[RSDSP_Bulk_UpdateNewDetectedSystems]
GO
CREATE PROCEDURE [dbo].[RSDSP_Bulk_UpdateNewDetectedSystems]
as
begin--{
	set nocount on
	declare @RecordedTime datetime;
	set @RecordedTime = GETUTCDATE();

	--create unknown subnet first
	declare @BitBucketID int;
	select @BitBucketID=SubnetID FROM RSDSubnetProperties WHERE BitBucket=1;

	--insert one-match rsd first
	--insert to temp table for one-match update
	insert #RSDMatch(SourceID, GroupID)
	select m.SourceID, m.GroupID
	from #mgAsset m
	join (
			select GroupID from #mgAsset
			group by GroupID
			having count(*)=1
		) d
		on m.GroupID = d.GroupID
	join #RSDAssets assets
		on m.SourceID=assets.SourceID
	where assets.HostID=0

	--Create new RSD with only one asset in the group
	if exists(select * from #RSDMatch)
	begin--{
		--update GUID fot BulkInsert
		update #RSDMatch
		set BulkInsertID=newid()

		--set FriendlyName
		update a
		set a.FriendlyName =
			case when a.DnsName is not null then a.DnsName
				 when a.NetbiosName is not null then a.NetbiosName
				 when a.IPAddress is not null then a.IPAddress
				 when a.MAC is not null then a.MAC
			else ''
			end,
			a.Active=1
		from #RSDAssets a join #RSDMatch m on m.SourceID=a.SourceID

		--Create RSD system
		insert into RSDDetectedSystemProperties
		(
			[DnsName],
			[OSPlatform],
			[OSFamily],
			[OSVersion],
			[Domain],
			[NetbiosName],
			[NetbiosComment],
			[Users],
			[AgentGUID],
			[FriendlyName],
			[IPV6],
			[MAC],
			[DetectedSourceType],
			[LastDetectedTime],
			BulkInsertID
		)
		select
			a.[DnsName],
			a.[OSPlatform],
			a.[OSFamily],
			a.[OSVersion],
			a.[Domain],
			a.[NetbiosName],
			a.[NetbiosComment],
			a.[Users],
			a.[AgentGUID],
			a.[FriendlyName],
			a.[IPV6],
			a.[MAC],
			a.SourceType,
			a.[LastDetectedTime],
			m.BulkInsertID
		from #RSDAssets a join #RSDMatch m on m.SourceID=a.SourceID

		--Get HostID back
		update m
		set m.HostID=rsd.HostID
		from #RSDMatch m
		join RSDDetectedSystemProperties rsd
			on rsd.BulkInsertID is not null and m.BulkInsertID=rsd.BulkInsertID

		--make it null right away
		update rsd
		set rsd.BulkInsertID=null
		from #RSDMatch m join RSDDetectedSystemProperties rsd on m.HostID=rsd.HostID

		-- set hostID
		update assets
		set assets.HostID=m.HostID,
			assets.Active=1
		from #RSDAssets	assets
		join #RSDMatch m
			on assets.SourceID=m.SourceID

		insert [RSDDetectedSource](HostID, SourceID, SourceType, ExternalID, FirstDetectedTime, LastDetectedTime, FirstRecordedTime, LastRecordedTime)
		select m.HostID, assets.SourceID, assets.SourceType, assets.ExternalID, assets.LastDetectedTime, assets.LastDetectedTime, @RecordedTime, @RecordedTime
		from #RSDMatch m
		join #RSDAssets assets on m.SourceID=assets.SourceID

		--handle interfaces

		--update subnetID
		update m
		set m.SubnetID=s.SubnetID
		from #RSDMatch m
		join #RSDAssets assets on m.SourceID=assets.SourceID
		join RSDSubnetProperties s on assets.IPV6 is NOT NULL
		and (assets.IPV6 between s.IPV6Start and s.IPV6End);

		--Ensure SubnetID is not NULL
		update #RSDMatch
			set SubnetID=@BitBucketID
			where SubnetID is null

		--insert interfaces
		insert[RSDInterfaceProperties](HostID,MAC,OUI,IPV6,SubnetID,LastDetectedTime,DetectedSourceType)
		select distinct
			m.HostID,
			assets.MAC,
			OUI = case assets.MAC
					when null then 'FFFFFF'
					else SUBSTRING(assets.MAC, 0, 7)
					end,
			IPV6 = assets.IPV6,
			SubnetID = m.SubnetID,
			LastDetectedTime = assets.LastDetectedTime,
			DetectedSourceType = assets.SourceType
		from #RSDMatch m
		join #RSDAssets assets on m.SourceID=assets.SourceID
		truncate table #RSDMatch
	end--}

	--insert multi matches
	insert #RSDMatch(SourceID, GroupID, HostID)
	select m.SourceID, m.GroupID, 0
	from #mgAsset m
	join #RSDAssets assets
		on m.SourceID=assets.SourceID
	where assets.HostID=0
	order by assets.LastDetectedTime

	if exists(select * from #RSDMatch)
	begin--{
		--update GUID fot BulkInsert
		update #RSDMatch
		set BulkInsertID=newid()

		--select the latest one for insert
		update assets
		set assets.Active=1
		from #RSDAssets assets join #RSDMatch m on m.SourceID=assets.SourceID
		join (select max(id) maxID from #RSDMatch group by GroupID) l on m.Id=l.maxID

		--merge properties
		--update DNSName
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.DnsName is null and m.SourceID=assets.SourceID and assets.Active=1
				)
		begin--{
			update assets
			set assets.DnsName=f.DnsName
			from #RSDAssets assets join #RSDMatch m on assets.DnsName is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join
			(select m2.GroupID, assets2.DnsName
			from #RSDAssets assets2 join #RSDMatch m2 on m2.SourceID=assets2.SourceID
				join
				(select max(m1.id) mid
				from #RSDMatch m1 join #RSDAssets assets1 on m1.SourceID=assets1.SourceID
				where assets1.DnsName is not null group by m1.GroupID) n on m2.id=n.mid) f
			on m.GroupID=f.GroupID
		end--}

		--update OSPlatform
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.OSPlatform is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin--{
			update assets
			set assets.OSPlatform=f.OSPlatform
			from #RSDAssets assets join #RSDMatch m on assets.OSPlatform is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join
			(select m2.GroupID, assets2.OSPlatform
			from #RSDAssets assets2 join #RSDMatch m2 on m2.SourceID=assets2.SourceID
				join
				(select max(m1.id) mid
				from #RSDMatch m1 join #RSDAssets assets1 on m1.SourceID=assets1.SourceID
				where assets1.OSPlatform is not null group by m1.GroupID) n on m2.id=n.mid) f
			on m.GroupID=f.GroupID
		end--}

		--update OSFamily
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.OSFamily is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin--{
			update assets
			set assets.OSFamily=f.OSFamily
			from #RSDAssets assets join #RSDMatch m on assets.OSFamily is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join
			(select m2.GroupID, assets2.OSFamily
			from #RSDAssets assets2 join #RSDMatch m2 on m2.SourceID=assets2.SourceID
				join
				(select max(m1.id) mid
				from #RSDMatch m1 join #RSDAssets assets1 on m1.SourceID=assets1.SourceID
				where assets1.OSFamily is not null group by m1.GroupID) n on m2.id=n.mid) f
			on m.GroupID=f.GroupID
		end--}

		--update OSVersion
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.OSVersion is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin--{
			update assets
			set assets.OSVersion=f.OSVersion
			from #RSDAssets assets join #RSDMatch m on assets.OSVersion is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join
			(select m2.GroupID, assets2.OSVersion
			from #RSDAssets assets2 join #RSDMatch m2 on m2.SourceID=assets2.SourceID
				join
				(select max(m1.id) mid
				from #RSDMatch m1 join #RSDAssets assets1 on m1.SourceID=assets1.SourceID
				where assets1.OSVersion is not null group by m1.GroupID) n on m2.id=n.mid) f
			on m.GroupID=f.GroupID
		end--}

		--update Domain
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.Domain is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin--{
			update assets
			set assets.Domain=f.Domain
			from #RSDAssets assets join #RSDMatch m on assets.Domain is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join
			(select m2.GroupID, assets2.Domain
			from #RSDAssets assets2 join #RSDMatch m2 on m2.SourceID=assets2.SourceID
				join
				(select max(m1.id) mid
				from #RSDMatch m1 join #RSDAssets assets1 on m1.SourceID=assets1.SourceID
				where assets1.Domain is not null group by m1.GroupID) n on m2.id=n.mid) f
			on m.GroupID=f.GroupID
		end--}

		--update NetbiosName
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.NetbiosName is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin--{
			update assets
			set assets.NetbiosName=f.NetbiosName
			from #RSDAssets assets join #RSDMatch m on assets.NetbiosName is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join
			(select m2.GroupID, assets2.NetbiosName
			from #RSDAssets assets2 join #RSDMatch m2 on m2.SourceID=assets2.SourceID
				join
				(select max(m1.id) mid
				from #RSDMatch m1 join #RSDAssets assets1 on m1.SourceID=assets1.SourceID
				where assets1.NetbiosName is not null group by m1.GroupID) n on m2.id=n.mid) f
			on m.GroupID=f.GroupID
		end--}

		--update NetbiosComment
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.NetbiosComment is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin--{
			update assets
			set assets.NetbiosComment=f.NetbiosComment
			from #RSDAssets assets join #RSDMatch m on assets.NetbiosComment is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join
			(select m2.GroupID, assets2.NetbiosComment
			from #RSDAssets assets2 join #RSDMatch m2 on m2.SourceID=assets2.SourceID
				join
				(select max(m1.id) mid
				from #RSDMatch m1 join #RSDAssets assets1 on m1.SourceID=assets1.SourceID
				where assets1.NetbiosComment is not null group by m1.GroupID) n on m2.id=n.mid) f
			on m.GroupID=f.GroupID
		end--}

		--update Users
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.Users is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin--{
			update assets
			set assets.Users=f.Users
			from #RSDAssets assets join #RSDMatch m on assets.Users is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join
			(select m2.GroupID, assets2.Users
			from #RSDAssets assets2 join #RSDMatch m2 on m2.SourceID=assets2.SourceID
				join
				(select max(m1.id) mid
				from #RSDMatch m1 join #RSDAssets assets1 on m1.SourceID=assets1.SourceID
				where assets1.Users is not null group by m1.GroupID) n on m2.id=n.mid) f
			on m.GroupID=f.GroupID
		end--}

		--update AgentGUID
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.AgentGUID is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin--{
			update assets
			set assets.AgentGUID=f.AgentGUID
			from #RSDAssets assets join #RSDMatch m on assets.AgentGUID is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join
			(select m2.GroupID, assets2.AgentGUID
			from #RSDAssets assets2 join #RSDMatch m2 on m2.SourceID=assets2.SourceID
				join
				(select max(m1.id) mid
				from #RSDMatch m1 join #RSDAssets assets1 on m1.SourceID=assets1.SourceID
				where assets1.AgentGUID is not null group by m1.GroupID) n on m2.id=n.mid) f
			on m.GroupID=f.GroupID
		end--}

		--update IPV6
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.IPV6 is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin--{
			update assets
			set assets.IPV6=f.IPV6,
				assets.IPAddress=f.IPAddress
			from #RSDAssets assets join #RSDMatch m on assets.IPV6 is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join
			(select m2.GroupID, assets2.IPV6, assets2.IPAddress
			from #RSDAssets assets2 join #RSDMatch m2 on m2.SourceID=assets2.SourceID
				join
				(select max(m1.id) mid
				from #RSDMatch m1 join #RSDAssets assets1 on m1.SourceID=assets1.SourceID
				where assets1.IPV6 is not null group by m1.GroupID) n on m2.id=n.mid) f
			on m.GroupID=f.GroupID
		end--}

		--update MAC
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.MAC is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin--{
			update assets
			set assets.MAC=f.MAC
			from #RSDAssets assets join #RSDMatch m on assets.MAC is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join
			(select m2.GroupID, assets2.MAC
			from #RSDAssets assets2 join #RSDMatch m2 on m2.SourceID=assets2.SourceID
				join
				(select max(m1.id) mid
				from #RSDMatch m1 join #RSDAssets assets1 on m1.SourceID=assets1.SourceID
				where assets1.MAC is not null group by m1.GroupID) n on m2.id=n.mid) f
			on m.GroupID=f.GroupID
		end--}

		--update LastDetectedTime
		if exists(	select 1 from #RSDAssets assets join #RSDMatch m
					on assets.LastDetectedTime is null and m.SourceID=assets.SourceID
					and assets.Active=1
				)
		begin--{
			update assets
			set assets.LastDetectedTime=f.LastDetectedTime
			from #RSDAssets assets join #RSDMatch m on assets.LastDetectedTime is null and m.SourceID=assets.SourceID
			and assets.Active=1
			join
			(select m2.GroupID, assets2.LastDetectedTime
			from #RSDAssets assets2 join #RSDMatch m2 on m2.SourceID=assets2.SourceID
				join
				(select max(m1.id) mid
				from #RSDMatch m1 join #RSDAssets assets1 on m1.SourceID=assets1.SourceID
				where assets1.LastDetectedTime is not null group by m1.GroupID) n on m2.id=n.mid) f
			on m.GroupID=f.GroupID
		end--}

		--set FriendlyName
		update a
		set a.FriendlyName =
			case when a.DnsName is not null then a.DnsName
				 when a.NetbiosName is not null then a.NetbiosName
				 when a.IPAddress is not null then a.IPAddress
				 when a.MAC is not null then a.MAC
			else ''
			end
		from #RSDMatch m join #RSDAssets a on a.Active=1 and m.SourceID=a.SourceID
		--insert RSD
		insert into RSDDetectedSystemProperties
		(
			[DnsName],
			[OSPlatform],
			[OSFamily],
			[OSVersion],
			[Domain],
			[NetbiosName],
			[NetbiosComment],
			[Users],
			[AgentGUID],
			[FriendlyName],
			[IPV6],
			[MAC],
			[DetectedSourceType],
			[LastDetectedTime],
			BulkInsertID
		)
		select
			a.[DnsName],
			a.[OSPlatform],
			a.[OSFamily],
			a.[OSVersion],
			a.[Domain],
			a.[NetbiosName],
			a.[NetbiosComment],
			a.[Users],
			a.[AgentGUID],
			a.[FriendlyName],
			a.[IPV6],
			a.[MAC],
			a.SourceType,
			a.[LastDetectedTime],
			m.BulkInsertID
		from #RSDMatch m join #RSDAssets a on a.Active=1 and m.SourceID=a.SourceID

		--Get HostID back
		update m
		set m.HostID=rsd.HostID
		from #RSDMatch m
		join RSDDetectedSystemProperties rsd
			on rsd.BulkInsertID is not null and m.BulkInsertID=rsd.BulkInsertID

		--make it null right away
		update rsd
		set rsd.BulkInsertID=null
		from #RSDMatch m
		join RSDDetectedSystemProperties rsd
			on m.HostID=rsd.HostID

		-- set hostID
		update m
		set m.HostID=n.HostID
		from #RSDMatch m join
			(select GroupID, HostID
			from #RSDMatch
			where HostID > 0) n
		on m.GroupID=n.GroupID and m.HostID = 0

		update assets
		set assets.HostID=m.HostID
		from #RSDAssets	assets
		join #RSDMatch m on assets.SourceID = m.SourceID and assets.HostID = 0
		--set Source
		insert [RSDDetectedSource](HostID, SourceID, SourceType, ExternalID, FirstDetectedTime, LastDetectedTime, FirstRecordedTime, LastRecordedTime)
		select m.HostID, assets.SourceID, assets.SourceType, assets.ExternalID, assets.LastDetectedTime, assets.LastDetectedTime, @RecordedTime, @RecordedTime
		from #RSDMatch m
		join #RSDAssets assets on m.SourceID=assets.SourceID

		--handle interfaces

		--update subnetID
		update m
		set m.SubnetID=s.SubnetID
		from #RSDMatch m
		join #RSDAssets assets on m.SourceID=assets.SourceID
		join RSDSubnetProperties s on assets.IPV6 is NOT NULL
		and (assets.IPV6 between s.IPV6Start and s.IPV6End);

		-- no subnet gets the bitbucket
		update #RSDMatch
			set SubnetID=@BitBucketID
			where SubnetID is null

		--insert interfaces
		insert[RSDInterfaceProperties](HostID,MAC,OUI,IPV6,SubnetID,LastDetectedTime,DetectedSourceType)
		select distinct
			m.HostID,
			assets.MAC,
			OUI = case assets.MAC
					when null then 'FFFFFF'
					else SUBSTRING(assets.MAC, 0, 7)
					end,
			IPV6 = assets.IPV6,
			SubnetID = m.SubnetID,
			LastDetectedTime = assets.LastDetectedTime,
			DetectedSourceType = assets.SourceType
		from #RSDMatch m
		join #RSDAssets assets on m.SourceID=assets.SourceID
	end--}
END--}
GO


-- loader for main bulk import
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDSP_BulkUpdate]'))
	DROP PROCEDURE [dbo].[RSDSP_BulkUpdate]
GO
CREATE PROCEDURE dbo.RSDSP_BulkUpdate
(
	@rowsource nvarchar(128)	-- stored proc that returns potential match rows.
)
AS
BEGIN
	-- squelch client row callbacks
	SET NOCOUNT ON;

	--create unknown subnet first if not existing
	if not exists(select 1 from dbo.RSDSubnetProperties where BitBucket=1)
	begin
		insert into [dbo].[RSDSubnetProperties] (SubnetName, IPV6, IPV6mask, BitBucket)
		values ('Unknown Subnet', 0x00000000000000000000FFFF00000000, 0x00000000000000000000FFFFFFFFFFFF, 1)
	end

	-- drop all of these if they exist (note: this is completely unsuported by MS and prone to break)
	IF EXISTS (SELECT * FROM [tempdb].[dbo].[sysobjects] WHERE id = OBJECT_ID(N'tempdb..#RSDAssets'))
		DROP TABLE #RSDAssets;
	IF EXISTS (SELECT * FROM [tempdb].[dbo].[sysobjects] WHERE id = OBJECT_ID(N'tempdb..#RSDMatch'))
		DROP TABLE #RSDMatch;
	IF EXISTS (SELECT * FROM [tempdb].[dbo].[sysobjects] WHERE id = OBJECT_ID(N'tempdb..#mgAsset'))
		DROP TABLE #mgAsset;

	CREATE TABLE #RSDAssets
	(
		[DNSName] [nvarchar](255) NULL,
		[OSPlatform] [nvarchar](25) NULL,
		[OSFamily] [nvarchar](128) NULL,
		[OSVersion] [nvarchar](128) NULL,
		[Domain] [nvarchar](255) NULL,
		[NetbiosName] [nvarchar](16) NULL,
		[NetbiosComment] [nvarchar](100) NULL,
		[Users] [nvarchar](128) NULL,
		[AgentGUID] [uniqueidentifier] NULL,
		[FriendlyName] [nvarchar](255) NULL,
		[IPV4] [int] NULL,
		[IPV6] BINARY(16) NULL,
		[IPAddress] varchar(20) null,
		[MAC] [nvarchar](12) NULL,
		[LastDetectedTime] [datetime] NULL,
		[SourceID] int not NUll PRIMARY KEY,
		[SourceType] nvarchar(100),
		[ExternalID] nvarchar(1000),
		[HostID] int not NULL default 0,
		[Active] bit not null default 0
	);

	-- table for storing matches
	CREATE TABLE #RSDMatch
	(
		[Id] int IDENTITY(1,1),
		[SourceID] int,
		[HostID] int,
		[InterfaceID] int,
		[SubnetID] int,
		[GroupID] int,
		[BulkInsertID] uniqueidentifier
	);

	-- table for grouping assets.
	CREATE TABLE #mgAsset
	(
		SourceID int primary key,
		GroupID int,
		GuidGroupID int,
		SourceGroupID int,
		MACGroupID int,
		HostDomainGroupID int,
		DnsGroupID int,
		IpGroupID int,
		HostGroupID int
	);

	-- populate incoming potentials systems
	DECLARE @flds nvarchar(500);
	DECLARE @sql nvarchar(1000);
	SET @flds = N'[DNSName],[OSPlatform],[OSFamily],[OSVersion],[Domain],[NetBIOSName],[AgentGUID],'
	SET @flds = @flds + N'[IPV4],[IPAddress],[MAC],[LastDetectedTime],[SourceID],[SourceType],[HostID]';
	SET @sql = N'INSERT INTO #RSDAssets(' + @flds + N') SELECT ' + @flds + N' FROM ' + @rowsource;

	-- populate temp table with caller's data set
	EXECUTE sp_executesql @sql;
	
	-- squelch opaque mask IP addresses
	UPDATE #RSDAssets
	SET IPV4 = NULL
	WHERE (IPV4 = -2147483648)

	-- convert IPV4's to IPV6
	UPDATE #RSDAssets
	SET [IPV6] = [dbo].[RSDFN_ConvertIntToIPV6Binary]([IPV4])
	WHERE ([IPV4] IS NOT NULL);
	
	-- done just to ensure we're not referencing this from *anywhere*
	ALTER TABLE #RSDAssets
		DROP COLUMN [IPV4];
		
    --Group all new systems
	EXEC [dbo].[RSDSP_Bulk_MatchNewDetectedSystems]

	--Find matching RSDDetectedSystems
	EXEC [dbo].[RSDSP_Bulk_MatchDetectedSystems]

	--update the HostIDs of the system in a group where one or more systems found RSD Matches
	UPDATE a SET a.HostID=b.MaxHostID
	FROM #RSDAssets a JOIN #mgAsset g ON (a.SourceID=g.SourceID)
	JOIN
		(SELECT m.GroupID, MAX(assets.HostID) MaxHostID
		 FROM #RSDAssets assets JOIN #mgAsset m	ON m.SourceID=assets.SourceID
		 WHERE assets.HostID > 0
		 GROUP BY m.GroupID) b
	ON g.GroupID=b.GroupID AND a.HostID=0

	--Update matching RSDDetectedSystems
	EXEC [dbo].[RSDSP_Bulk_UpdateDetectedSystems]

	--Create new rsd systems with no matchings
	EXEC [dbo].[RSDSP_Bulk_UpdateNewDetectedSystems]

	--Matching with Managed systems
	EXEC [dbo].[RSDSP_Bulk_MatchManagedSystems]

	-- return rowset for consumption by the invoker.
	SELECT SourceID, HostID, Active FROM #RSDAssets
    WHERE HostID IS NOT NULL AND HostID <> 0;

	-- final cleanup
	DROP TABLE #mgAsset
	DROP TABLE #RSDMatch
	DROP TABLE #RSDAssets
END
GO
-------------------------------------------------------------------------------
-- END RSD Bulk Update API
-------------------------------------------------------------------------------

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_ConvertIPV4BinaryToInt]') )
DROP FUNCTION [dbo].[RSDFN_ConvertIPV4BinaryToInt]
GO

CREATE FUNCTION [dbo].[RSDFN_ConvertIPV4BinaryToInt]
(
	@IPV4 binary(4)
)
RETURNS int
AS
BEGIN
	declare @ipv4BigInt bigint;
	set @ipv4BigInt = convert(bigint, @IPV4);
	set @ipv4BigInt = (@ipv4BigInt - 2147483648);

	return convert(int, @ipv4BigInt);
END
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_ConvertIPV6BinaryToInt]') )
DROP FUNCTION [dbo].[RSDFN_ConvertIPV6BinaryToInt]
GO

CREATE FUNCTION [dbo].[RSDFN_ConvertIPV6BinaryToInt]
(
    @IPV6 binary(16)
)
RETURNS int
AS
BEGIN
    -- If this is not IPv4 compatible, it will return null
    declare @ipint int;

    if ([dbo].[RSDFN_IsIPAddressIPv4Compatible] (@IPV6) = 1)
    begin
    	set @ipint = [dbo].[RSDFN_ConvertIPV4BinaryToInt](substring(@IPV6,13,4));
    end

    return @ipint;
END
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_ConvertIntToIPV6Binary]') )
DROP FUNCTION [dbo].[RSDFN_ConvertIntToIPV6Binary]
GO


CREATE FUNCTION [dbo].[RSDFN_ConvertIntToIPV6Binary]
(
    @IPV4 int
)
RETURNS binary(16)
AS
BEGIN
    if (@IPV4 is null) RETURN NULL;

    RETURN 0x00000000000000000000FFFF + [dbo].[RSDFN_ConvertIntToIPV4Binary](@IPV4);
END
GO


IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_ConvertIntToIPV4Binary]') )
DROP FUNCTION [dbo].[RSDFN_ConvertIntToIPV4Binary]
GO


CREATE FUNCTION [dbo].[RSDFN_ConvertIntToIPV4Binary]
(
    @ipin int
)
RETURNS BINARY(4)
AS
BEGIN
    if (@ipin is null) RETURN NULL;

	declare @o1 bigint, @o2 bigint, @o3 bigint, @o4 bigint;
	declare @ip bigint;

-- This is the magic epo conversion size...
    set @ip = (CAST(@ipin as bigint) + 2147483647) + 1;

    SET @o1 = @ip / 16777216;
    SET @ip = @ip % 16777216;
    SET @o2 = @ip / 65536;
    SET @ip = @ip % 65536;
    SET @o3 = @ip / 256;
    SET @ip = @ip % 256;
    SET @o4 = @ip;

    RETURN
        CONVERT(BINARY(1), @o1) +
        CONVERT(BINARY(1), @o2) +
        CONVERT(BINARY(1), @o3) +
        CONVERT(BINARY(1), @o4)
END
GO


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TR_RSDInterfaceProperties_OnInsert]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TR_RSDInterfaceProperties_OnInsert]
GO

CREATE TRIGGER [dbo].[TR_RSDInterfaceProperties_OnInsert]
   ON  [dbo].[RSDInterfaceProperties]
   FOR INSERT, UPDATE
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- invoke user-defined translation function for all all affected IP address columns
	-- get the inserted

	IF (UPDATE(IPV6))
	BEGIN
	    -- Only update the IPv4 field if the v6 address is IPv4 compatible...
        UPDATE RSDInterfaceProperties
        SET IPV4 = [dbo].[RSDFN_ConvertIPV6BinaryToInt](B.IPV6)
        FROM inserted AS A INNER JOIN RSDInterfaceProperties AS B
        ON A.InterfaceID = B.InterfaceID where A.IPV6 is not null
            and [dbo].[RSDFN_IsIPAddressIPv4Compatible] (A.IPV6) = 1;
	END

END
GO



EXEC EPOCore_DropTrigger N'TR_RSDDetectedSystemProperties_OnInsert';
GO
CREATE TRIGGER [TR_RSDDetectedSystemProperties_OnInsert]
   ON  [dbo].[RSDDetectedSystemProperties]
   AFTER INSERT, UPDATE
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- invoke user-defined translation function for all all affected IP address columns
	IF (UPDATE(IPV6))
	BEGIN
	    -- Only update the IPv4 field if the v6 address is IPv4 compatible...
        UPDATE RDSP
        SET IPV4 = [dbo].[RSDFN_ConvertIPV6BinaryToInt](A.IPV6)
        FROM inserted A INNER JOIN RSDDetectedSystemProperties RDSP
        ON A.HostID = RDSP.HostID
		where A.IPV6 is not null
        and [dbo].[RSDFN_IsIPAddressIPv4Compatible] (A.IPV6) = 1;
	END
END
GO


EXEC EPOCore_DropTrigger N'TR_RSDSubnetProperties_OnInsert';
GO
CREATE TRIGGER [TR_RSDSubnetProperties_OnInsert]
   ON  [dbo].[RSDSubnetProperties]
   FOR INSERT, UPDATE
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- invoke user-defined translation function for all all affected IP address columns
	-- get the inserted
	IF (UPDATE(IPV6) OR UPDATE(IPV6Mask))
	BEGIN
		IF (UPDATE(IPV6))
		BEGIN
			-- Only update the IPv4 field if the v6 address is IPv4 compatible...
			UPDATE RSDSubnetProperties
			SET IPV4 = [dbo].[RSDFN_ConvertIPV6BinaryToInt](B.IPV6)
			FROM inserted AS A INNER JOIN RSDSubnetProperties AS B
			ON A.SubnetID = B.SubnetID
			WHERE (A.IPV6 is not null )
			AND [dbo].[RSDFN_IsIPAddressIPv4Compatible] (A.IPV6) = 1;
		END

		IF (UPDATE(IPV6mask))
		BEGIN
			-- Only update the IPv4 field if the v6 address is IPv4 compatible...
			UPDATE B
			SET IPV4mask = [dbo].[RSDFN_ConvertIPV6BinaryToInt](B.IPV6mask)
			FROM inserted AS A INNER JOIN RSDSubnetProperties AS B
			ON A.SubnetID = B.SubnetID
			WHERE (A.IPV6mask is not null )
			AND [dbo].[RSDFN_IsIPAddressIPv4Compatible] (A.IPV6mask) = 1;
		END

		-- all entries need to be range-updated
		UPDATE B
		SET IPV6Start = [dbo].[RSDFN_IPV6SubnetAddrStart](B.IPV6, B.IPV6Mask),
		 IPV6End = [dbo].[RSDFN_IPV6SubnetAddrEnd](B.IPV6, B.IPV6Mask)
		FROM inserted AS A INNER JOIN RSDSubnetProperties AS B
		ON A.SubnetID = B.SubnetID
		WHERE (B.IPV6 is not null and B.IPV6mask is not null);
	END
END
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_DetectedSystemTransaction_InterfacesByHostID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[RSDSP_DetectedSystemTransaction_InterfacesByHostID]
GO

CREATE PROCEDURE [dbo].[RSDSP_DetectedSystemTransaction_InterfacesByHostID]
(
    @HostID int
)
AS
BEGIN
    SET NOCOUNT ON;

    select RSDInterfaceProperties.InterfaceID,
		RSDInterfaceProperties.OUI,
        RSDInterfaceProperties.LastDetectedTime,
		RSDInterfaceProperties.MAC,
        RSDInterfaceProperties.IPV6,
		RSDSubnetProperties.IPV6mask,
		RSDSubnetProperties.IPV6 as IPV6subnet
    from [dbo].[RSDInterfaceProperties] left join [dbo].[RSDSubnetProperties] on RSDInterfaceProperties.SubnetID = RSDSubnetProperties.SubnetID
    where RSDInterfaceProperties.HostID = @HostID;

END
GO


if exists (select * from .[dbo].sysobjects where id = object_id(N'.[dbo].[RSDSensorBlacklist]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[RSDSensorBlacklist]
GO


-- Update tables for RSD 4.5
CREATE VIEW [dbo].[RSDSensorBlacklist]
AS
SELECT
        EPOComputerProperties.ParentID,
        EPOComputerProperties.ComputerName,
        EPOComputerProperties.DomainName as Domain,
        [dbo].[RSDFN_ConvertIPV6BinaryToInt]([EPOComputerProperties].[IPV6]) as IPV4,
        EPOComputerProperties.IPHostName as DnsName,
        EPOComputerProperties.NetAddress as MAC,
        EPOLeafNode.AgentGUID,
        EPOComputerProperties.IPV6
FROM    EPOComputerProperties
    JOIN EPOLeafNode ON EPOComputerProperties.ParentID = EPOLeafNode.AutoID
    JOIN RSDSensorBlacklistTarget ON EPOLeafNode.AgentGUID = RSDSensorBlacklistTarget.AgentGUID
GO


IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_GetEpoServerNameForDetectedSystem]') )
DROP FUNCTION [dbo].[RSDFN_GetEpoServerNameForDetectedSystem]
GO

-- Update/add stored proc/function for RSD 4.5
CREATE FUNCTION [dbo].[RSDFN_GetEpoServerNameForDetectedSystem]
(
    @HostID int
)
RETURNS nvarchar(255)
AS
BEGIN
    declare @ServerName nvarchar(255);
    declare @AgentGUID uniqueidentifier;
    declare @LeafNodeID int;

    -- If this is a managed machine, use the ComputerName from EPOServerInfo, otherwise see
    -- if it is an alternative epo server, if not, this is should return null
    select @AgentGUID = AgentGUID from [dbo].[RSDDetectedSystemProperties] where HostID = @HostID;
    select @LeafNodeID = AutoID from [dbo].[EPOLeafNode] where AgentGUID = @AgentGUID;
    if (@LeafNodeID is not null)
    begin
        -- TODO: Is there guaranteed to only be one row?
        select @ServerName = ComputerName from [dbo].[EPOServerInfo]
    end
    else
    begin
        select @ServerName = ServerName from [dbo].[RSDDetectedSystemAgentProperties] where HostID = @HostID;
    end

    return @ServerName;
END
GO


IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_GetOUIFromMAC]') )
DROP FUNCTION [dbo].[RSDFN_GetOUIFromMAC]
GO


CREATE FUNCTION [dbo].[RSDFN_GetOUIFromMAC]
(
    @MAC    nvarchar(12)
)
RETURNS nvarchar(6)
AS
BEGIN
    declare @OUI nvarchar(6);
    if ( @MAC is not null )
    begin
        set @OUI = SUBSTRING(@MAC, 0, 7);
    end
    else
    begin
        set @OUI = '';
    end

    return @OUI;
END
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_GetExceptionCategoryName]') )
DROP FUNCTION [dbo].[RSDFN_GetExceptionCategoryName]
GO

CREATE FUNCTION [dbo].[RSDFN_GetExceptionCategoryName]
(
    @CategoryID     int
)
RETURNS nvarchar(100)
AS
BEGIN
    RETURN (select [Name] from [dbo].[RSDExceptionCategories] where CategoryID = @CategoryID);
END
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_AddExceptionCategory]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[RSDSP_AddExceptionCategory]
GO

CREATE PROCEDURE [dbo].[RSDSP_AddExceptionCategory]
(
    @Name           nvarchar(100),
    @Description    nvarchar(1000),
    @CategoryID     int output,
    @ReturnCode     int output
)
AS
BEGIN
    set @CategoryID = 0;

    declare @cnt int
    select @cnt = count(*) from RSDExceptionCategories where [Name] = @Name

    if (@cnt > 0)
    begin
		select @CategoryID = CategoryID from RSDExceptionCategories where [Name] = @Name
        set @ReturnCode = 1
        return
    end

    insert into RSDExceptionCategories ([Name], Description) values (@Name, @Description)
    set @CategoryID = SCOPE_IDENTITY()

    set @ReturnCode = 0

END
GO

IF NOT EXISTS(SELECT * FROM [dbo].[syscolumns] WHERE id = OBJECT_ID(N'[dbo].[RSDSensorProperties]') AND [name] = N'ComputerName')
	ALTER TABLE [dbo].[RSDSensorProperties] ADD [ComputerName] [nvarchar] (255) NULL
GO

IF NOT EXISTS(SELECT * FROM [dbo].[syscolumns] WHERE id = OBJECT_ID(N'[dbo].[RSDSensorProperties]') AND [name] = N'FirstCommunicationTime')
	ALTER TABLE [dbo].[RSDSensorProperties] ADD [FirstCommunicationTime] [datetime] NOT NULL DEFAULT GETUTCDATE()
GO

IF NOT EXISTS(SELECT * FROM [dbo].[syscolumns] WHERE id = OBJECT_ID(N'[dbo].[RSDSensorProperties]') AND [name] = N'FirstRecordedTime')
	ALTER TABLE [dbo].[RSDSensorProperties] ADD [FirstRecordedTime] [datetime] NOT NULL DEFAULT GETUTCDATE()
GO

IF NOT EXISTS(SELECT * FROM [dbo].[syscolumns] WHERE id = OBJECT_ID(N'[dbo].[RSDSensorProperties]') AND [name] = N'LastRecordedTime')
	ALTER TABLE [dbo].[RSDSensorProperties] ADD [LastRecordedTime] [datetime] NOT NULL DEFAULT GETUTCDATE()
GO

IF NOT EXISTS(SELECT * FROM [dbo].[syscolumns] WHERE id = OBJECT_ID(N'[dbo].[RSDSensorProperties]') AND [name] = N'LastStartedTime')
	ALTER TABLE [dbo].[RSDSensorProperties] ADD [LastStartedTime] [datetime] NULL
GO

IF NOT EXISTS(SELECT * FROM [dbo].[syscolumns] WHERE id = OBJECT_ID(N'[dbo].[RSDSensorProperties]') AND [name] = N'LastStoppedTime')
	ALTER TABLE [dbo].[RSDSensorProperties] ADD [LastStoppedTime] [datetime] NULL
GO


IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_GetSensorStatus]') )
DROP FUNCTION [dbo].[RSDFN_GetSensorStatus]
GO

CREATE FUNCTION [dbo].[RSDFN_GetSensorStatus]
(
    @SensorID           int,
    @CompareDateTime    datetime
)
RETURNS int
AS
BEGIN
    -- 1 = active, 2 = passive, 3 = missing, 0 = unknown
    declare @ret int;
    declare @aguid uniqueidentifier;
    select @aguid = AgentGUID from [dbo].[RSDSensorProperties] where SensorID = @SensorID;
    set @ret = [dbo].[RSDFN_ManagedSystemHasSensorByAgentGUID](@aguid);
    if (@ret <> 0)
    begin
        declare @started bit;
        declare @lastCommunicationTime datetime;

        select @started = Started, @lastCommunicationTime = LastCommunicationTime from RSDSensorProperties where SensorID = @SensorID;

        if (@started = 1)
        begin
            declare @sensorTimeout int;
            select @sensorTimeout = SensorTimeout from RSDConfiguration where ID = 1;

            if ( @lastCommunicationTime < DATEADD(minute, -1 * @sensorTimeout, @CompareDateTime) )
            begin
                set @ret = 3;
            end
            else
            begin
                set @ret = 1;
            end
        end
        else
        begin
            set @ret = 2;
        end
    end

    return @ret;
END
GO


if exists (select * from .[dbo].sysobjects where id = object_id(N'.[dbo].[RSDSensors]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[RSDSensors]
GO

CREATE VIEW [dbo].[RSDSensors]
AS
SELECT  RSDSensorProperties.SensorID,
        RSDSensorProperties.SensorName,
        RSDSensorProperties.LastCommunicationTime,
        RSDSensorProperties.AgentGUID,
        RSDSensorProperties.SensorType,
        RSDSensorProperties.SensorVersion,
        RSDSensorProperties.Description,
        RSDSensorProperties.Started,
        RSDSensorProperties.ComputerName,
        RSDSensorProperties.FirstCommunicationTime,
        RSDSensorProperties.FirstRecordedTime,
        RSDSensorProperties.LastRecordedTime,
        RSDSensorProperties.LastStartedTime,
        RSDSensorProperties.LastStoppedTime,
        [dbo].[RSDFN_GetSensorStatus](RSDSensorProperties.SensorID, GETUTCDATE()) as Status,
        [dbo].[RSDFN_ManagedSystemHasSensorByAgentGUID](RSDSensorProperties.AgentGUID) as Installed
FROM    RSDSensorProperties
GO






IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_IsIPAddressIPv4Compatible]') )
DROP FUNCTION [dbo].[RSDFN_IsIPAddressIPv4Compatible]
GO



-- Update/add stored proc/function for RSD 4.5
CREATE FUNCTION [dbo].[RSDFN_IsIPAddressIPv4Compatible]
(
    @IPAddr varbinary(16)
)
RETURNS bit
AS
BEGIN
    if (DATALENGTH(@IPAddr) = 4) return 1;

    if (DATALENGTH(@IPAddr) = 16)
    begin
        declare @a bigint;
        set @a = CONVERT(bigint, SUBSTRING(@IPAddr, 1, 8));
        declare @b int;
        set @b = CONVERT(int, SUBSTRING(@IPAddr, 9, 2));
        declare @c int;
        set @c = CONVERT(int, SUBSTRING(@IPAddr, 11, 2));

        if ( ((@a & 0xFFFFFFFFFFFFFFFF) = 0) and ((@b & 0xFFFF) = 0) and (((~@c) & 0xFFFF) = 0)) return 1;
	end

	return 0;
END
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_ConvertIPAddrToDisplayString]') )
DROP FUNCTION [dbo].[RSDFN_ConvertIPAddrToDisplayString]
GO


CREATE FUNCTION [dbo].[RSDFN_ConvertIPAddrToDisplayString]
(
  @IPAddr varbinary(16)
)
RETURNS NVARCHAR(100)
AS
BEGIN
    declare @name nvarchar(100);

	if (DATALENGTH(@IPAddr) = 4)
	begin
		set @name = [dbo].[RSDFN_ConvertBigIntToIPString] (CONVERT(bigint, @IPAddr));
		return @name;
	end

    if ([dbo].[RSDFN_IsIPAddressIPv4Compatible] (@IPAddr) = 1)
    begin
        set @name = [dbo].[RSDFN_ConvertBigIntToIPString] (CONVERT(bigint, SUBSTRING(@IPAddr, 13, 4)));
		return @name;
    end

    -- This isn't IPv4, so gimme a IPv6 string...  Need to make this more flexible with variants
    declare @hex nvarchar(16);
    set @hex = '0123456789ABCDEF';

    declare @a1 int, @b1 int, @c1 int, @d1 int, @e1 int, @f1 int, @g1 int, @h1 int;
    set @a1 = convert(int, substring(@IPAddr, 1, 2));
    set @b1 = convert(int, substring(@IPAddr, 3, 2));
    set @c1 = convert(int, substring(@IPAddr, 5, 2));
    set @d1 = convert(int, substring(@IPAddr, 7, 2));
    set @e1 = convert(int, substring(@IPAddr, 9, 2));
    set @f1 = convert(int, substring(@IPAddr, 11, 2));
    set @g1 = convert(int, substring(@IPAddr, 13, 2));
    set @h1 = convert(int, substring(@IPAddr, 15, 2));

    declare @a nvarchar(4);
    set @a = substring(@hex, (@a1 / POWER(16, 3) ) % 16 + 1, 1) +
                substring(@hex, (@a1 / POWER(16, 2) ) % 16 + 1, 1) +
                substring(@hex, (@a1 / POWER(16, 1) ) % 16 + 1, 1) +
                substring(@hex, (@a1 / POWER(16, 0) ) % 16 + 1, 1);

    declare @b nvarchar(4);
    set @b = substring(@hex, (@b1 / POWER(16, 3) ) % 16 + 1, 1) +
                substring(@hex, (@b1 / POWER(16, 2) ) % 16 + 1, 1) +
                substring(@hex, (@b1 / POWER(16, 1) ) % 16 + 1, 1) +
                substring(@hex, (@b1 / POWER(16, 0) ) % 16 + 1, 1);

    declare @c nvarchar(4);
    set @c = substring(@hex, (@c1 / POWER(16, 3) ) % 16 + 1, 1) +
                substring(@hex, (@c1 / POWER(16, 2) ) % 16 + 1, 1) +
                substring(@hex, (@c1 / POWER(16, 1) ) % 16 + 1, 1) +
                substring(@hex, (@c1 / POWER(16, 0) ) % 16 + 1, 1);

    declare @d nvarchar(4);
    set @d = substring(@hex, (@d1 / POWER(16, 3) ) % 16 + 1, 1) +
                substring(@hex, (@d1 / POWER(16, 2) ) % 16 + 1, 1) +
                substring(@hex, (@d1 / POWER(16, 1) ) % 16 + 1, 1) +
                substring(@hex, (@d1 / POWER(16, 0) ) % 16 + 1, 1);

    declare @e nvarchar(4);
    set @e = substring(@hex, (@e1 / POWER(16, 3) ) % 16 + 1, 1) +
                substring(@hex, (@e1 / POWER(16, 2) ) % 16 + 1, 1) +
                substring(@hex, (@e1 / POWER(16, 1) ) % 16 + 1, 1) +
                substring(@hex, (@e1 / POWER(16, 0) ) % 16 + 1, 1);

    declare @f nvarchar(4);
    set @f = substring(@hex, (@f1 / POWER(16, 3) ) % 16 + 1, 1) +
                substring(@hex, (@f1 / POWER(16, 2) ) % 16 + 1, 1) +
                substring(@hex, (@f1 / POWER(16, 1) ) % 16 + 1, 1) +
                substring(@hex, (@f1 / POWER(16, 0) ) % 16 + 1, 1);

    declare @g nvarchar(4);
    set @g = substring(@hex, (@g1 / POWER(16, 3) ) % 16 + 1, 1) +
                substring(@hex, (@g1 / POWER(16, 2) ) % 16 + 1, 1) +
                substring(@hex, (@g1 / POWER(16, 1) ) % 16 + 1, 1) +
                substring(@hex, (@g1 / POWER(16, 0) ) % 16 + 1, 1);

    declare @h nvarchar(4);
    set @h = substring(@hex, (@h1 / POWER(16, 3) ) % 16 + 1, 1) +
                substring(@hex, (@h1 / POWER(16, 2) ) % 16 + 1, 1) +
                substring(@hex, (@h1 / POWER(16, 1) ) % 16 + 1, 1) +
                substring(@hex, (@h1 / POWER(16, 0) ) % 16 + 1, 1);

    set @name = @a+':'+@b+':'+@c+':'+@d+':'+@e+':'+@f+':'+@g+':'+@h;

    return @name;
END
GO


IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_CreateCanonicalName]') )
DROP FUNCTION [dbo].[RSDFN_CreateCanonicalName]
GO


CREATE FUNCTION [dbo].[RSDFN_CreateCanonicalName]
(
    @DnsName nvarchar(255),
	@NetbiosName nvarchar(16),
	@IPAddr varbinary(16),
	@EPOIP int,
	@MAC nvarchar(12)
)
RETURNS NVARCHAR(255)
AS
BEGIN
	declare @FriendlyName nvarchar(255);

    -- Friendly name is determined by the following, whichever one is not null
    if (@DnsName is not null)
    begin
        set @FriendlyName = @DnsName;
    end
    else
    begin
        if (@NetbiosName is not null)
        begin
            set @FriendlyName = @NetbiosName;
        end
        else
        begin
            if (@IPAddr is not null)
            begin
                set @FriendlyName = [dbo].[RSDFN_ConvertIPAddrToDisplayString](@IPAddr);
            end
            else
            begin
                if (@EPOIP is not null)
                begin
                    set @FriendlyName = [dbo].[RSDFN_ConvertIntToIPString](@EPOIP);
                end
                else
                begin
                    if (@MAC is not null)
                    begin
                        set @FriendlyName = [dbo].[RSDFN_ConvertMACToDisplayString](@MAC);
                    end
                    else
                    begin
                        set @FriendlyName = '';
                    end
                end
            end
        end
    end

	RETURN @FriendlyName;

END
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_IsManagedDetectedSystem]') )
DROP FUNCTION [dbo].[RSDFN_IsManagedDetectedSystem]
GO


CREATE FUNCTION [dbo].[RSDFN_IsManagedDetectedSystem]
(
    @HostID  int,
    @CompareDateTime datetime
)
RETURNS bit
AS
BEGIN
    declare @lastAgentComm int;
    select @lastAgentComm = LastAgentCommunication from RSDConfiguration where ID = 1

    declare @exception bit;
    declare @agentGUID uniqueidentifier;
    declare @lastAgentCommunication datetime;

    select @exception = Exception,
           @agentGUID = AgentGUID,
           @lastAgentCommunication = LastAgentCommunication
        from RSDDetectedSystems where HostID = @HostID;

    declare @ret bit;
    set @ret = 0;
    if (
        @exception = 0 and
        @agentGUID is not null and
        @lastAgentCommunication is not null and
        @lastAgentCommunication >= DATEADD(day, -1 * @lastAgentComm, @CompareDateTime)
        )
    begin
        -- Managed by this epo server
        set @ret = 1;
    end
    else
    begin
        declare @cnt int;

        select @cnt = count(*) from RSDDetectedSystems where HostID = @HostID and ServerName in
            (select ServerName from RSDConfigurationAlternateEpoServers)

        if (@cnt > 0)
        begin
            -- Managed by another known epo server, but not this one...
            set @ret = 1;
        end
    end

    return @ret;
END
GO


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_UpdateAgentInfo]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[RSDSP_UpdateAgentInfo]
GO

CREATE PROCEDURE [dbo].[RSDSP_UpdateAgentInfo]
(
    @HostID				int,
    @ComputerName       nvarchar(255),
    @ServerName         nvarchar(255),
    @AgentVersion       nvarchar(100),
    @AgentGUID          uniqueidentifier
)
AS
BEGIN

    declare @cnt int;
    select @cnt = count(*) from RSDDetectedSystemAgentProperties where HostID = @HostID;

    if (@cnt = 0)
    begin
        insert into RSDDetectedSystemAgentProperties (HostID, ComputerName, ServerName, AgentVersion, AgentGUID)
            values (@HostID, @ComputerName, @ServerName, @AgentVersion, @AgentGUID)
    end
    else
    begin
        update RSDDetectedSystemAgentProperties set ComputerName = @ComputerName, ServerName = @ServerName,
            AgentVersion = @AgentVersion, AgentGUID = @AgentGUID where HostID = @HostID
    end



END
GO



DELETE FROM EPONotificationProcessed where [Type] = 'rsdAddDetectedSystemEvent';
GO

INSERT INTO EPONotificationProcessed (Type, LastProcessedUTC) VALUES (N'rsdAddDetectedSystemEvent', GETUTCDATE())
GO


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_UpdateNewDetectedSystemEventCheck]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[RSDSP_UpdateNewDetectedSystemEventCheck]
GO


CREATE PROCEDURE [dbo].[RSDSP_UpdateNewDetectedSystemEventCheck]
(
	@LastProcessed	datetime
)
AS
BEGIN
	SET NOCOUNT ON;

    if (@LastProcessed is null)
    begin
	    set @LastProcessed = GETUTCDATE();
	end

	update [dbo].[EPONotificationProcessed] set LastProcessedUTC = @LastProcessed where [Type] = N'rsdAddDetectedSystemEvent';

END
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_GetNewDetectedSystemEvents]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[RSDSP_GetNewDetectedSystemEvents]
GO


CREATE PROCEDURE [dbo].[RSDSP_GetNewDetectedSystemEvents]
(
	@WhereClause	ntext
)
AS
BEGIN
	SET NOCOUNT ON;

    -- Create the Where clause for the timestamp, so we're only pulling events we haven't processed yet...
    declare @WhereTime nvarchar(128);
	set @WhereTime = 'RecordedTime > (select LastProcessedUTC from [dbo].[EPONotificationProcessed] where [Type] = N''rsdAddDetectedSystemEvent'')';

	-- If the where clause is null, then we must want all the events since the last time
	-- the Notification Threat Event triggered...  So, just get ALL events
	declare @LastProcessed datetime;
	set @LastProcessed = GETUTCDATE();
	if (@WhereClause is null)
	begin
		exec ('select HostID, DnsName, OSPlatform, OSFamily, OSVersion, Domain, NetbiosName, NetbiosComment, Users, AgentGUID,
		    FriendlyName, Ignored, Comments, IPV4, IPV6, MAC, Exception, RogueAction, LastDetectedTime, OrgName, OUI, NewDetection,
		    RogueState, Managed, Rogue, Inactive, DetectedSourceName, LastAgentCommunication, AgentVersion, ServerName
			from RSDDetectedSystems where ' + @WhereTime);
	end
	else
	begin
		exec ('select HostID, DnsName, OSPlatform, OSFamily, OSVersion, Domain, NetbiosName, NetbiosComment, Users, AgentGUID,
		    FriendlyName, Ignored, Comments, IPV4, IPV6, MAC, Exception, RogueAction, LastDetectedTime, OrgName, OUI, NewDetection,
		    RogueState, Managed, Rogue, Inactive, DetectedSourceName, LastAgentCommunication, AgentVersion, ServerName
			from RSDDetectedSystems where (' + @WhereTime + ') and (' + @WhereClause + ')' );
	end

    exec [dbo].[RSDSP_UpdateNewDetectedSystemEventCheck] @LastProcessed;

END
GO


-- This tries to select and match the incoming detected system with existing managed machines
EXEC EPOCore_DropStoredProc N'RSDSP_MatchManagedSystems';
GO
CREATE PROCEDURE [dbo].[RSDSP_MatchManagedSystems]
(
	@HostID				int,
    @AgentGUID          uniqueidentifier,
    @MAC                nvarchar(12),
    @ComputerName       nvarchar(16),
    @Domain             nvarchar(255),
    @DnsName            nvarchar(255),
    @IPV4               int,
    @IPV6               binary (16)
)
AS
BEGIN
    declare @managedMatching    int;

    -- The Configuration ID by default should always be 1
    select @managedMatching = [RSDConfiguration].[ManagedMatching]
        from [dbo].[RSDConfiguration]
        where [RSDConfiguration].[ID] = 1;

    declare @useAgentGUID       bit;
    declare @useProductGUID     bit;
    declare @useMAC             bit;
    declare @useHostnameDomain  bit;
    declare @useDNSName         bit;
    declare @useIPAddress       bit;
    declare @useHostname        bit;

    set @useAgentGUID = @managedMatching & 0x1;
    set @useProductGUID = @managedMatching & 0x2;
    set @useMAC = @managedMatching & 0x10;
    set @useHostnameDomain = @managedMatching & 0x20;
    set @useDNSName = @managedMatching & 0x40;
    set @useIPAddress = @managedMatching & 0x80;
    set @useHostname = @managedMatching & 0x100;

    declare @m_AgentGUID          uniqueidentifier;

    declare @found bit;
	declare @cnt int;
	declare @done bit;
	declare @results table (
		LeafNodeID		int,
		AgentGUID       uniqueidentifier,
		MAC             nvarchar(100),
		ComputerName    nvarchar(255),
		Domain          nvarchar(255),
		DnsName         nvarchar(255),
		IPV4            int,
		IPV6            binary (16)
	);

    set @found = 0;
	set @done = 0;
	set @cnt = 0;

    if (@AgentGUID is not null and @useAgentGUID = 1)
    begin

		insert into @results (LeafNodeID, AgentGUID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6)
			select [EPOLeafNode].[AutoID],
				   @AgentGUID,
				   [EPOComputerProperties].[NetAddress],
				   [EPOComputerProperties].[ComputerName],
				   [EPOComputerProperties].[DomainName],
				   [EPOComputerProperties].[IPHostName],
				   [dbo].[RSDFN_ConvertIPV6BinaryToInt]([EPOComputerProperties].[IPV6]),
				   [EPOComputerProperties].[IPV6]
			from [EPOLeafNode] WITH (NOLOCK)
				inner join [EPOComputerProperties] WITH (NOLOCK)
				on [EPOLeafNode].[AutoID] = [EPOComputerProperties].[ParentID]
			where [EPOLeafNode].[AgentGUID] = @AgentGUID;

		select @cnt = count(*) from @results;
		if (@cnt = 1)
		begin
            set @done = 1;
			set @m_AgentGUID = @AgentGUID;
		end

		-- In this case, we have already associated the AgentGUID to a ManagedSystem, so we're good
		-- unless we decide we want to update the DetectedSystem entry with known values from the ManagedSystem
		-- If more than one AgentGUID matches, we've got other problems...
    end

	if (@done = 0 and @MAC is not null and @useMAC = 1)
	begin
		if (@found = 0)
		begin
		    set @MAC = upper(@MAC);

			insert into @results (LeafNodeID, AgentGUID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6)
				select [EPOLeafNode].[AutoID],
					   [EPOLeafNode].[AgentGUID],
					   [EPOComputerProperties].[NetAddress],
					   [EPOComputerProperties].[ComputerName],
					   [EPOComputerProperties].[DomainName],
					   [EPOComputerProperties].[IPHostName],
    				   [dbo].[RSDFN_ConvertIPV6BinaryToInt]([EPOComputerProperties].[IPV6]),
					   [EPOComputerProperties].[IPV6]
				from [EPOLeafNode] WITH (NOLOCK)
					inner join [EPOComputerProperties] WITH (NOLOCK)
					on [EPOLeafNode].[AutoID] = [EPOComputerProperties].[ParentID]
				where upper([dbo].[EPOComputerProperties].[NetAddress]) = @MAC;

			select @cnt = count(*) from @results;

			if (@cnt = 1)
			begin
				set @done = 1;
				select @m_AgentGUID = AgentGUID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		-- Since this is the first possible case, there is no "else" here...
	end

	if (@done = 0 and @ComputerName is not null and @Domain is not null and @useHostnameDomain = 1)
	begin
		if (@found = 0)
		begin
			insert into @results (LeafNodeID, AgentGUID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6)
				select [EPOLeafNode].[AutoID],
					   [EPOLeafNode].[AgentGUID],
					   [EPOComputerProperties].[NetAddress],
					   [EPOComputerProperties].[ComputerName],
					   [EPOComputerProperties].[DomainName],
					   [EPOComputerProperties].[IPHostName],
    				   [dbo].[RSDFN_ConvertIPV6BinaryToInt]([EPOComputerProperties].[IPV6]),
					   [EPOComputerProperties].[IPV6]
				from [EPOLeafNode] WITH (NOLOCK)
					inner join [EPOComputerProperties] WITH (NOLOCK)
					on [EPOLeafNode].[AutoID] = [EPOComputerProperties].[ParentID]
				where [dbo].[EPOComputerProperties].[ComputerName] = @ComputerName
					and [dbo].[EPOComputerProperties].[DomainName] = @Domain;

			select @cnt = count(*) from @results;
			if (@cnt = 1)
			begin
				set @done = 1;
				select @m_AgentGUID = AgentGUID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		else
		begin
			delete R from @results as R where R.ComputerName <> @ComputerName and R.Domain <> @Domain;

			select @cnt = count(*) from @results;

			if (@cnt = 0)
			begin
				set @done = 1;
			end
			if (@cnt = 1)
			begin
				set @done = 1;
				select @m_AgentGUID = AgentGUID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
	end

	if (@done = 0 and @DnsName is not null and @useDNSName = 1)
	begin
		-- If we haven't found anything yet, insert this new selection into the DB
		if (@found = 0)
		begin
			insert into @results (LeafNodeID, AgentGUID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6)
				select [EPOLeafNode].[AutoID],
					   [EPOLeafNode].[AgentGUID],
					   [EPOComputerProperties].[NetAddress],
					   [EPOComputerProperties].[ComputerName],
					   [EPOComputerProperties].[DomainName],
					   [EPOComputerProperties].[IPHostName],
    				   [dbo].[RSDFN_ConvertIPV6BinaryToInt]([EPOComputerProperties].[IPV6]),
					   [EPOComputerProperties].[IPV6]
				from [EPOLeafNode] WITH (NOLOCK)
					inner join [EPOComputerProperties] WITH (NOLOCK)
					on [EPOLeafNode].[AutoID] = [EPOComputerProperties].[ParentID]
				where [dbo].[EPOComputerProperties].[IPHostName] = @DnsName;

			select @cnt = count(*) from @results;
			if (@cnt = 1)
			begin
				set @done = 1;
				select @m_AgentGUID = AgentGUID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		else
		begin
			delete R from @results as R where R.DnsName <> @DnsName;

			select @cnt = count(*) from @results;

			if (@cnt = 0)
			begin
				set @done = 1;
			end
			if (@cnt = 1)
			begin
				set @done = 1;
				select @m_AgentGUID = AgentGUID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
	end

	-- This is the IP Address check, it's gonna be a little nasty...
	if (@done = 0 and ( @IPV4 is not null or @IPV6 is not null) and @useIPAddress = 1)
	begin
		-- convert IPV4 to IPV6 so we can just use a single algorithm :)
		declare @ipaddr binary(16);
		if (@IPV4 is not null)
		begin
			set @ipaddr = [dbo].[RSDFN_ConvertIntToIPV6Binary](@IPV4);
		end
		else
		begin
			set @ipaddr = @IPV6;
		end

		-- We only want to do anything if this IPAddress falls in the correct range
		if ([dbo].[RSDFN_IsInRSDConfigurationIPRange](@ipaddr) = 1)
		begin
			if (@found = 0)
			begin
				if (@IPV4 is not null)
				begin
					insert into @results (LeafNodeID, AgentGUID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6)
						select [EPOLeafNode].[AutoID],
							   [EPOLeafNode].[AgentGUID],
							   [EPOComputerProperties].[NetAddress],
							   [EPOComputerProperties].[ComputerName],
							   [EPOComputerProperties].[DomainName],
							   [EPOComputerProperties].[IPHostName],
            				   [dbo].[RSDFN_ConvertIPV6BinaryToInt]([EPOComputerProperties].[IPV6]),
							   [EPOComputerProperties].[IPV6]
						from [EPOLeafNode] WITH (NOLOCK)
							inner join [EPOComputerProperties] WITH (NOLOCK)
							on [EPOLeafNode].[AutoID] = [EPOComputerProperties].[ParentID]
						where [dbo].[EPOComputerProperties].[IPV6] = [dbo].[RSDFN_ConvertIntToIPV6Binary](@IPV4);
				end
				else
				begin
					insert into @results (LeafNodeID, AgentGUID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6)
						select [EPOLeafNode].[AutoID],
							   [EPOLeafNode].[AgentGUID],
							   [EPOComputerProperties].[NetAddress],
							   [EPOComputerProperties].[ComputerName],
							   [EPOComputerProperties].[DomainName],
							   [EPOComputerProperties].[IPHostName],
            				   [dbo].[RSDFN_ConvertIPV6BinaryToInt]([EPOComputerProperties].[IPV6]),
							   [EPOComputerProperties].[IPV6]
					from [EPOLeafNode] WITH (NOLOCK)
						inner join [EPOComputerProperties] WITH (NOLOCK)
						on [EPOLeafNode].[AutoID] = [EPOComputerProperties].[ParentID]
						where [dbo].[EPOComputerProperties].[IPV6] = @IPV6;
				end

				select @cnt = count(*) from @results;
				if (@cnt = 1)
				begin
					set @done = 1;
					select @m_AgentGUID = AgentGUID from @results;
				end
				if (@cnt > 1)
				begin
					set @found = 1;
				end
			end
			else
			begin
				-- If this is IPV4, remove the IPV4 elements...
				if (@IPV4 is not null)
				begin
					delete R from @results as R where R.IPV4 <> @IPV4;
				end
				else
				begin
					delete R from @results as R where R.IPV6 <> @IPV6;
				end

    			select @cnt = count(*) from @results;
				if (@cnt = 0)
				begin
					set @done = 1;
				end
				if (@cnt = 1)
				begin
					set @done = 1;
					select @m_AgentGUID = AgentGUID from @results;
				end
				if (@cnt > 1)
				begin
					set @found = 1;
				end
			end
		end
	end

	-- Check for Hostname only!
	if (@done = 0 and @ComputerName is not null and @useHostname = 1)
	begin
		-- If we haven't found anything yet, insert this new selection into the DB
		if (@found = 0)
		begin
			insert into @results (LeafNodeID, AgentGUID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6)
				select [EPOLeafNode].[AutoID],
					   [EPOLeafNode].[AgentGUID],
					   [EPOComputerProperties].[NetAddress],
					   [EPOComputerProperties].[ComputerName],
					   [EPOComputerProperties].[DomainName],
					   [EPOComputerProperties].[IPHostName],
    				   [dbo].[RSDFN_ConvertIPV6BinaryToInt]([EPOComputerProperties].[IPV6]),
					   [EPOComputerProperties].[IPV6]
				from [EPOLeafNode] WITH (NOLOCK)
					inner join [EPOComputerProperties] WITH (NOLOCK)
					on [EPOLeafNode].[AutoID] = [EPOComputerProperties].[ParentID]
				where [dbo].[EPOComputerProperties].[ComputerName] = @ComputerName;

			select @cnt = count(*) from @results;
			if (@cnt = 1)
			begin
				set @done = 1;
				select @m_AgentGUID = AgentGUID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		else
		begin
			delete R from @results as R where R.ComputerName <> @ComputerName;
			select @cnt = count(*) from @results;

			if (@cnt = 0)
			begin
				set @done = 1;
			end
			if (@cnt = 1)
			begin
				set @done = 1;
				select @m_AgentGUID = AgentGUID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
	end


	if (@done = 1 and @m_AgentGUID is not null)
	begin
		update [dbo].[RSDDetectedSystemProperties]
		set AgentGUID = @m_AgentGUID, RogueAction = 0
		where HostID = @HostID
		and (AgentGUID is null OR AgentGUID <> @m_AgentGUID OR RogueAction is null OR RogueAction <> 0);
	end
END
GO


IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_GetSubnetID]') )
DROP FUNCTION [dbo].[RSDFN_GetSubnetID]
GO

CREATE FUNCTION [dbo].[RSDFN_GetSubnetID]
(
	@ipv6	    binary(16),
	@ipv6mask   binary(16)
)
RETURNS int
AS
BEGIN
    declare @SubnetID int;

    declare @cnt int;
    set @cnt = 0;

    -- Check to see if the subnet already exists
    select @cnt = count(*) from [dbo].[RSDSubnetProperties] where IPV6 = @ipv6;
    if (@cnt > 0)
    begin
        if (@cnt = 1)
        begin
            select @SubnetID = SubnetID from [dbo].[RSDSubnetProperties] where IPV6 = @ipv6;
        end
        else
        begin
            select @SubnetID = SubnetID from [dbo].[RSDSubnetProperties] where IPV6 = @ipv6 and IPV6mask = @ipv6mask;
        end
    end

	return @SubnetID;
END
GO


ALTER PROCEDURE [dbo].[RSDSP_UpdateSubnets]
(
    @IPV6           varbinary (16),
    @IPV6mask       varbinary (16),
    @OutputSubnetID int OUTPUT
)
AS
BEGIN
	-- If the ip addrs to add are null, really can't do much here...
	if (@IPV6 is null or DATALENGTH(@IPV6) = 0 or @IPV6mask is null or DATALENGTH(@IPV6mask) = 0)
	begin
	    set @OutputSubnetID = 1;
	    return;
    end

    declare @SubnetID int;
    declare @SubnetName nvarchar(255);
    declare @SubnetMaskInt int;

    set @SubnetID = [dbo].[RSDFN_GetSubnetID](@IPV6, @IPV6mask);
    set @SubnetMaskInt = [dbo].[RSDFN_ConvertIPV6BinaryToInt](@IPV6mask);

    if (@SubnetMaskInt = 2147483647)
    begin
        if (@SubnetID is not null)
        begin
            delete from [dbo].[RSDSubnetProperties]
                where SubnetID = @SubnetID
                and BitBucket = 0
            select @SubnetID = SubnetID from [dbo].[RSDSubnetProperties]
                where BitBucket = 1
                and IPV4 = -2147483648
                and IPV4mask = 2147483647
        end
     end
    else
    begin
        if (@SubnetID is not null)
	    begin
	        declare @_SubnetName nvarchar(255);

	        select @_SubnetName = SubnetName
	        from [dbo].[RSDSubnetProperties]
	        where SubnetID = @SubnetID

	        -- Here, we want the one stored in the DB to win, not the one we made up...
	        if (@_SubnetName is not null or LEN(@_SubnetName) > 0)
	            set @SubnetName = @_SubnetName;

	        update [dbo].[RSDSubnetProperties]
	        set SubnetName = @SubnetName
	        where SubnetID = @SubnetID and @SubnetName is not null and SubnetName <> @SubnetName;
	    end
	    else
	    begin
			-- in 3.6 the SubnetName was the name of the first machine that found it...
			set @SubnetName = [dbo].[RSDFN_ConvertIPAddrToDisplayString](@IPV6);

			if ((select count(*) from [dbo].[RSDSubnetProperties] with (TABLOCKX) where IPV6 = @IPV6 and IPV6mask = @IPV6mask) = 0)
			begin
				-- need to make sure a subnet exists for this interface...
				insert into [dbo].[RSDSubnetProperties] with (TABLOCKX) (SubnetName, IPV4, IPV4mask, IPV6, IPV6mask)
				values (@SubnetName, [dbo].[RSDFN_ConvertIPV6BinaryToInt](@IPV6), [dbo].[RSDFN_ConvertIPV6BinaryToInt](@IPV6mask), @IPV6, @IPV6mask)

		        select @SubnetID = SCOPE_IDENTITY();
			end
			else
			begin
				select @SubnetID = SubnetID from [dbo].[RSDSubnetProperties] where IPV6 = @IPV6 and IPV6mask = @IPV6mask
			end
	    end
    end

    set @OutputSubnetID = @SubnetID;

END
GO

ALTER PROCEDURE [dbo].[RSDSP_GetSubnets]
AS
BEGIN
    Select Distinct IPSubnet, IPSubnetMask
    From EPOComputerProperties
    Order By IPSubnet, IPSubnetMask
END
GO

ALTER PROCEDURE [RSDSP_AddOrUpdateSubnets]
(
    @SubnetAddress varbinary(16),
    @SubnetMask varbinary(16)
)
AS
BEGIN
    if (@SubnetAddress is null or DATALENGTH(@SubnetAddress) = 0 or @SubnetMask is null or DATALENGTH(@SubnetMask) = 0)
        return;

    declare @IPV6 binary(16);
    declare @IPV6mask binary(16);

    if (DATALENGTH(@SubnetAddress) = 4)
    begin
        set @IPV6 = 0x00000000000000000000FFFF + @SubnetAddress;
    end
    else
    begin
        set @IPV6 = @SubnetAddress;
    end

    if (DATALENGTH(@SubnetMask) = 4)
    begin
        set @IPV6mask = 0x00000000000000000000FFFF + @SubnetMask;
    end
    else
    begin
        set @IPV6mask = @SubnetMask;
    end

    declare @snid int;
    set @snid = [dbo].[RSDFN_GetSubnetID](@IPV6, @IPV6mask);
    -- If this subnet does not exist, then we need to add it...
    if (@snid is null)
    begin
        exec [dbo].[RSDSP_UpdateSubnets] @IPV6, @IPV6mask, @snid output;
    end

END
GO

ALTER FUNCTION [dbo].[RSDFN_GetManagedSystemsBySubnetIDCount]
(
	@SubnetID		int,
	@ShowAll        bit = 1,
	@HasSensor		bit = 0,
	@InBlacklist	bit = 0
)
RETURNS int
AS
BEGIN
    -- This duplicates the stored proc but gets the count...
    declare @cnt int;

	declare @ipsubnet binary(16);
	declare @ipmask binary(16);

	select @ipsubnet = IPV6, @ipmask = IPV6mask
	from [dbo].[RSDSubnetProperties] where SubnetID = @SubnetID;

    if (@ShowAll = 1)
    begin
        select @cnt = count(*)
        from [dbo].[EPOComputerProperties]
        inner join EPOLeafNode on EPOComputerProperties.ParentID = EPOLeafNode.AutoID
        where EPOComputerProperties.IPSubnet = @ipsubnet
            and EPOComputerProperties.IPSubnetMask = @ipmask;
    end
    else
    begin
        if (@InBlacklist = 1)
        begin
            select @cnt = count(*)
            from [dbo].[EPOComputerProperties]
            inner join EPOLeafNode on EPOComputerProperties.ParentID = EPOLeafNode.AutoID
            where EPOComputerProperties.IPSubnet = @ipsubnet
                and EPOComputerProperties.IPSubnetMask = @ipmask
                and [dbo].[RSDFN_IsInSensorBlacklist](EPOLeafNode.AgentGUID) = @InBlacklist;
        end
        else
        begin
            select @cnt = count(*)
            from [dbo].[EPOComputerProperties]
            inner join EPOLeafNode on EPOComputerProperties.ParentID = EPOLeafNode.AutoID
            where EPOComputerProperties.IPSubnet = @ipsubnet
                and EPOComputerProperties.IPSubnetMask = @ipmask
                and [dbo].[RSDFN_ManagedSystemHasSensor](EPOComputerProperties.ParentID) = @HasSensor
                and [dbo].[RSDFN_IsInSensorBlacklist](EPOLeafNode.AgentGUID) = @InBlacklist;
        end
    end

    return @cnt;
END
GO


ALTER PROCEDURE [dbo].[RSDSP_GetManagedSystemsBySubnetID]
(
	@SubnetID		int,
	@ShowAll        bit = 1,
	@HasSensor		bit = 0,
	@InBlacklist	bit = 0
)
AS
BEGIN

	declare @ipsubnet binary(16);
	declare @ipmask binary(16);

	select @ipsubnet = IPV6, @ipmask = IPV6mask
	from [dbo].[RSDSubnetProperties] where SubnetID = @SubnetID;

    if (@ShowAll = 1)
    begin
        select EPOComputerProperties.ParentID,
            EPOComputerProperties.ComputerName,
            EPOComputerProperties.DomainName,
            EPOComputerProperties.IPHostName,
            EPOComputerProperties.IPAddress,
            EPOComputerProperties.OSType,
            EPOComputerProperties.CPUType,
            EPOComputerProperties.NumOfCPU,
            EPOComputerProperties.TotalDiskSpace,
            EPOComputerProperties.FreeDiskSpace,
            EPOComputerProperties.TotalPhysicalMemory,
            EPOComputerProperties.FreeMemory
        from [dbo].[EPOComputerProperties]
        inner join EPOLeafNode on EPOComputerProperties.ParentID = EPOLeafNode.AutoID
        where EPOComputerProperties.IPSubnet = @ipsubnet
            and EPOComputerProperties.IPSubnetMask = @ipmask;
    end
    else
    begin
        if (@InBlacklist = 1)
        begin
            select EPOComputerProperties.ParentID,
                EPOComputerProperties.ComputerName,
                EPOComputerProperties.DomainName,
                EPOComputerProperties.IPHostName,
                EPOComputerProperties.IPAddress,
                EPOComputerProperties.OSType,
                EPOComputerProperties.CPUType,
                EPOComputerProperties.NumOfCPU,
                EPOComputerProperties.TotalDiskSpace,
                EPOComputerProperties.FreeDiskSpace,
                EPOComputerProperties.TotalPhysicalMemory,
                EPOComputerProperties.FreeMemory
            from [dbo].[EPOComputerProperties]
            inner join EPOLeafNode on EPOComputerProperties.ParentID = EPOLeafNode.AutoID
            where EPOComputerProperties.IPSubnet = @ipsubnet
                and EPOComputerProperties.IPSubnetMask = @ipmask
                and [dbo].[RSDFN_IsInSensorBlacklist](EPOLeafNode.AgentGUID) = @InBlacklist;
        end
        else
        begin
            select EPOComputerProperties.ParentID,
                EPOComputerProperties.ComputerName,
                EPOComputerProperties.DomainName,
                EPOComputerProperties.IPHostName,
                EPOComputerProperties.IPAddress,
                EPOComputerProperties.OSType,
                EPOComputerProperties.CPUType,
                EPOComputerProperties.NumOfCPU,
                EPOComputerProperties.TotalDiskSpace,
                EPOComputerProperties.FreeDiskSpace,
                EPOComputerProperties.TotalPhysicalMemory,
                EPOComputerProperties.FreeMemory
            from [dbo].[EPOComputerProperties]
            inner join EPOLeafNode on EPOComputerProperties.ParentID = EPOLeafNode.AutoID
            where EPOComputerProperties.IPSubnet = @ipsubnet
                and EPOComputerProperties.IPSubnetMask = @ipmask
                and [dbo].[RSDFN_ManagedSystemHasSensor](EPOComputerProperties.ParentID) = @HasSensor
                and [dbo].[RSDFN_IsInSensorBlacklist](EPOLeafNode.AgentGUID) = @InBlacklist;
        end
    end
END
GO


ALTER PROCEDURE [dbo].[RSDSP_UpdateDetectedSubnetsWithKnownManagedSubnets]
AS
BEGIN
    declare @subnet binary(16);
    declare @mask binary(16);

    DECLARE @cur CURSOR;
   	SET @cur = CURSOR FOR Select Distinct IPSubnet, IPSubnetMask
		From EPOComputerProperties
		Order By IPSubnet, IPSubnetMask

   	-- open the cursor
   	OPEN @cur;

   	-- walk all items in the server cursor
   	FETCH NEXT FROM @cur INTO @subnet, @mask;
   	WHILE @@FETCH_STATUS = 0
   	BEGIN
        exec [dbo].[RSDSP_AddOrUpdateSubnets] @subnet, @mask;
   		FETCH NEXT FROM @cur INTO @subnet, @mask;
   	END;

   	-- close and release the server cursor.
   	CLOSE @cur;
   	DEALLOCATE @cur;
END
GO


EXEC EPOCore_DropStoredProc N'RSDSP_UpdateInterfaces';
GO
CREATE PROCEDURE [dbo].[RSDSP_UpdateInterfaces]
(
    @HostID             int,
    @MAC                nvarchar(12),
    @IPV4               int,
    @IPV4mask           int,
    @IPV4subnet         int,
    @IPV6               varbinary (16),
    @IPV6mask           varbinary (16),
    @IPV6subnet         varbinary (16),
    @DetectedTime       datetime,
    @SourceID           int,
    @SourceType         nvarchar(100),
    @ExternalID         nvarchar(1000)
)
AS
BEGIN
    if (@HostID is null or @HostID = 0)
    begin
        -- If this isn't a valid hostid, kinda pointless to continue
        return;
    end

	if (@IPV6 is not null and DATALENGTH(@IPV6) = 16 and @IPV4 is null and [dbo].[RSDFN_IsIPAddressIPv4Compatible] (@IPV6) = 1)
	begin
		set @IPV4 = [dbo].[RSDFN_ConvertIPV6BinaryToInt](@IPV6);
	end

    if (@IPV6 is null or DATALENGTH(@IPV6) = 0)
    begin
        set @IPV6 = [dbo].[RSDFN_ConvertIntToIPV6Binary](@IPV4);
    end

    if (DATALENGTH(@IPV6) = 4)
    begin
        set @IPV6 = 0x00000000000000000000FFFF + @IPV6
    end

	if (@IPV6mask is not null and DATALENGTH(@IPV6mask) = 16 and @IPV4mask is null and [dbo].[RSDFN_IsIPAddressIPv4Compatible] (@IPV6mask) = 1)
	begin
		set @IPV4mask = [dbo].[RSDFN_ConvertIPV6BinaryToInt](@IPV6mask);
	end

    if (@IPV6mask is null or DATALENGTH(@IPV6mask) = 0)
    begin
        set @IPV6mask = [dbo].[RSDFN_ConvertIntToIPV6Binary](@IPV4mask);
    end

    if (DATALENGTH(@IPV6mask) = 4)
    begin
        set @IPV6mask = 0x00000000000000000000FFFF + @IPV6mask;
    end

	if (@IPV6subnet is not null and DATALENGTH(@IPV6subnet) = 16 and @IPV4subnet is null and [dbo].[RSDFN_IsIPAddressIPv4Compatible] (@IPV6subnet) = 1)
	begin
		set @IPV4subnet = [dbo].[RSDFN_ConvertIPV6BinaryToInt](@IPV6subnet);
	end

    if (@IPV6subnet is null or DATALENGTH(@IPV6subnet) = 0)
    begin
        set @IPV6subnet = [dbo].[RSDFN_ConvertIntToIPV6Binary](@IPV4subnet);
    end

    if (DATALENGTH(@IPV6subnet) = 4)
    begin
        set @IPV6subnet = 0x00000000000000000000FFFF + @IPV6subnet;
    end

    if (@MAC is not null)
    begin
        set @MAC = UPPER(@MAC);
    end;

    -- need to get the OUI
    declare @OUI nvarchar(6);
    if ( @MAC is not null )
    begin
        set @OUI = SUBSTRING(@MAC, 0, 7);

		-- bug 431315 - if MAC is from a VPN or other "exclude this" list, then don't use it (set to null)
		declare @vendorIdCount int;
		select @vendorIdCount = count(*) from EPOVirtualMacVendor where VendorID = @OUI;
		if (@vendorIdCount > 0)
		begin
			set @MAC = NULL;
		end
    end
    else
    begin
        set @OUI = 'FFFFFF';
    end

    -- for now, always default to the bitbucket subnet
    declare @SubnetID int;
	declare @Ignored bit;
	select @SubnetID = SubnetID from RSDSubnetProperties where (BitBucket = 1);
	set @Ignored = 0;

	declare @RealSubnetID int;
	declare @RealIgnored bit;
	declare @RealIPV6Subnet binary(16);
	declare @RealIPV6Mask binary(16);

	-- find the subnet info
    if ( (@IPV6subnet is null or @IPV6subnet = 0x00000000000000000000FFFF00000000) and (@IPV6mask is null or @IPV6mask = 0x00000000000000000000FFFFFFFFFFFF))
    begin
		-- lookup in defined subnets based on IPV6 value and the subnet ranges
		select @RealSubnetID = SubnetID, @RealIgnored = Ignored, @RealIPV6Subnet = IPV6, @RealIPV6Mask = IPV6Mask
			from RSDSubnetProperties
			where @IPV6 between IPV6Start and IPV6End
			and (BitBucket = 0);

		-- if we found one, use it instead.
		if (@RealSubnetID IS NOT NULL)
		begin
			set @SubnetID = @RealSubnetID;
			set @Ignored = @RealIgnored;
			set @IPV6subnet = @RealIPV6Subnet;
			set @IPV6mask = @RealIPV6Mask;
		end
    end
    else
    begin
		-- lookup in defined subnets based on IPV6 value and the subnet ranges
		select @RealSubnetID = SubnetID, @RealIgnored = Ignored, @RealIPV6Subnet = IPV6, @RealIPV6Mask = IPV6Mask
			from RSDSubnetProperties
			where @IPV6 between IPV6Start and IPV6End
			and (BitBucket = 0);

		-- if we found one, use it instead.
		if (@RealSubnetID IS NOT NULL)
		begin
			set @SubnetID = @RealSubnetID;
			set @Ignored = @RealIgnored;
			set @IPV6subnet = @RealIPV6Subnet;
			set @IPV6mask = @RealIPV6Mask;
		end
	/*
        -- if the subnet and mask are not null, then we're good to go
        exec RSDSP_UpdateSubnets @IPV6subnet, @IPV6mask, @SubnetID output
	*/
    end

    -- This is specific to RSD, this should be changed if any "SourceType" changes occur
    if (@SourceType like 'rsd.%')
    begin
        exec RSDSP_UpdateSensorToSubnet @SourceID, @SubnetID;
    end

    if (@Ignored = 0)
    begin
		declare @InterfaceID int;
        declare @_MAC nvarchar(12);
        declare @_OUI nvarchar(6);
        declare @_IPV4 int;
        declare @_IPV6 binary(16);

		-- jack of all trades lookup (by priority)
		select @InterfaceID=InterfaceID, @_MAC=MAC, @_OUI=OUI, @_IPV4=IPV4, @_IPV6=IPV6
			from [dbo].[RSDInterfaceProperties]
			where (HostID = @HostID)
			and
			(	-- mac not null and equal
				(MAC is not null and MAC = @MAC) or
				-- mac null or not equal, ipv6 not null and equal
				((MAC is null or MAC <> @MAC) and (IPV6 is not null and IPV6 = @IPV6)) or
				-- mac not equal or null, ipv6 not equal or null, ipv4 not null and equal
				((MAC is null or MAC <> @MAC) and (IPV6 is null or IPV6 <> @IPV6) and (IPV4 is not null and IPV4 = @IPV4))
			)

        -- if the InterfaceID is not null, just update, otherwise add a new one
        if (@InterfaceID is not null)
        begin
            if (@MAC is null or LEN(@MAC) = 0)
                set @MAC = @_MAC;

            if (@OUI is null or LEN(@OUI) = 0)
                set @OUI = @_OUI;

            if (@IPV4 = -2147483648 or @IPV4 is null)
                set @IPV4 = @_IPV4;

            set @IPV6 = ISNULL(@IPV6, @_IPV6);

            update RSDInterfaceProperties
            set MAC = @MAC,
                OUI = @OUI,
                IPV4 = @IPV4,
                IPV6 = @IPV6,
				IPV6Subnet = @IPV6subnet,
				IPV6Mask = @IPV6mask,
                SubnetID = @SubnetID,
                LastDetectedTime = @DetectedTime,
                DetectedSourceType = @SourceType
            where InterfaceID = @InterfaceID;
        end
        else
        begin
			-- need to make sure a subnet exists for this interface...
			insert into RSDInterfaceProperties(HostID, MAC, OUI, IPV4, IPV6, IPV6Subnet, IPV6Mask, SubnetID, LastDetectedTime, DetectedSourceType)
				values (@HostID, @MAC, @OUI, @IPV4, @IPV6, @IPV6subnet, @IPV6mask, @SubnetID, @DetectedTime, @SourceType)
        end
    end
END
GO

-- lookup a subnet record based on the incoming IP address.
EXEC EPOCore_DropStoredProc N'RSDSP_FindSubnetForIPAddress';
GO
CREATE PROCEDURE [dbo].[RSDSP_FindSubnetForIPAddress]
(
    @IPAddress	varbinary(16),
    @OutputSubnetID int OUTPUT
)
AS
BEGIN
	-- default is the bit bucket
	declare @BitBucketID int;
	declare @BitBucketIgnored bit;
    select @BitBucketID = SubnetID, @BitBucketIgnored = Ignored from RSDSubnetProperties where BitBucket = 1;
    if (@BitBucketID is null)
    begin
		set nocount on;
        -- The bit bucket must always exist
        insert into RSDSubnetProperties (SubnetName, IPV4, IPV4mask, IPV6, IPV6mask, BitBucket)
        values (N'Unknown', -2147483648, 2147483647, 0x00000000000000000000FFFF00000000, 0x00000000000000000000FFFFFFFFFFFF, 1);
        select @BitBucketID = SCOPE_IDENTITY();
    end
	else if (@BitBucketIgnored = 1)
	begin
		update RSDSubnetProperties set Ignored = 0 where SubnetID = @BitBucketID
	end

	-- qualify to either v4 or v6.
	if (@IPAddress is not null)
	begin
		declare @ip binary(16);
		set @ip = null;
		if (DATALENGTH(@IPAddress) = 4)
		begin
			set @ip = 0x00000000000000000000FFFF + @IPAddress;
		end
		else if (DATALENGTH(@IPAddress) = 16)
		begin
			set @ip = @IPAddress;
		end
		if (@ip is not null)
		begin
			select @OutputSubnetID = SubnetID
				from RSDSubnetProperties
				where @ip between IPV6Start and IPV6End;
			set @OutputSubnetID = ISNULL(@OutputSubnetID, @BitBucketID);
		end
		else
		begin
			-- bogus lookup. default to bitbucket.
			set @OutputSubnetID = @BitBucketID;
		end
	end
	else
	begin
		-- bogus address. default to bitbucket.
		set @OutputSubnetID = @BitBucketID;
	end;
END
GO



if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_FindIPV6Range]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[RSDSP_FindIPV6Range]
GO


CREATE PROCEDURE [dbo].[RSDSP_FindIPV6Range]
(
    @IPAddress		varbinary(16),
    @Netmask		varbinary(16),
	@StartAddress	binary(16) OUTPUT,
    @EndAddress		binary(16) OUTPUT
)
AS
BEGIN
	declare @ip binary(16);
	declare @mask binary(16);

	if (DATALENGTH(@IPAddress) = 4)
	begin
		set @ip = 0x00000000000000000000FFFF + @IPAddress;
	end
	else
	begin
		set @ip = @IPAddress;
	end
	if (DATALENGTH(@Netmask) = 4)
	begin
		set @mask = 0x00000000000000000000FFFF + @Netmask;
	end
	else
	begin
		set @mask = @Netmask;
	end

    declare @SubnetID int;

	-- All the IPV6 bits
	declare @andhighv4 bigint;
	declare @andlowv4 bigint;
	set @andhighv4 = 0x0000000000000000;
	set @andlowv4 = 0x0000FFFFFFFFFFFF;

	declare @andhighv6 bigint;
	declare @andlowv6 bigint;
	set @andhighv6 = 0xFFFFFFFFFFFFFFFF;
	set @andlowv6 = 0xFFFFFFFFFFFFFFFF;

	declare @andhigh bigint;
	declare @andlow bigint;

	declare @nethigh bigint;
	declare @netlow bigint;
	declare @maskhigh bigint;
	declare @masklow bigint;

	declare @miniph bigint;
	declare @minipl bigint;
	declare @maxiph bigint;
	declare @maxipl bigint;

	declare @minip binary(16);
	declare @maxip binary(16);

	if ([dbo].[RSDFN_IsIPAddressIPv4Compatible](@ip) = 1 and [dbo].[RSDFN_IsIPAddressIPv4Compatible](@mask) = 1)
	begin
		set @andhigh = @andhighv4;
		set @andlow = @andlowv4;
	end
	else
	begin
		set @andhigh = @andhighv6;
		set @andlow = @andlowv6;
	end

	set @nethigh = convert(bigint, substring(@ip, 1, 8));
	set @netlow = convert(bigint, substring(@ip, 9, 8));
	set @maskhigh = convert(bigint, substring(@mask, 1, 8));
	set @masklow = convert(bigint, substring(@mask, 9, 8));

	set @miniph = @nethigh & @maskhigh;
	set @minipl = @netlow & @masklow;
	set @maxiph = @miniph | ( (~@maskhigh) & @andhigh );
	set @maxipl = @minipl | ( (~@masklow) & @andlow );

	set @StartAddress = convert(binary(8), @miniph) + convert(binary(8), @minipl);
	set @EndAddress = convert(binary(8), @maxiph) + convert(binary(8), @maxipl);

END
GO


IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_ConvertIPV4BinaryToIPV6Binary]') )
DROP FUNCTION [dbo].[RSDFN_ConvertIPV4BinaryToIPV6Binary]
GO

CREATE FUNCTION [dbo].[RSDFN_ConvertIPV4BinaryToIPV6Binary]
(
    @IPV4	binary(4)
)
RETURNS BINARY(16)
AS
BEGIN
	if (@IPV4 is null) RETURN NULL;

	RETURN 0x00000000000000000000FFFF + @IPV4;
END
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_ConvertIPStringToIPV4Binary]') )
DROP FUNCTION [dbo].[RSDFN_ConvertIPStringToIPV4Binary]
GO


CREATE FUNCTION [dbo].[RSDFN_ConvertIPStringToIPV4Binary]
(
    @ipstr nvarchar(15)
)
RETURNS BINARY(4)
AS
BEGIN
    if (@ipstr is null) RETURN NULL;

	-- Declare the return variable here
	DECLARE @ipv4 bigint;
	SET @ipv4 = 0;

	-- cleanup string for starters
	SET @ipstr = LTrim(RTrim(@ipstr));
	IF (LEN(@ipstr) = 0)
		RETURN NULL;

	-- parse string (weak parse, but efficient)
	DECLARE @nPos int;
	SET @nPos = CHARINDEX(N'.', @ipstr);
	if (@nPos > 0)
	BEGIN
		DECLARE @strA nvarchar(4);
		SET @strA = SUBSTRING(@ipstr, 1, @nPos-1);
		SET @ipstr = SUBSTRING(@ipstr, @nPos+1, LEN(@ipstr) - @nPos);
		SET @nPos = CHARINDEX(N'.', @ipstr);
		if (@nPos > 0)
		BEGIN
			DECLARE @strB nvarchar(4);
			SET @strB = SUBSTRING(@ipstr, 1, @nPos-1);
			SET @ipstr = SUBSTRING(@ipstr, @nPos+1, LEN(@ipstr) - @nPos);
			SET @nPos = CHARINDEX(N'.', @ipstr);
			if (@nPos > 0)
			BEGIN
				DECLARE @strC nvarchar(4);
				SET @strC = SUBSTRING(@ipstr, 1, @nPos-1);
				SET @ipstr = SUBSTRING(@ipstr, @nPos+1, LEN(@ipstr) - @nPos);
				SET @ipv4 = CONVERT(bigint, @strA) * POWER(2,24) +
							CONVERT(bigint, @strB) * POWER(2,16) +
							CONVERT(bigint, @strC) * POWER(2,8) +
							CONVERT(bigint, @ipstr);
			END
		END
	END

	RETURN CONVERT(binary(4), @ipv4);
END
GO


ALTER PROCEDURE [dbo].[RSDSP_SubnetOverlap]
(
    @IPV6           varbinary(16),
	@IPV6mask		varbinary(16),
    @OutputSubnetID int OUTPUT
)
AS
BEGIN

	declare @NetworkAddr binary(16);
	declare @NetworkMask binary(16);

	set @OutputSubnetID = NULL;

	if (DATALENGTH(@IPV6) = 4)
	begin
		set @NetworkAddr = 0x00000000000000000000FFFF + @IPV6;
	end
	else
	begin
		set @NetworkAddr = @IPV6;
	end

	if (DATALENGTH(@IPV6mask) = 4)
	begin
		set @NetworkMask = 0x00000000000000000000FFFF + @IPV6mask;
	end
	else
	begin
		set @NetworkMask = @IPV6mask;
	end

	declare @minip binary(16);
	declare @maxip binary(16);

	exec [dbo].[RSDSP_FindIPV6Range] @NetworkAddr, @NetworkMask, @minip output, @maxip output;

    declare @SubnetID int;
	declare @Subnet binary(16);
	declare @SubnetMask binary(16);
	declare @min binary(16);
	declare @max binary(16);


	DECLARE @cur CURSOR;
	SET @cur = CURSOR FOR
		SELECT SubnetID, IPV6 as Subnet, IPV6mask as SubnetMask
		FROM RSDSubnetProperties where BitBucket = 0

	-- open the cursor
	OPEN @cur;

	-- walk all items in the server cursor
	FETCH NEXT FROM @cur INTO @SubnetID, @Subnet, @SubnetMask;
	WHILE @@FETCH_STATUS = 0
	BEGIN

		exec [dbo].[RSDSP_FindIPV6Range] @Subnet, @SubnetMask, @min output, @max output;

		-- Check to see if the supplied subnet is already contained within an existing subnet
		if ((@minip >= @min and @minip <= @max) or (@maxip >= @min and @maxip <= @max))
		begin
			set @OutputSubnetID = @SubnetID;
			break;
		end

		-- Now, check to see if the existing subnet is contained within the supplied subnet
		if ((@min >= @minip and @min <= @maxip) or (@max >= @minip and @max <= @maxip))
		begin
			set @OutputSubnetID = @SubnetID;
			break;
		end

		FETCH NEXT FROM @cur INTO @SubnetID, @Subnet, @SubnetMask;
	END;

	-- close and release the server cursor.
	CLOSE @cur;
	DEALLOCATE @cur;

END
GO

ALTER PROCEDURE [dbo].[RSDSP_SetUnknownSubnetName]
(
    @Name       nvarchar(255)
)
AS
BEGIN
	SET NOCOUNT ON;

    update [dbo].[RSDSubnetProperties] set SubnetName = @Name
    where IPV6 = 0x00000000000000000000FFFF00000000
        and IPV6mask = 0x00000000000000000000FFFFFFFFFFFF
        and BitBucket = 1
END
GO


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_GetSubnetToRogueCount]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_GetSubnetToRogueCount]
GO

CREATE PROCEDURE [dbo].[RSDSP_GetSubnetToRogueCount]
AS
BEGIN
    select top 25 count (RSDDetectedSystemProperties.HostID) as 'count',
        RSDSubnetProperties.SubnetID, RSDSubnetProperties.SubnetName,
        RSDSubnetProperties.IPV6, RSDSubnetProperties.IPV6mask, RSDSubnetProperties.BitBucket
    from [dbo].[RSDSubnetProperties]
    inner join [dbo].[RSDInterfaceProperties] on RSDInterfaceProperties.SubnetID = RSDSubnetProperties.SubnetID
    inner join [dbo].[RSDDetectedSystemProperties] on RSDDetectedSystemProperties.HostID = RSDInterfaceProperties.HostID
    where RSDSubnetProperties.Ignored = 0 and
        [dbo].[RSDFN_IsRogueDetectedSystem](RSDDetectedSystemProperties.HostID, GETUTCDATE()) = 1
    group by RSDSubnetProperties.IPV6, RSDSubnetProperties.SubnetName, RSDSubnetProperties.SubnetID, RSDSubnetProperties.IPV6mask, RSDSubnetProperties.BitBucket
    order by count desc;
END
GO




-- No longer need or use this dude...
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TR_RSDSubnetProperties_EPOComputerProperties_OnInsert]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TR_RSDSubnetProperties_EPOComputerProperties_OnInsert]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TR_RSDDetected_EPOComputerProperties_OnUpdate]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TR_RSDDetected_EPOComputerProperties_OnUpdate]
GO

CREATE TRIGGER [TR_RSDDetected_EPOComputerProperties_OnUpdate] ON [dbo].[EPOComputerProperties]
AFTER UPDATE
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @count int;
    SELECT @count = COUNT(*) FROM inserted;
    if (@count = 0)
        return;

    if (update(IPHostName) or update(OSType) or update(OSVersion) or update(DomainName) or
        update(ComputerName) or update(UserName) or update(IPV6) or update(IPSubnet) or update(IPSubnetMask) or
        update(NetAddress))
    begin

        -- Select the "detected system" properties
		declare @snid int;
        declare @LeafNodeID int;
        declare @AgentGUID uniqueidentifier;
		declare @DnsName			nvarchar(255);
		declare @OSPlatformStr		nvarchar(100);
		declare @OSVersion          nvarchar(128);
		declare @Domain             nvarchar(255);
		declare @ComputerName       nvarchar(255);
		declare @Users              nvarchar(128);
		declare @IPV6               binary(16);
		declare @IPV6mask           binary(16);
		declare @IPV6subnet         binary(16);
		declare @MACStr             nvarchar(100);

        if (@count = 1)
        begin
            select @LeafNodeID = ParentID, @DnsName = IPHostName, @OSPlatformStr = OSType, @OSVersion = OSVersion,
				@Domain = DomainName, @ComputerName = ComputerName, @Users = UserName,
				@IPV6 = IPV6, @IPV6mask = IPSubnetMask, @IPV6subnet = IPSubnet, @MACStr = NetAddress from inserted;
            select @AgentGUID = AgentGUID from EPOLeafNode where AutoID = @LeafNodeID;

            if (@LeafNodeID is not null and @AgentGUID is not null and @IPV6 is not null)
            begin
                exec [dbo].[RSDSP_CreateAgentUpdateDetection] @LeafNodeID, @AgentGUID, @DnsName, @OSPlatformStr, @OSVersion,
					@Domain, @ComputerName, @Users, @IPV6, @IPV6mask, @IPV6subnet, @MACStr;
            end
        end
        else
        begin
            declare @cur cursor;
            set @cur = cursor for select ParentID, IPHostName, OSType, OSVersion, DomainName, ComputerName, UserName,
				IPV6, IPSubnetMask, IPSubnet, NetAddress from inserted;
            open @cur;

            fetch next from @cur into @LeafNodeID, @DnsName, @OSPlatformStr, @OSVersion, @Domain, @ComputerName, @Users,
				@IPV6, @IPV6mask, @IPV6subnet, @MACStr;
            while (@@FETCH_STATUS = 0)
            begin
                select @AgentGUID = AgentGUID from EPOLeafNode where AutoID = @LeafNodeID;
	            if (@LeafNodeID is not null and @AgentGUID is not null and @IPV6 is not null)
                begin
					exec [dbo].[RSDSP_CreateAgentUpdateDetection] @LeafNodeID, @AgentGUID, @DnsName, @OSPlatformStr, @OSVersion,
						@Domain, @ComputerName, @Users, @IPV6, @IPV6mask, @IPV6subnet, @MACStr;
                end
				fetch next from @cur into @LeafNodeID, @DnsName, @OSPlatformStr, @OSVersion, @Domain, @ComputerName, @Users,
					@IPV6, @IPV6mask, @IPV6subnet, @MACStr;
            end
            close @cur;
            deallocate @cur;

        end
    end


END
GO


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_BlacklistSystemByAgentGUID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_BlacklistSystemByAgentGUID]
GO


CREATE PROCEDURE [dbo].[RSDSP_BlacklistSystemByAgentGUID]
(
    @AgentGUID          uniqueidentifier,
    @AddSystem          bit,
    @HasSensor          bit OUTPUT,
    @ComputerName       nvarchar(255) OUTPUT,
    @OutputAgentGUID    uniqueidentifier OUTPUT,
    @DidWork            bit OUTPUT
)
AS
BEGIN
    exec [dbo].[RSDSP_ManagedSystemHasSensorByAgentGUID] @AgentGUID, @HasSensor OUTPUT, @ComputerName OUTPUT;
    set @DidWork = 0;

    if (@AgentGUID is not null)
    begin
		select @OutputAgentGUID = AgentGUID from RSDSensorBlacklistTarget where AgentGUID = @AgentGUID;
        if (@AddSystem = 0)
        begin
			if (@OutputAgentGUID is not null)
			begin
				exec RSDSP_RemoveFromSensorBlacklist @AgentGUID;
				set @DidWork = 1;
			end
        end
        else
        begin
            if (@HasSensor = 0 and @OutputAgentGUID is null)
            begin
                exec RSDSP_AddToSensorBlacklist null, @AgentGUID, @OutputAgentGUID OUTPUT;
                set @DidWork = 1;
            end
        end
    end
END
GO


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_BlacklistSystemByParentID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_BlacklistSystemByParentID]
GO

CREATE PROCEDURE [dbo].[RSDSP_BlacklistSystemByParentID]
(
    @ParentID           int,
    @AddSystem          bit,
    @HasSensor          bit OUTPUT,
    @ComputerName       nvarchar(255) OUTPUT,
    @OutputAgentGUID    uniqueidentifier OUTPUT,
    @DidWork            bit OUTPUT
)
AS
BEGIN
    declare @AgentGUID uniqueidentifier;

    select @AgentGUID = [dbo].[EPOLeafNode].[AgentGUID]
        from [dbo].[EPOLeafNode]
        where [dbo].[EPOLeafNode].[AutoID] = @ParentID;

    exec RSDSP_BlacklistSystemByAgentGUID @AgentGUID, @AddSystem, @HasSensor OUTPUT, @ComputerName OUTPUT, @OutputAgentGUID OUTPUT, @DidWork OUTPUT;

    if (@ComputerName is null)
    begin
        select @ComputerName = NodeName
            from [dbo].[EPOLeafNode]
            where [dbo].[EPOLeafNode].[AutoID] = @ParentID;
    end
END
GO

-- BZ440046 delete the existing 32-bit subnets
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSubnetProperties]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
begin
    DELETE FROM [dbo].[RSDSubnetProperties]
        WHERE [IPV4mask] = 2147483647
        AND [IPV4] <> -2147483648
        AND [BitBucket] = 0
end
GO


--if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TR_RSDDetectedSystemProperties_UpdateExceptions]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
--drop trigger [dbo].[TR_RSDDetectedSystemProperties_UpdateExceptions]
--GO

--CREATE TRIGGER [dbo].[TR_RSDDetectedSystemProperties_UpdateExceptions]
--   ON  [dbo].[RSDDetectedSystemProperties]
--   FOR UPDATE
--AS
--BEGIN
--	-- SET NOCOUNT ON added to prevent extra result sets from
--	-- interfering with SELECT statements.
--	SET NOCOUNT ON;
--	IF (UPDATE(Exception))
--	BEGIN
--		if ((select Exception from inserted) != (select Exception from deleted))
--		begin
--			UPDATE RSDGlobalPolicySettings SET UpdateExceptions = 1 where ID = 1
--		end
--	END
--END
--GO

--if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TR_RSDScanBlacklist_Update]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
--drop trigger [dbo].[TR_RSDScanBlacklist_Update]
--GO

--CREATE TRIGGER [dbo].[TR_RSDScanBlacklist_Update]
--   ON  [dbo].[RSDScanBlacklist]
--   AFTER INSERT, UPDATE
--AS
--BEGIN
--	-- SET NOCOUNT ON added to prevent extra result sets from
--	-- interfering with SELECT statements.
--	SET NOCOUNT ON;
--    UPDATE RSDGlobalPolicySettings SET UpdateScan = 1 where ID = 1
--END
--GO

--if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TR_RSDReportBlacklist_Update]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
--drop trigger [dbo].[TR_RSDReportBlacklist_Update]
--GO

--CREATE TRIGGER [dbo].[TR_RSDReportBlacklist_Update]
--   ON  [dbo].[RSDReportBlacklist]
--   AFTER INSERT, UPDATE
--AS
--BEGIN
--	-- SET NOCOUNT ON added to prevent extra result sets from
--	-- interfering with SELECT statements.
--	SET NOCOUNT ON;
--    UPDATE RSDGlobalPolicySettings SET UpdateReport = 1 where ID = 1
--END
--GO


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_ForceNewPolicyNextUpdate]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_ForceNewPolicyNextUpdate]
GO

-- Called when the SensorSettings are saved to make sure the Exception list is sent down to the
-- sensors on subsequent policy updates
CREATE PROCEDURE [dbo].[RSDSP_ForceNewPolicyNextUpdate]
AS
BEGIN
	SET NOCOUNT ON;

	update PSV
	set PSV.SettingValue = PSV.SettingValue
	from EPOPolicySettingValues PSV inner join EPOPolicySettings PS
	on (PSV.PolicySettingsID = PS.PolicySettingsID)
	inner join EPOPolicyTypes PT on (PS.TypeID = PT.TypeID)
	where PT.FeatureTextID = N'RSDSensorSettings'
	and PT.CategoryTextID = N'General'
	and PT.TypeTextID = N'General'
	and PSV.SettingName = 'EnableSensor'


END
GO

if exists (select * from .[dbo].sysobjects where id = object_id(N'.[dbo].[RSDDetectionSources]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[RSDDetectionSources]
GO

CREATE VIEW [dbo].[RSDDetectionSources]
AS
SELECT dbo.RSDDetectedSource.AutoID,
       dbo.RSDDetectedSource.HostID,
       dbo.RSDDetectedSource.SourceID,
       dbo.RSDDetectedSource.SourceType,
       dbo.RSDDetectedSource.ExternalID,
       dbo.RSDDetectedSource.FirstDetectedTime,
       dbo.RSDDetectedSource.LastDetectedTime,
       dbo.RSDDetectedSource.FirstRecordedTime,
       dbo.RSDDetectedSource.LastRecordedTime,
       dbo.RSDDetectedSourceType.SourceName
FROM   dbo.RSDDetectedSource
INNER JOIN dbo.RSDDetectedSourceType ON dbo.RSDDetectedSource.SourceType = dbo.RSDDetectedSourceType.SourceType
GO



-----------------------------------------------------------------------------------------
-- BEGIN RSD INDEX MODIFICATIONS

-- create indexes based new database fields.
IF EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID('[RSDSubnetProperties]') AND name = N'IX_RSDSubnetProperties_IPV6StartIPV6End')
	DROP INDEX [dbo].[RSDSubnetProperties].[IX_RSDSubnetProperties_IPV6StartIPV6End];
GO
CREATE INDEX [IX_RSDSubnetProperties_IPV6StartIPV6End] ON [dbo].[RSDSubnetProperties]
(
	[IPV6Start],
	[IPV6End]
) ON [PRIMARY];
GO

IF EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID('[RSDSubnetProperties]') AND name = N'IX_RSDSubnetProperties_IPV6Start')
	DROP INDEX [dbo].[RSDSubnetProperties].[IX_RSDSubnetProperties_IPV6Start];
GO
CREATE INDEX [IX_RSDSubnetProperties_IPV6Start] ON [dbo].[RSDSubnetProperties]
(
	[IPV6Start]
) ON [PRIMARY];
GO

IF EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID('[RSDSubnetProperties]') AND name = N'IX_RSDSubnetProperties_IPV6End')
	DROP INDEX [dbo].[RSDSubnetProperties].[IX_RSDSubnetProperties_IPV6End];
GO
CREATE INDEX [IX_RSDSubnetProperties_IPV6End] ON [dbo].[RSDSubnetProperties]
(
	[IPV6End]
) ON [PRIMARY];
GO

-- BEGIN RSD INDEX MODIFICATIONS
-----------------------------------------------------------------------------------------


-----------------------------------------------------------------------------------------
-- BEGIN RSD DATA MODIFICATIONS

-- alter table to fill in the ranges
SET NOCOUNT ON;
UPDATE RSP
	SET IPV6Start = [dbo].[RSDFN_IPV6SubnetAddrStart](RSP.IPV6, RSP.IPV6Mask),
		IPV6End = [dbo].[RSDFN_IPV6SubnetAddrEnd](RSP.IPV6, RSP.IPV6Mask)
	FROM RSDSubnetProperties RSP
	WHERE (RSP.IPV6 is not null and RSP.IPV6mask is not null);
GO

-- reallign subnet identification
SET NOCOUNT ON;
UPDATE RIP
	SET RIP.SubnetID = SN.SubnetID
	FROM RSDInterfaceProperties RIP LEFT JOIN RSDSubnetProperties SN
	ON (RIP.SubnetID = SN.SubnetID)
	WHERE (SN.SubnetID IS NULL)
	AND (RIP.IPV6 BETWEEN SN.IPV6Start AND SN.IPV6End)
	AND (SN.BitBucket = 0);
GO

-- update current values from existing subnets table
SET NOCOUNT ON;
UPDATE RIP
	SET	RIP.IPV6Subnet = SN.IPV6, RIP.IPV6Mask = SN.IPV6Mask
	FROM RSDInterfaceProperties RIP INNER JOIN RSDSubnetProperties SN
	ON (RIP.SubnetID = SN.SubnetID)
	WHERE (SN.BitBucket = 0);
GO

-- END RSD DATA MODIFICATIONS
----------------------------------------------------------------------------------------- end

-- This touches all existing SensorDeployment tasks so TheTimestamp is updated and
-- the sensor will be updated on the next asci
-- removed for bug 482747
--update EPOTaskSettings set EPOTaskSettings.Value = EPOTaskSettings.Value
--  from EPOTaskSettings inner join EPOTask
--  on EPOTask.AutoID = EPOTaskSettings.ParentID
--  where EPOTask.ProductCode = 'SNOWCAP_2000';
--GO


