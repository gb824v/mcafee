-------------------------------------------------------------------------------
-- Uninstall script for RSD tables in the ePO4 database.  This script is
-- called when the RSD extension is unloaded/deinstalled from a running ePO4
-- system.
--
-- Purpose: delete all database artifacts related to the RSD extension.
-------------------------------------------------------------------------------

-------------------------------------------------------------------------------
-- RSD 4.5.0 Uninstall
-------------------------------------------------------------------------------
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_IsIPAddressIPv4Compatible]') )
DROP FUNCTION [dbo].[RSDFN_IsIPAddressIPv4Compatible]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_ConvertIPAddrToDisplayString]') )
DROP FUNCTION [dbo].[RSDFN_ConvertIPAddrToDisplayString]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_CreateCanonicalName]') )
DROP FUNCTION [dbo].[RSDFN_CreateCanonicalName]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_GetEpoServerNameForDetectedSystem]') )
DROP FUNCTION [dbo].[RSDFN_GetEpoServerNameForDetectedSystem]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_GetOUIFromMAC]') )
DROP FUNCTION [dbo].[RSDFN_GetOUIFromMAC]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_UpdateAgentInfo]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_UpdateAgentInfo]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDConfigurationAlternateEpoServers]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[RSDConfigurationAlternateEpoServers]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDDetectedSystemAgentProperties]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[RSDDetectedSystemAgentProperties]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[OUIUpdatingSettings]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[OUIUpdatingSettings]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDExceptionCategories]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[RSDExceptionCategories]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDSP_GetNewDetectedSystemEvents]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[RSDSP_GetNewDetectedSystemEvents]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_ConvertIPV4BinaryToInt]') )
DROP FUNCTION [dbo].[RSDFN_ConvertIPV4BinaryToInt]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_ConvertIPV6BinaryToInt]') )
DROP FUNCTION [dbo].[RSDFN_ConvertIPV6BinaryToInt]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_ConvertIPV4BinaryToIPV6Binary]') )
DROP FUNCTION [dbo].[RSDFN_ConvertIPV4BinaryToIPV6Binary]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_ConvertIPStringToIPV4Binary]') )
DROP FUNCTION [dbo].[RSDFN_ConvertIPStringToIPV4Binary]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDSP_GetNewDetectedSystemEvents]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[RSDSP_GetNewDetectedSystemEvents]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDSP_FindIPV6Range]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[RSDSP_FindIPV6Range]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_GetExceptionCategoryName]') )
DROP FUNCTION [dbo].[RSDFN_GetExceptionCategoryName]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDSP_AddExceptionCategory]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[RSDSP_AddExceptionCategory]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TR_RSDDetected_EPOComputerProperties_OnUpdate]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TR_RSDDetected_EPOComputerProperties_OnUpdate]
GO


-------------------------------------------------------------------------------
-- RSD 2.0.1 Uninstall
-------------------------------------------------------------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDUnmanagedSystemsLink]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[RSDUnmanagedSystemsLink]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_AddDetectedSystemToEPOSystemTree]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_AddDetectedSystemToEPOSystemTree]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_UpdateDetectedSystemPropertiesByHostID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_UpdateDetectedSystemPropertiesByHostID]
GO

if exists (select * from .[dbo].sysobjects where id = object_id(N'.[dbo].[RSDManagedSystemsForSubnet]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view .[dbo].[RSDManagedSystemsForSubnet]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TR_RSDCleanup_RSDDetectedSystemProperties_Delete]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TR_RSDCleanup_RSDDetectedSystemProperties_Delete]
GO



-------------------------------------------------------------------------------
-- Drop the RSD Stored Procedures
-------------------------------------------------------------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_MatchDetectedSystems]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_MatchDetectedSystems]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_UpdateDetectedSystems]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_UpdateDetectedSystems]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_UpdateInterfaces]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_UpdateInterfaces]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_UpdateSubnets]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_UpdateSubnets]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_MatchManagedSystems]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_MatchManagedSystems]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_RemoveFromSensorBlacklist]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_RemoveFromSensorBlacklist]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_AddToSensorBlacklist]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_AddToSensorBlacklist]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_BlacklistSystemByParentID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_BlacklistSystemByParentID]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_BlacklistSystemByAgentGUID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_BlacklistSystemByAgentGUID]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_ManagedSystemHasSensorByAgentGUID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_ManagedSystemHasSensorByAgentGUID]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_FindSubnetForIPAddress]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_FindSubnetForIPAddress]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_SubnetOverlap]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_SubnetOverlap]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_UpdateSensorToSubnet]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_UpdateSensorToSubnet]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_AddOrUpdateSubnets]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_AddOrUpdateSubnets]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_ExecuteMerge]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_ExecuteMerge]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_GetDetectedSystemMergeCandidates]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_GetDetectedSystemMergeCandidates]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_UpdateDetectedSubnetsWithKnownManagedSubnets]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_UpdateDetectedSubnetsWithKnownManagedSubnets]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_UpdateOUIs]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_UpdateOUIs]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_SetUnknownSubnetName]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_SetUnknownSubnetName]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_GetManagedSystemsBySubnetID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_GetManagedSystemsBySubnetID]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_GetSubnetToRogueCount]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_GetSubnetToRogueCount]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_UpdateVMVendorOUIs]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_UpdateVMVendorOUIs]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_DetectedSystemTransaction_DetectedSystemByHostID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_DetectedSystemTransaction_DetectedSystemByHostID]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_DetectedSystemTransaction_InterfacesByHostID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_DetectedSystemTransaction_InterfacesByHostID]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_DetectedSystemTransaction_DetectedSourceByHostID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_DetectedSystemTransaction_DetectedSourceByHostID]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_DetectedSourceTransaction_DetectedSourceBySourceAndHostID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_DetectedSourceTransaction_DetectedSourceBySourceAndHostID]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_CreateAgentUpdateDetection]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_CreateAgentUpdateDetection]
GO


-- TODO: possibly remove if we get this from ePO patch (as EPOSP_GetSubnets)
-- or the need for it is obviated by a Managed Systems import
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_GetSubnets]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_GetSubnets]
GO




-------------------------------------------------------------------------------
-- Drop the RSD Functions
-------------------------------------------------------------------------------

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_ConvertIntToIPString]') )
DROP FUNCTION [dbo].[RSDFN_ConvertIntToIPString]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_ConvertBigIntToIPString]') )
DROP FUNCTION [dbo].[RSDFN_ConvertBigIntToIPString]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_ConvertIPStringToInt]') )
DROP FUNCTION [dbo].[RSDFN_ConvertIPStringToInt]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_ConvertIPStringToBigInt]') )
DROP FUNCTION [dbo].[RSDFN_ConvertIPStringToBigInt]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_ConvertMACToDisplayString]') )
DROP FUNCTION [dbo].[RSDFN_ConvertMACToDisplayString]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_CreateFriendlyName]') )
DROP FUNCTION [dbo].[RSDFN_CreateFriendlyName]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_ConvertIntToIPV4Binary]') )
DROP FUNCTION [dbo].[RSDFN_ConvertIntToIPV4Binary]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_ConvertIntToIPV6Binary]') )
DROP FUNCTION [dbo].[RSDFN_ConvertIntToIPV6Binary]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_IsLeafNodeInSensorBlacklist]') )
DROP FUNCTION [dbo].[RSDFN_IsLeafNodeInSensorBlacklist]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_IsInSensorBlacklist]') )
DROP FUNCTION [dbo].[RSDFN_IsInSensorBlacklist]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_ManagedSystemHasSensor]') )
DROP FUNCTION [dbo].[RSDFN_ManagedSystemHasSensor]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_ManagedSystemHasSensorByAgentGUID]') )
DROP FUNCTION [dbo].[RSDFN_ManagedSystemHasSensorByAgentGUID]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_GetManagedSystemsBySubnetIDCount]') )
DROP FUNCTION [dbo].[RSDFN_GetManagedSystemsBySubnetIDCount]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_IsInRSDConfigurationIPRange]') )
DROP FUNCTION [dbo].[RSDFN_IsInRSDConfigurationIPRange]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_IsInIPRange]') )
DROP FUNCTION [dbo].[RSDFN_IsInIPRange]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_GetSubnetID]') )
DROP FUNCTION [dbo].[RSDFN_GetSubnetID]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_IsManagedDetectedSystem]') )
DROP FUNCTION [dbo].[RSDFN_IsManagedDetectedSystem]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_IsRogueDetectedSystem]') )
DROP FUNCTION [dbo].[RSDFN_IsRogueDetectedSystem]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_IsInactiveDetectedSystem]') )
DROP FUNCTION [dbo].[RSDFN_IsInactiveDetectedSystem]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_GetRogueState]') )
DROP FUNCTION [dbo].[RSDFN_GetRogueState]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_CountSensorsForSubnet]') )
DROP FUNCTION [dbo].[RSDFN_CountSensorsForSubnet]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_IsSubnetCovered]') )
DROP FUNCTION [dbo].[RSDFN_IsSubnetCovered]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_SubnetContainsRogueSystems]') )
DROP FUNCTION [dbo].[RSDFN_SubnetContainsRogueSystems]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_GetSensorStatus]') )
DROP FUNCTION [dbo].[RSDFN_GetSensorStatus]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_GetOrganizationName]') )
DROP FUNCTION [dbo].[RSDFN_GetOrganizationName]
GO



-------------------------------------------------------------------------------
-- Drop the RSD Triggers
-------------------------------------------------------------------------------

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TR_RSDCleanup_EPOLeafNode_Delete]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TR_RSDCleanup_EPOLeafNode_Delete]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TR_RSDSensorBlacklistTarget_Delete]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TR_RSDSensorBlacklistTarget_Delete]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TR_RSDSubnetProperties_OnUpdate]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TR_RSDSubnetProperties_OnUpdate]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TR_RSDSubnetProperties_OnDelete]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TR_RSDSubnetProperties_OnDelete]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TR_RSDDetectedSystemProperties_OnInsert]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TR_RSDDetectedSystemProperties_OnInsert]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TR_RSDInterfaceProperties_OnInsert]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TR_RSDInterfaceProperties_OnInsert]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TR_RSDSubnetProperties_EPOComputerProperties_OnInsert]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TR_RSDSubnetProperties_EPOComputerProperties_OnInsert]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TR_RSDDetected_EPOLeafNode_OnUpdate]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[TR_RSDDetected_EPOLeafNode_OnUpdate]
GO


-------------------------------------------------------------------------------
-- Drop the RSD Foreign Keys
-------------------------------------------------------------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_RSDInterfaceProperties_RSDDetectedSystemProperties]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[RSDInterfaceProperties] DROP CONSTRAINT FK_RSDInterfaceProperties_RSDDetectedSystemProperties
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_RSDDetectedSource_RSDDetectedSystemProperties]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[RSDDetectedSource] DROP CONSTRAINT FK_RSDDetectedSource_RSDDetectedSystemProperties
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_RSDSensorToSubnet_RSDSubnetProperties]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[RSDSensorToSubnet] DROP CONSTRAINT FK_RSDSensorToSubnet_RSDSubnetProperties
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_RSDSensorToSubnet_RSDSensorProperties]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[RSDSensorToSubnet] DROP CONSTRAINT FK_RSDSensorToSubnet_RSDSensorProperties
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_RSDConfigurationIPRanges_RSDConfiguration]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[RSDConfigurationIPRanges] DROP CONSTRAINT FK_RSDConfigurationIPRanges_RSDConfiguration
GO



-------------------------------------------------------------------------------
-- Drop the RSD tables/views
-------------------------------------------------------------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDDetectedSourceType]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[RSDDetectedSourceType]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDDetectedSystemProperties]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[RSDDetectedSystemProperties]
GO

if exists (select * from .[dbo].sysobjects where id = object_id(N'.[dbo].[RSDDetectedSystems]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view .[dbo].[RSDDetectedSystems]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDDetectedSource]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[RSDDetectedSource]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDInterfaceProperties]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[RSDInterfaceProperties]
GO

if exists (select * from .[dbo].sysobjects where id = object_id(N'.[dbo].[RSDInterfaces]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view .[dbo].[RSDInterfaces]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSubnetProperties]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[RSDSubnetProperties]
GO

if exists (select * from .[dbo].sysobjects where id = object_id(N'.[dbo].[RSDSubnets]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view .[dbo].[RSDSubnets]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSensorToSubnet]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[RSDSensorToSubnet]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSensorProperties]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[RSDSensorProperties]
GO

if exists (select * from .[dbo].sysobjects where id = object_id(N'.[dbo].[RSDSensors]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view .[dbo].[RSDSensors]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDConfiguration]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[RSDConfiguration]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDConfigurationIPRanges]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[RSDConfigurationIPRanges]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSensorBlacklistTarget]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[RSDSensorBlacklistTarget]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDVMVendorOUIs]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[RSDVMVendorOUIs]
GO

if exists (select * from .[dbo].sysobjects where id = object_id(N'.[dbo].[RSDSensorBlacklist]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view .[dbo].[RSDSensorBlacklist]
GO



