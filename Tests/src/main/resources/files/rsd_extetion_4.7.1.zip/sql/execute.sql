-- This is where any setup, migration or other SQL should go that is only run on install

-- This creates all the existing "known" ePO Subnets at install time.  They are kept in sync via Triggers post install
exec [dbo].[RSDSP_UpdateDetectedSubnetsWithKnownManagedSubnets];
GO


-- Add all known VM Vendor OUIs to the VMVendorOUIs table
-- VMWare
exec [dbo].[RSDSP_UpdateVMVendorOUIs] '000569';
exec [dbo].[RSDSP_UpdateVMVendorOUIs] '000C29';
exec [dbo].[RSDSP_UpdateVMVendorOUIs] '001C14';
exec [dbo].[RSDSP_UpdateVMVendorOUIs] '005056';
-- Parallels
exec [dbo].[RSDSP_UpdateVMVendorOUIs] '001C42';

-- This is where any setup, migration or other SQL should go that is only run on install

