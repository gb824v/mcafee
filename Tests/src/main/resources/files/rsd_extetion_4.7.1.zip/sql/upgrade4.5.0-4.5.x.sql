-- This is the sustaining script of 4.5.0-4.5.x upgrade issues
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_GetSubnetToRogueCount]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_GetSubnetToRogueCount]
GO

CREATE PROCEDURE [dbo].[RSDSP_GetSubnetToRogueCount]
AS
BEGIN
    select top 25 count(dsp.HostID) as 'count', sp.SubnetID, sp.SubnetName, sp.IPV6, sp.IPV6mask, sp.BitBucket
    from [dbo].[RSDSubnetProperties] sp
		inner join [dbo].[RSDInterfaceProperties] ip on sp.SubnetID = ip.SubnetID
		inner join [dbo].[RSDDetectedSystemProperties] dsp on ip.HostID = dsp.HostID
		inner join [dbo].[RSDConfiguration] conf ON (conf.ID = 1)
    where sp.Ignored = 0 and
		(
			dsp.Exception = 0 and
			(
				dsp.AgentGUID is null or
				(
					(select COUNT(*) from [dbo].[EPOLeafNode] leaf where dsp.AgentGUID = leaf.AgentGUID) = 0
				)
				or
				(
					(select LastUpdate from [dbo].[EPOLeafNode] leaf where dsp.AgentGUID = leaf.AgentGUID) <
						DATEADD(day, -1 * conf.LastAgentCommunication, GETUTCDATE())
				)
			)
			and
			(
				dsp.LastDetectedTime >= DATEADD(day, -1 * conf.LastSensorDetection, GETUTCDATE())
			)
		)
    group by sp.IPV6,
		sp.SubnetName,
		sp.SubnetID,
		sp.IPV6mask,
		sp.BitBucket
    order by count desc
END
GO


if exists (select * from .[dbo].sysobjects where id = object_id(N'.[dbo].[RSDDetectedSystems]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[RSDDetectedSystems]
GO

CREATE VIEW [dbo].[RSDDetectedSystems]
AS
SELECT  dsp.HostID,
	    dsp.DnsName,
        dsp.OSPlatform,
        dsp.OSFamily,
        dsp.OSVersion,
        dsp.Domain,
        dsp.NetbiosName,
        dsp.NetbiosComment,
        dsp.Users,
        dsp.AgentGUID,
        dsp.FriendlyName,
        dsp.Ignored,
        dsp.Comments,
        dsp.IPV4,
        dsp.IPV6,
        dsp.MAC,
        dsp.Exception,
        dsp.RogueAction,
        dsp.LastDetectedTime,
        dsp.RecordedTime,
        dsp.NewDetection,
        dsp.DeviceType,
        o.OUI,
        o.OrgName,
        CASE
            WHEN dsp.AgentGUID IS NULL THEN 0
            WHEN n.AgentGUID IS NULL THEN 1
            WHEN n.LastUpdate IS NOT NULL AND n.LastUpdate < DATEADD(day, - 1 * c.LastAgentCommunication, GETUTCDATE()) THEN 2
            WHEN n.LastUpdate IS NOT NULL AND n.LastUpdate >= DATEADD(day, - 1 * c.LastAgentCommunication, GETUTCDATE()) THEN - 1
            ELSE 0
        END AS RogueState,
        CAST(
            CASE
                WHEN dsp.Exception = 0 AND dsp.AgentGUID IS NOT NULL AND n.LastUpdate IS NOT NULL
                    AND n.LastUpdate >= DATEADD(day, - 1 * c.LastAgentCommunication, GETUTCDATE()) THEN 1
                WHEN (aes.servername IS NOT NULL) THEN 1
                ELSE 0
            END AS BIT)
        AS Managed,
        CAST(
            CASE
                WHEN aes.ServerName IS NOT NULL THEN 0
                WHEN (dsp.AgentGUID IS NULL OR n.AgentGUID IS NULL OR n.LastUpdate IS NOT NULL
                    AND n.LastUpdate < DATEADD(day, - 1 * c.LastAgentCommunication, GETUTCDATE())) AND dsp.Exception = 0
                    AND dsp.LastDetectedTime >= DATEADD(day, - 1 * c.LastSensorDetection, GETUTCDATE()) THEN 1
                ELSE 0
            END AS BIT)
        AS Rogue,
        CAST(
            CASE
                WHEN (dsp.AgentGUID IS NULL OR n.AgentGUID IS NULL OR n.LastUpdate IS NOT NULL
                    AND n.LastUpdate < DATEADD(day, - 1 * c.LastAgentCommunication, GETUTCDATE()))
                    AND dsp.Exception = 0 AND dsp.LastDetectedTime < DATEADD(day, - 1 * c.LastSensorDetection, GETUTCDATE()) THEN 1
                ELSE 0
            END AS BIT)
        AS Inactive,
        dst.SourceName AS DetectedSourceName,
        n.LastUpdate AS LastAgentCommunication,
        n.AgentVersion,
        CASE
            WHEN n.AutoID IS NOT NULL THEN eposi.ComputerName
            ELSE dsap.ServerName
        END AS ServerName,
        ec.Name AS ExceptionCategory
FROM dbo.RSDDetectedSystemProperties AS dsp
    LEFT OUTER JOIN dbo.RSDDetectedSystemAgentProperties AS dsap ON dsp.HostID = dsap.HostID
    LEFT OUTER JOIN dbo.RSDConfigurationAlternateEpoServers AS aes ON dsap.ServerName = aes.ServerName
    LEFT OUTER JOIN dbo.RSDExceptionCategories AS ec ON dsp.ExceptionCategoryID = ec.CategoryID
    LEFT OUTER JOIN dbo.EPOLeafNode AS n ON dsp.AgentGUID = n.AgentGUID
    LEFT OUTER JOIN dbo.RSDDetectedSourceType AS dst ON dsp.DetectedSourceType = dst.SourceType
    LEFT OUTER JOIN dbo.OUIs AS o ON SUBSTRING(dsp.MAC, 1, 6) = o.OUI AND dsp.MAC IS NOT NULL
    CROSS JOIN dbo.RSDConfiguration AS c
    CROSS JOIN dbo.EPOServerInfo AS eposi
WHERE (dsp.Ignored = 0) AND (c.ID = 1)
GO



-- Index for RSDDetectedSourceType
IF  EXISTS (SELECT * FROM [dbo].[sysindexes] WHERE id = OBJECT_ID(N'[dbo].[RSDDetectedSourceType]') and name = N'IX_RSDDetectedSourceType_SourceType')
DROP INDEX [dbo].[RSDDetectedSourceType].[IX_RSDDetectedSourceType_SourceType]
GO

CREATE UNIQUE NONCLUSTERED INDEX [IX_RSDDetectedSourceType_SourceType] ON [dbo].[RSDDetectedSourceType]
(
	[SourceType] ASC
) ON [PRIMARY]
GO




-- Indexes for RSDExceptionCategories
IF  EXISTS (SELECT * FROM [dbo].[sysindexes] WHERE id = OBJECT_ID(N'[dbo].[RSDExceptionCategories]') AND name = N'PK_RSDExceptionCategories')
ALTER TABLE [dbo].[RSDExceptionCategories] DROP CONSTRAINT [PK_RSDExceptionCategories]
GO

ALTER TABLE [dbo].[RSDExceptionCategories] ADD  CONSTRAINT [PK_RSDExceptionCategories] PRIMARY KEY NONCLUSTERED
(
	[CategoryID] ASC
) ON [PRIMARY]
GO


IF  EXISTS (SELECT * FROM [dbo].[sysindexes] WHERE id = OBJECT_ID(N'[dbo].[RSDExceptionCategories]') AND name = N'IX_RSDExceptionCategories_CategoryIDName')
DROP INDEX [dbo].[RSDExceptionCategories].[IX_RSDExceptionCategories_CategoryIDName]
GO

CREATE UNIQUE CLUSTERED INDEX [IX_RSDExceptionCategories_CategoryIDName] ON [dbo].[RSDExceptionCategories]
(
	[CategoryID] ASC,
	[Name] ASC
) ON [PRIMARY]
GO


-- Index for RSDDetectedSystemAgentProperties
IF  EXISTS (SELECT * FROM [dbo].[sysindexes] WHERE id = OBJECT_ID(N'[dbo].[RSDDetectedSystemAgentProperties]') AND name = N'IX_RSDDetectedSystemAgentProperties_HostIDServerName')
DROP INDEX [dbo].[RSDDetectedSystemAgentProperties].[IX_RSDDetectedSystemAgentProperties_HostIDServerName]
GO

CREATE UNIQUE NONCLUSTERED INDEX [IX_RSDDetectedSystemAgentProperties_HostIDServerName] ON [dbo].[RSDDetectedSystemAgentProperties]
(
	[HostID] ASC,
	[ServerName] ASC
) ON [PRIMARY]
GO


-- Indexes for RSDConfigrationAlternateEpoServers
IF  EXISTS (SELECT * FROM [dbo].[sysindexes] WHERE id = OBJECT_ID(N'[dbo].[RSDConfigurationAlternateEpoServers]') AND name = N'PK_RSDConfigurationAlternateEpoServers')
ALTER TABLE [dbo].[RSDConfigurationAlternateEpoServers] DROP CONSTRAINT [PK_RSDConfigurationAlternateEpoServers]
GO

ALTER TABLE [dbo].[RSDConfigurationAlternateEpoServers] ADD  CONSTRAINT [PK_RSDConfigurationAlternateEpoServers] PRIMARY KEY NONCLUSTERED
(
	[ServerName] ASC
) ON [PRIMARY]
GO


IF  EXISTS (SELECT * FROM [dbo].[sysindexes] WHERE id = OBJECT_ID(N'[dbo].[RSDConfigurationAlternateEpoServers]') AND name = N'IX_RSDConfigurationAlternateEpoServers_ServerName')
DROP INDEX [dbo].[RSDConfigurationAlternateEpoServers].[IX_RSDConfigurationAlternateEpoServers_ServerName]
GO

CREATE UNIQUE CLUSTERED INDEX [IX_RSDConfigurationAlternateEpoServers_ServerName] ON [dbo].[RSDConfigurationAlternateEpoServers]
(
	[ServerName] ASC
) ON [PRIMARY]
GO

IF  EXISTS (SELECT * FROM [dbo].[sysindexes] WHERE id = OBJECT_ID(N'[dbo].[RSDInterfaceProperties]') AND name = N'IX_RSDInterfaceProperties_MAC')
DROP INDEX [dbo].[RSDInterfaceProperties].[IX_RSDInterfaceProperties_MAC]
GO

CREATE NONCLUSTERED INDEX [IX_RSDInterfaceProperties_MAC] ON [dbo].[RSDInterfaceProperties]
(
	[MAC] ASC
) ON [PRIMARY]
GO

IF  EXISTS (SELECT * FROM [dbo].[sysindexes] WHERE id = OBJECT_ID(N'[dbo].[RSDSubnetProperties]') AND name = N'IX_RSDSubnetProperties_BitBucket')
DROP INDEX [dbo].[RSDSubnetProperties].[IX_RSDSubnetProperties_BitBucket]
GO

CREATE NONCLUSTERED INDEX [IX_RSDSubnetProperties_BitBucket] ON [dbo].[RSDSubnetProperties]
(
	[BitBucket] ASC
) ON [PRIMARY]
GO



