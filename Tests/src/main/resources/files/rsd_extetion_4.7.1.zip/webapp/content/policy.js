/*
 * Copyright (C) 2004-2010 McAfee, Inc.  All Rights Reserved.
 */

function enableDisableSubnetScanSection()
{
    var enableVal = false;

    if ($("SubnetScanEnabled").checked == 1)
    {
        enableVal = true;
        $("osFingerprintingDetail").style.color = "";
        $("OSFingerprintingIntervalText").style.color = "";
        $("OSFingerprintingDelayText").style.color = "";
        $("OSCacheLifeText").style.color="";
        $("scanExceptionsDetail").style.color = "";
    }
    else
    {
        $("SubnetScanEnabled").checked = 0;
        $("osFingerprintingDetail").style.color = "#CCC";
        $("OSFingerprintingIntervalText").style.color = "#CCC";
        $("OSFingerprintingDelayText").style.color = "#CCC";
        $("OSCacheLifeText").style.color="#CCC";
        $("scanExceptionsDetail").style.color = "#CCC";
    }

    OrionCore.setEnabledById("OSFingerprinting", enableVal);
    OrionCore.setEnabledById("scanExceptions", enableVal);
    OrionCore.setEnabledById("timepickerNumbox_OSFingerprintingInterval", enableVal);
    OrionCore.setEnabledById("timepickerSelector_OSFingerprintingInterval", enableVal);
    OrionCore.setEnabledById("timepickerNumbox_OSFingerprintingDelay", enableVal);
    OrionCore.setEnabledById("timepickerSelector_OSFingerprintingDelay", enableVal);

    OrionCore.setEnabledById("scanAll", enableVal);
    OrionCore.setEnabledById("scanWhitelist", enableVal);
    OrionCore.setEnabledById("scanBlacklist", enableVal);

    if (enableVal)
    {
        enableDisableOSFingerprinting();
        if ($("scanAll").checked)
        {
            toggleWhitelist(false);
            toggleBlacklist(false);
        } else if ($("scanWhitelist").checked)
        {
            toggleWhitelist(true);
            toggleBlacklist(false);
        } else if ($("scanBlacklist").checked)
        {
            toggleWhitelist(false);
            toggleBlacklist(true);
        }
    }
    else
    {
        toggleWhitelist(enableVal);
        toggleBlacklist(enableVal);
        $("SubnetScanBlacklist").selectedIndex = -1;
        $("SubnetScanWhitelist").selectedIndex = -1;
    }

}

function enableDisableOSFingerprinting()
{
    var enableVal = false;

    if ($("OSFingerprinting").checked == 1)
    {
        enableVal = true;
        $("scanExceptionsDetail").style.color = "";
        $("OSFingerprintingIntervalText").style.color = "";
        $("OSFingerprintingDelayText").style.color = "";
        $("OSCacheLifeText").style.color="";
    }
    else
    {
        $("OSFingerprinting").checked = 0;
        $("scanExceptionsDetail").style.color = "#CCC";
        $("OSFingerprintingIntervalText").style.color = "#CCC";
        $("OSFingerprintingDelayText").style.color = "#CCC";
        $("OSCacheLifeText").style.color="#CCC";
    }

    OrionCore.setEnabledById("scanExceptions", enableVal);

    OrionCore.setEnabledById("timepickerNumbox_OSFingerprintingInterval", enableVal);
    OrionCore.setEnabledById("timepickerSelector_OSFingerprintingInterval", enableVal);
    OrionCore.setEnabledById("timepickerNumbox_OSFingerprintingDelay", enableVal);
    OrionCore.setEnabledById("timepickerSelector_OSFingerprintingDelay", enableVal);
    OrionCore.setEnabledById("timepickerNumbox_PlatformCacheLife", enableVal);
    OrionCore.setEnabledById("timepickerSelector_PlatformCacheLife", enableVal);
}


function scanAllClicked()
{
    $("scanAll").checked = true;
    toggleWhitelist(false);
    toggleBlacklist(false);
    $("SubnetScanBlacklist").selectedIndex = -1;
    $("SubnetScanWhitelist").selectedIndex = -1;
    $("scanWhitelistContainer").style.backgroundColor = "#EFEFEF";
    $("scanBlacklistContainer").style.backgroundColor = "#EFEFEF";
    OrionForm.revalidate();
}

function scanWhitelistClicked()
{
    $("scanWhitelist").checked = true;
    toggleWhitelist(true);
    toggleBlacklist(false);
    $("SubnetScanBlacklist").selectedIndex = -1;
    $("scanWhitelistContainer").style.backgroundColor = "#EFF4F8";
    $("scanBlacklistContainer").style.backgroundColor = "#EFEFEF";
    OrionForm.revalidate();
    enableWhitelistAdd();
}

function scanBlacklistClicked()
{
    $("scanBlacklist").checked = true;
    toggleWhitelist(false);
    toggleBlacklist(true);
    $("SubnetScanWhitelist").selectedIndex = -1;
    $("scanWhitelistContainer").style.backgroundColor = "#EFEFEF";
    $("scanBlacklistContainer").style.backgroundColor = "#EFF4F8";
    OrionForm.revalidate();
    enableBlacklistAdd();
}


function toggleWhitelist(enableVal)
{
    OrionCore.setEnabledById("whitelistSubnet", enableVal);
    OrionCore.setEnabledById("whitelistMask", enableVal);
    OrionCore.setEnabledById("addWhitelist", enableVal);
    OrionCore.setEnabledById("removeWhitelist", enableVal);
    OrionCore.setEnabledById("SubnetScanWhitelist", enableVal);
    if (enableVal)
    {
        $("scanWhitelistNetworkText").style.color = "";
    }
    else
    {
        $("scanWhitelistNetworkText").style.color = "#CCC";
    }
}

function toggleBlacklist(enableVal)
{
    OrionCore.setEnabledById("blacklistSubnet", enableVal);
    OrionCore.setEnabledById("blacklistMask", enableVal);
    OrionCore.setEnabledById("addBlacklist", enableVal);
    OrionCore.setEnabledById("removeBlacklist", enableVal);
    OrionCore.setEnabledById("SubnetScanBlacklist", enableVal);
    if (enableVal)
    {
        $("scanBlacklistNetworkText").style.color = "";
    }
    else
    {
        $("scanBlacklistNetworkText").style.color = "#CCC";
    }
}


function enableVLAN()
{
    OrionCore.setEnabledById("RestrictReports", true);
    $("reportingWarningText").style.color = "";
}

function disableVLAN()
{
    OrionCore.setEnabledById("RestrictReports", false);
    $("reportingWarningText").style.color = "#CCC";
}

function isNotBlank(value)
{
    var regex = /^\s+/;
    return !(regex.test(value) || (value == null) || value == "");
}

function enableIncludeAdd()
{
    if (OrionForm.isFormValid())
    {
        OrionCore.setEnabledById("addInclude", true);
    }
    else
    {
        OrionCore.setEnabledById("addInclude", false);
    }
    return true;
}

function enableExcludeAdd()
{
    if (OrionForm.isFormValid())
    {
        OrionCore.setEnabledById("addExclude", true);
    }
    else
    {
        OrionCore.setEnabledById("addExclude", false);
    }
    return true;
}

function enableBlacklistAdd()
{
    if (OrionForm.isFormValid())
    {
        OrionCore.setEnabledById("addBlacklist", true);
    }
    else
    {
        OrionCore.setEnabledById("addBlacklist", false);
    }
    return true;
}

function enableWhitelistAdd()
{
    if (OrionForm.isFormValid())
    {
        OrionCore.setEnabledById("addWhitelist", true);
    }
    else
    {
        OrionCore.setEnabledById("addWhitelist", false);
    }
    return true;
}

function checkRemoveInclude()
{
    //look to see if any elements are actually selected
    var enabled = false;

    var incList = $("IncludedSubnets");
    for (var i = 0; i < incList.length; i++)
    {
        if (incList.options[i].selected == true)
        {
            enabled = true;
        }
    }

    OrionCore.setEnabledById("removeInclude", enabled);
}

function checkRemoveExclude()
{
    var enabled = false;

    var excList = $("ExcludedSubnets");
    for (var i = 0; i < excList.length; i++)
    {
        if (excList.options[i].selected == true)
        {
            enabled = true;
        }
    }
    OrionCore.setEnabledById("removeExclude", enabled);
}

function checkRemoveWhitelist()
{
    var enabled = false;

    var incList = $("SubnetScanWhitelist");
    for (var i = 0; i < incList.length; i++)
    {
        if (incList.options[i].selected == true)
        {
            enabled = true;
        }
    }

    OrionCore.setEnabledById("removeWhitelist", enabled);
}

function checkRemoveBlacklist()
{
    var enabled = false;

    var incList = $("SubnetScanBlacklist");
    for (var i = 0; i < incList.length; i++)
    {
        if (incList.options[i].selected == true)
        {
            enabled = true;
        }
    }

    OrionCore.setEnabledById("removeBlacklist", enabled);
}


function removeIncludeSubnet()
{
    var myList = $('IncludedSubnets');
    var myLength = myList.length;
    var i;
    //var valueList = []

    //count down backwards so the indices don't change as we delete items
    for (i = myLength - 1; i >= 0; i--)
    {
        if (myList.options[i].selected)
        {
            myList.options[i] = null;
        }
    }

    updateIncludeHidden();
    checkRemoveInclude();
}


function removeExcludeSubnet()
{
    var myList = $('ExcludedSubnets');
    var myLength = myList.length;
    var i;
    //count down backwards so the indices don't change as we delete items
    for (i = myLength - 1; i >= 0; i--)
    {
        if (myList.options[i].selected)
        {
            myList.options[i] = null;
        }
    }

    updateExcludeHidden();
    checkRemoveExclude();
}


function removeWhitelistSubnet()
{
    var myList = $('SubnetScanWhitelist');
    var myLength = myList.length;
    var i;
    //count down backwards so the indices don't change as we delete items
    for (i = myLength - 1; i >= 0; i--)
    {
        if (myList.options[i].selected)
        {
            myList.options[i] = null;
        }
    }

    updateWhitelistHidden();
    checkRemoveWhitelist();
}


function removeBlacklistSubnet()
{
    var myList = $('SubnetScanBlacklist');
    var myLength = myList.length;
    var i;
    //count down backwards so the indices don't change as we delete items
    for (i = myLength - 1; i >= 0; i--)
    {
        if (myList.options[i].selected)
        {
            myList.options[i] = null;
        }
    }

    updateBlacklistHidden();
    checkRemoveBlacklist();
}

//functions below here are part of the workaround for bug #382963
function updateIncludeHidden()
{
    var inc = $("IncludedSubnets");
    var hidden = $("HiddenIncludeList");
    hidden.value = "";

    for (var i = 0; i < inc.length; i++)
    {
        hidden.value += inc[i].value + "|";
    }

    OrionForm.revalidate();
}

function updateExcludeHidden()
{
    var exc = $("ExcludedSubnets");
    var hidden = $("HiddenExcludeList");
    hidden.value = "";

    for (var i = 0; i < exc.length; i++)
    {
        hidden.value += exc[i].value + "|";
    }

    OrionForm.revalidate();
}

function updateWhitelistHidden()
{
    var inc = $("SubnetScanWhitelist");
    var hidden = $("HiddenWhitelist");
    hidden.value = "";

    for (var i = 0; i < inc.length; i++)
    {
        hidden.value += inc[i].value + "|";
    }

    OrionForm.revalidate();
}

function updateBlacklistHidden()
{
    var inc = $("SubnetScanBlacklist");
    var hidden = $("HiddenBlacklist");
    hidden.value = "";

    for (var i = 0; i < inc.length; i++)
    {
        hidden.value += inc[i].value + "|";
    }

    OrionForm.revalidate();
}

function includeRadioClicked()
{
    includeSubnetToggle(true);
    excludeSubnetToggle(false);
}

function excludeRadioClicked()
{
    includeSubnetToggle(false);
    excludeSubnetToggle(true);
}

function includeSubnetToggle(enableVal)
{
    OrionCore.setEnabledById("includeSubnet", enableVal);
    OrionCore.setEnabledById("mask", enableVal);
    OrionCore.setEnabledById("addInclude", enableVal);
    OrionCore.setEnabledById("IncludedSubnets", enableVal);
    if (enableVal)
    {
        checkRemoveInclude();
    }
    else
    {
        OrionCore.setEnabledById("removeInclude", enableVal);
    }
}

function excludeSubnetToggle(enableVal)
{
    OrionCore.setEnabledById("excludeSubnet", enableVal);
    OrionCore.setEnabledById("excludeMask", enableVal);
    OrionCore.setEnabledById("addExclude", enableVal);
    OrionCore.setEnabledById("ExcludedSubnets", enableVal);
    if (enableVal)
    {
        checkRemoveExclude();
    }
    else
    {
        OrionCore.setEnabledById("removeExclude", enableVal);
    }
}

function validateIP(value, id)
{
    var mask;

    if (id == "includeSubnet")
    {
        mask = $("mask").value;
    } else if (id == "excludeSubnet")
    {
        mask = $("excludeMask").value;
    } else if (id == "whitelistSubnet")
    {
        mask = $("whitelistMask").value;
    } else if (id == "blacklistSubnet")
    {
        mask = $("blacklistMask").value;
    }

    var result = false;
    if (OrionValidate.isValidIpv4CidrSubnet(value, mask))
    {
        result = true;
    }
    else
    {
        result = OrionValidate.isValidIpv6CidrSubnet(value, mask);
    }

    if (id == "includeSubnet")
    {
        OrionCore.setEnabledById("addInclude", result);
    } else if (id == "excludeSubnet")
    {
        OrionCore.setEnabledById("addExclude", result);
    } else if (id == "whitelistSubnet")
    {
        OrionCore.setEnabledById("addWhitelist", result);
    } else if (id == "blacklistSubnet")
    {
        OrionCore.setEnabledById("addBlacklist", result);
    }

    return result;
}

//------------------------------------------------
//  LOCAL ELECTION
//------------------------------------------------
function enableSensorElect()
{
    var enableServerElects = false;
    var enableSensorElects = false;
    var serverElectColor = "";
    var sensorElectColor = "";

    if($("serverElects").checked == 1)
    {
        // Enable the server elects
        enableServerElects = true;
        serverElectColor = "";
        sensorElectColor = "#CCC";
    }
    else
    {
        // Enable the sensor elects
        enableSensorElects = true;
        serverElectColor = "#CCC";
        sensorElectColor = "";
    }

    // Set values
    $("numActiveSensors").style.color = sensorElectColor;
    OrionCore.setEnabledById("numActiveSensors", enableSensorElects);

    $("radioNumActiveSensors").style.color = sensorElectColor;
    OrionCore.setEnabledById("radioNumActiveSensors", enableSensorElects);

    $("radioAllActiveSensors").style.color = sensorElectColor;
    OrionCore.setEnabledById("radioAllActiveSensors", enableSensorElects);

    $("div.numActiveSensorsMsg").style.color = sensorElectColor;
    OrionCore.setEnabledById("div.numActiveSensorsMsg", enableSensorElects);

    $("div.resultWaitTime").style.color = sensorElectColor;
    OrionCore.setEnabledById("div.resultWaitTime", enableSensorElects);

    $("div.electionInterval").style.color = sensorElectColor;
    OrionCore.setEnabledById("div.electionInterval", enableSensorElects);

    OrionCore.setEnabledById("timepickerNumbox_electResultWaitTime", enableSensorElects);
    OrionCore.setEnabledById("timepickerSelector_electResultWaitTime", enableSensorElects);

    OrionCore.setEnabledById("timepickerNumbox_electionInterval", enableSensorElects);
    OrionCore.setEnabledById("timepickerSelector_electionInterval", enableSensorElects);

    $("div.ipv4MulticastGroup").style.color = sensorElectColor;
    OrionCore.setEnabledById("div.ipv4MulticastGroup", enableSensorElects);

    $("ipv4Multicast").style.color = sensorElectColor;
    OrionCore.setEnabledById("ipv4Multicast", enableSensorElects);

    $("div.ipv6MulticastGroup").style.color = sensorElectColor;
    OrionCore.setEnabledById("div.ipv6MulticastGroup", enableSensorElects);

    $("ipv6Multicast").style.color = sensorElectColor;
    OrionCore.setEnabledById("ipv6Multicast", enableSensorElects);

    $("div.sensorPort").style.color = sensorElectColor;
    OrionCore.setEnabledById("div.sensorPort", enableSensorElects);

    $("sensorPort").style.color = sensorElectColor;
    OrionCore.setEnabledById("sensorPort", enableSensorElects);

    // Server settings
    $("div.activeSensorsMsg").style.color = serverElectColor;
    OrionCore.setEnabledById("div.activeSensorsMsg", enableServerElects);

    $("div.failoverSleepTime").style.color = serverElectColor;
    OrionCore.setEnabledById("div.failoverSleepTime", enableServerElects);

    OrionCore.setEnabledById("timepickerNumbox_FailoverSleepTime", enableServerElects);
    OrionCore.setEnabledById("timepickerSelector_FailoverSleepTime", enableServerElects);
}

function validateIPv4(value, id)
{
    return OrionValidate.isValidIPv4String(value);
}


function validateIPv6(value, id)
{
    return OrionValidate.isValidIPv6String(value);
}