/*
 * Copyright (c) 2004 - 2010 McAfee, Inc.  All Rights Reserved.
 */

OrionCore.addLoadHandler(function()
{
    _initHandlers();
    scanTimeout();
    scanPeriod();
});

function RSDSensor()
{

}

new RSDSensor();


RSDSensor.checkSensorsPerSubnet = function ()
{
    OrionCore.setEnabledById("sensors.per.subnet.num", $("sensors.per.subnet.max").checked);
}

function _initHandlers()
{
    var timeout = $("sensor.timeout");
    timeout.onfocus = scanTimeout;
    timeout.onblur = scanTimeout;

    var timeoutSelector = $("sensor.timeout.units");
    timeoutSelector.onchange = scanTimeout;

    var period = $("sensor.period");
    period.onfocus = scanPeriod;
    period.onblur = scanPeriod;

    var periodSelector = $("sensor.period.units");
    periodSelector.onchange = scanPeriod;
}

function scanTimeout()
{
    var timeout = $("sensor.timeout");
    var selection = $("sensor.timeout.units");

    if ((selection.value == "minutes") && (timeout.value % 60 == 0))
    {
        selection.value = "hours";
        timeout.value = timeout.value / 60;
        OrionForm.rescan();
    }

    if ((selection.value == "hours") && (timeout.value % 24 == 0))
    {
        selection.value = "days";
        timeout.value = timeout.value / 24;
        OrionForm.rescan();
    }

    OrionForm.rescan();
}

function scanPeriod()
{
    var timeout = $("sensor.period");
    var selection = $("sensor.period.units");

    if ((selection.value == "minutes") && (timeout.value % 60 == 0))
    {
        selection.value = "hours";
        timeout.value = timeout.value / 60;
        OrionForm.rescan();
    }
}

function timeoutValidator( value )
{
    var maxInt = 10080;

    //the validation depends on the value of the dropdown...
    var selection = $("sensor.timeout.units");
    if (selection.value == "hours")
    {
        maxInt = 168;
    }
    else if (selection.value == "days")
    {
        maxInt = 7;
    }

    var valid = (OrionValidate.isIntString(value) && OrionValidate.isIntBetween(value, 1, maxInt));
    OrionCore.setEnabledById("sensor.timeout.units", valid);
    return valid;
}

function timeoutUnitValidator( value )
{
    var maxInt = 10080;
    var timeout = $("sensor.timeout").value;
    if(value == "hours"){maxInt = 168;}
    else if(value == "days"){maxInt = 7;}

    var valid = OrionValidate.isIntBetween(timeout, 1, maxInt);
    OrionCore.setEnabledById("sensor.timeout.units", valid);    
    return valid;
}


function periodValidator( value )
{
    var maxInt = 1440;
    var selection = $("sensor.period.units");
    if (selection.value == "hours")
    {
        maxInt = 24;
    }

    var valid = (OrionValidate.isIntString(value) && OrionValidate.isIntBetween(value, 1, maxInt));
    OrionCore.setEnabledById("sensor.period.units", valid);
    return valid;
}

function periodUnitValidator( value )
{
    var maxInt = 1440;
    var period = $("sensor.period").value;
    if(value == "hours"){maxInt = 24;}

    var valid = OrionValidate.isIntBetween(period, 1, maxInt);
    OrionCore.setEnabledById("sensor.period.units", valid);
    return valid;
}

function macOrOUIValidator( value )
{
    if (OrionValidate.isNotEmpty(value))
    {
        var macOrOUIs = value.split(/[\r\n\s,]/);

        for (var v = 0; v < macOrOUIs.length; v++)
        {
            var s = macOrOUIs[v];
            s = OrionCore.trim(s);

            var ok = true;
            if (s != "")
            {
                var ouiRegEx = /^[0-9a-fA-F]{6}$/;
                var macRegEx = /^[0-9a-fA-F]{12}$/;
                var macRegEx2 = /^[0-9a-fA-F]{2}[:-]{1}[0-9a-fA-F]{2}[:-]{1}[0-9a-fA-F]{2}[:-]{1}[0-9a-fA-F]{2}[:-]{1}[0-9a-fA-F]{2}[:-]{1}[0-9a-fA-F]{2}$/;

                if (s.length == 6)
                {
                    ok = ouiRegEx.test(s);
                }
                else if (s.length == 12)
                {
                    ok = macRegEx.test(s);
                }
                else if (s.length == 17)
                {
                    ok = macRegEx2.test(s);
                }
                else
                {
                    ok = false;
                }
            }
            if (!ok)
            {
                return false;
            }
        }
        return true;
    }
    return false;
}

